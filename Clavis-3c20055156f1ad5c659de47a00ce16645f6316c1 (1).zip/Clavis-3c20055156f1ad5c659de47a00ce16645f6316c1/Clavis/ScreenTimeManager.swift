import Foundation
import Combine

// MARK: - Blocking Mode
//
// Defined outside the #if block so every file can reference it
// regardless of whether the FamilyControls entitlement is active.

enum BlockingMode: Equatable {
    /// Not authorized or FamilyControls unavailable. Blocking cannot function.
    case unavailable
    /// Authorized. Selected apps are shielded (or will be once apps are chosen).
    case blocked
    /// Earned-time timer is running. Selected apps are temporarily accessible.
    case earnedUnlocked
}

// ─────────────────────────────────────────────────────────────────────────────
// MARK: - Real Implementation (requires com.apple.developer.family-controls)
// ─────────────────────────────────────────────────────────────────────────────

#if canImport(FamilyControls)
import FamilyControls
import ManagedSettings

@MainActor
final class ScreenTimeManager: ObservableObject {
    static let shared = ScreenTimeManager()

    // MARK: - Published

    @Published var authorizationStatus: AuthorizationStatus = .notDetermined
    @Published var blockingMode: BlockingMode = .unavailable
    @Published var isBlocking = false
    @Published var activitySelection = FamilyActivitySelection()
    @Published var remainingSeconds: Double = 0
    @Published var lastAuthError: String = ""
    @Published var rawFCStatus: String = "unknown"

    enum AuthorizationStatus { case notDetermined, authorized, denied }

    // MARK: - Private

    private let store  = ManagedSettingsStore()
    private let center = AuthorizationCenter.shared
    private var countdownTimer: Timer?

    // Current user — all UserDefaults keys are namespaced by this.
    private var currentUserId: String = ""

    // Computed keys — scoped per user so earned time and app selection
    // are never shared between accounts.
    private var selectionKey: String { "\(currentUserId)_familyActivitySelection_v1" }
    private var expiryKey:    String { "\(currentUserId)_earnedTimeExpiry_v1" }

    // MARK: - Computed

    var remainingFormatted: String {
        let t = Int(max(0, remainingSeconds))
        return String(format: "%d:%02d", t / 60, t % 60)
    }

    var selectedAppCount: Int {
        activitySelection.applicationTokens.count
        + activitySelection.categoryTokens.count
        + activitySelection.webDomainTokens.count
    }

    // MARK: - Init

    private init() {
        syncAuthorizationStatus()
        // Do NOT load selection or expiry here — wait for restoreState(for:)
        // called by SupabaseManager after userId is known.
    }

    // MARK: - User Lifecycle

    /// Called by SupabaseManager after sign-in or session restore.
    /// Sets the active userId then resumes the correct state for that user.
    func restoreState(for userId: String) {
        currentUserId = userId
        loadSavedSelection()
        restoreState()
    }

    /// Called by SupabaseManager on sign-out.
    /// Relocks immediately and wipes in-memory earned-time state.
    func clearUserState() {
        countdownTimer?.invalidate()
        countdownTimer   = nil
        remainingSeconds = 0
        // Re-apply shields so the device is locked when the user signs out.
        if authorizationStatus == .authorized { applyShields() }
        else { blockingMode = .unavailable }
        // Clear app selection from memory (persisted copy stays keyed by userId).
        activitySelection = FamilyActivitySelection()
        currentUserId     = ""
    }

    // MARK: - Authorization

    func syncAuthorizationStatus() {
        switch center.authorizationStatus {
        case .approved:
            rawFCStatus = "approved"; authorizationStatus = .authorized
        case .denied:
            rawFCStatus = "denied";   authorizationStatus = .denied
        default:
            rawFCStatus = "notDetermined"; authorizationStatus = .notDetermined
        }
        print("🔵 [ScreenTime] FC=\(rawFCStatus) local=\(authorizationStatus)")
    }

    func requestAuthorization() async {
        print("🟡 [ScreenTime] requestAuthorization START")
        lastAuthError = ""
        do {
            try await center.requestAuthorization(for: .individual)
            print("✅ [ScreenTime] requestAuthorization SUCCESS")
            authorizationStatus = .authorized
            rawFCStatus = "approved"
            restoreState()
        } catch {
            print("❌ [ScreenTime] FAILED: \(error)")
            authorizationStatus = .denied
            blockingMode  = .unavailable
            lastAuthError = error.localizedDescription
        }
    }

    // MARK: - State Restore (foreground / scene-phase)
    //
    // Called by ClavisApp on every foreground. Uses the already-set currentUserId.

    func restoreState() {
        syncAuthorizationStatus()
        guard authorizationStatus == .authorized else {
            blockingMode = .unavailable; return
        }

        if let expiry = UserDefaults.standard.object(forKey: expiryKey) as? Date {
            let remaining = expiry.timeIntervalSinceNow
            if remaining > 0 {
                remainingSeconds = remaining
                blockingMode     = .earnedUnlocked
                isBlocking       = false
                store.clearAllSettings()
                startCountdownTimer()
            } else {
                clearExpiry()
                applyShields()
            }
        } else {
            applyShields()
        }
    }

    // MARK: - Earned Time

    func addEarnedTime(minutes: Int) {
        guard minutes > 0 else { return }
        let additional = Double(minutes * 60)

        let newExpiry: Date
        if let current = UserDefaults.standard.object(forKey: expiryKey) as? Date,
           current > Date() {
            newExpiry = current.addingTimeInterval(additional)
        } else {
            newExpiry = Date().addingTimeInterval(additional)
        }

        UserDefaults.standard.set(newExpiry, forKey: expiryKey)
        remainingSeconds = newExpiry.timeIntervalSinceNow
        store.clearAllSettings()
        isBlocking   = false
        blockingMode = .earnedUnlocked
        startCountdownTimer()
    }

    // MARK: - Blocking

    func startBlocking() { applyShields() }

    func stopBlocking() {
        store.clearAllSettings()
        isBlocking   = false
        blockingMode = .earnedUnlocked
    }

    // MARK: - Dev / QA helpers

    func testApplyBlock() {
        print("🧪 [ScreenTime] testApplyBlock — selectedAppCount=\(selectedAppCount)")
        applyShields()
        print("🧪 after → blockingMode=\(blockingMode) isBlocking=\(isBlocking)")
    }

    func testClearBlock() {
        print("🧪 [ScreenTime] testClearBlock")
        store.clearAllSettings()
        isBlocking   = false
        blockingMode = .blocked
    }

    // MARK: - Private Helpers

    private func applyShields() {
        guard authorizationStatus == .authorized else {
            blockingMode = .unavailable; return
        }
        let apps = activitySelection.applicationTokens
        let cats = activitySelection.categoryTokens
        let webs = activitySelection.webDomainTokens

        guard !apps.isEmpty || !cats.isEmpty || !webs.isEmpty else {
            blockingMode = .blocked; isBlocking = false; return
        }
        if !apps.isEmpty { store.shield.applications           = apps }
        if !cats.isEmpty { store.shield.applicationCategories = .specific(cats) }
        if !webs.isEmpty { store.shield.webDomains             = webs }
        isBlocking   = true
        blockingMode = .blocked
    }

    private func startCountdownTimer() {
        countdownTimer?.invalidate()
        countdownTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
            guard let self else { return }
            Task { @MainActor [weak self] in
                guard let self else { return }
                guard let expiry = UserDefaults.standard.object(forKey: self.expiryKey) as? Date
                else { self.relock(); return }
                let rem = expiry.timeIntervalSinceNow
                if rem <= 0 { self.relock() } else { self.remainingSeconds = rem }
            }
        }
    }

    private func relock() {
        countdownTimer?.invalidate()
        countdownTimer   = nil
        remainingSeconds = 0
        clearExpiry()
        applyShields()
    }

    private func clearExpiry() {
        UserDefaults.standard.removeObject(forKey: expiryKey)
    }

    // MARK: - Selection Persistence

    func saveSelection(_ selection: FamilyActivitySelection) {
        activitySelection = selection
        if let data = try? JSONEncoder().encode(selection) {
            UserDefaults.standard.set(data, forKey: selectionKey)
        }
        if blockingMode == .blocked { applyShields() }
    }

    func loadSavedSelection() {
        guard !currentUserId.isEmpty else { return }
        guard
            let data    = UserDefaults.standard.data(forKey: selectionKey),
            let decoded = try? JSONDecoder().decode(FamilyActivitySelection.self, from: data)
        else { activitySelection = FamilyActivitySelection(); return }
        activitySelection = decoded
    }
}

// ─────────────────────────────────────────────────────────────────────────────
#else
// MARK: - Stub (FamilyControls entitlement not yet active)
// ─────────────────────────────────────────────────────────────────────────────

@MainActor
final class ScreenTimeManager: ObservableObject {
    static let shared = ScreenTimeManager()
    private init() {}

    @Published var authorizationStatus: AuthorizationStatus = .notDetermined
    @Published var blockingMode: BlockingMode = .unavailable
    @Published var isBlocking = false
    @Published var remainingSeconds: Double = 0

    enum AuthorizationStatus { case notDetermined, authorized, denied }

    var selectedAppCount: Int { 0 }
    var remainingFormatted: String {
        let t = Int(max(0, remainingSeconds))
        return String(format: "%d:%02d", t / 60, t % 60)
    }

    private var currentUserId: String = ""
    private var expiryKey: String { "\(currentUserId)_earnedTimeExpiry_v1" }
    private var countdownTimer: Timer?

    func restoreState(for userId: String) {
        currentUserId = userId
        restoreState()
    }

    func clearUserState() {
        countdownTimer?.invalidate()
        countdownTimer   = nil
        remainingSeconds = 0
        blockingMode     = .unavailable
        isBlocking       = false
        currentUserId    = ""
    }

    func syncAuthorizationStatus() {}

    func requestAuthorization() async {
        print("⚠️ ScreenTimeManager stub — FamilyControls not active.")
        authorizationStatus = .denied
        blockingMode        = .unavailable
    }

    func restoreState() {
        guard !currentUserId.isEmpty else { return }
        guard let expiry = UserDefaults.standard.object(forKey: expiryKey) as? Date else { return }
        let remaining = expiry.timeIntervalSinceNow
        if remaining > 0 {
            remainingSeconds = remaining
            blockingMode     = .earnedUnlocked
            startCountdownTimer()
        } else {
            clearExpiry()
        }
    }

    func addEarnedTime(minutes: Int) {
        guard minutes > 0, !currentUserId.isEmpty else { return }
        let additional = Double(minutes * 60)
        let newExpiry: Date
        if let current = UserDefaults.standard.object(forKey: expiryKey) as? Date, current > Date() {
            newExpiry = current.addingTimeInterval(additional)
        } else {
            newExpiry = Date().addingTimeInterval(additional)
        }
        UserDefaults.standard.set(newExpiry, forKey: expiryKey)
        remainingSeconds = newExpiry.timeIntervalSinceNow
        blockingMode     = .earnedUnlocked
        isBlocking       = false
        startCountdownTimer()
    }

    func startBlocking() { blockingMode = .unavailable }
    func stopBlocking()  { isBlocking = false }
    func saveSelection(_ selection: Any) {}
    func loadSavedSelection() {}
    func testApplyBlock() {}
    func testClearBlock() {}

    private func startCountdownTimer() {
        countdownTimer?.invalidate()
        countdownTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
            guard let self else { return }
            Task { @MainActor [weak self] in
                guard let self else { return }
                guard let expiry = UserDefaults.standard.object(forKey: self.expiryKey) as? Date
                else { self.relock(); return }
                let rem = expiry.timeIntervalSinceNow
                if rem <= 0 { self.relock() } else { self.remainingSeconds = rem }
            }
        }
    }

    private func relock() {
        countdownTimer?.invalidate()
        countdownTimer   = nil
        remainingSeconds = 0
        clearExpiry()
        blockingMode = .unavailable
        isBlocking   = false
    }

    private func clearExpiry() {
        UserDefaults.standard.removeObject(forKey: expiryKey)
    }
}

#endif
