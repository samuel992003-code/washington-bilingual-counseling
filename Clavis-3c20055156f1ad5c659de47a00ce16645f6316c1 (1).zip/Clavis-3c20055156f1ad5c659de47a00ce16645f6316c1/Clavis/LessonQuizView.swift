import SwiftUI

// MARK: - LessonQuizView
//
// Full lesson experience for a single LessonPlan:
//   1. Lesson content screen (title, summary, key points, key term)
//   2. Quiz questions sourced from the same LessonPlan
//   3. Completion screen with spaced-repetition update
//
// This is opened from SubjectDetailView when the user taps a lesson row.
// It is NOT the quick-quiz path — that goes through QuizView directly.

struct LessonQuizView: View {
    let lesson:      LessonPlan
    @Binding var isPresented: Bool

    // Phase 1: lesson content. Phase 2: quiz.
    @State private var showLesson     = true
    @State private var appeared       = false

    // Reading gate — user must spend 15 seconds on the lesson before the
    // quiz button unlocks. Once passed it stays passed for this session.
    private static let readingGateSeconds = 15
    @State private var readingSecondsLeft: Int  = readingGateSeconds
    @State private var readingGatePassed:  Bool = false
    private let readingTimer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    // Quiz state
    @State private var currentIndex   = 0
    @State private var selectedAnswer = ""
    @State private var hasSubmitted   = false
    @State private var correctCount   = 0
    @State private var isComplete     = false

    var questions: [QuizQuestion] {
        lesson.questions.map { $0.toQuizQuestion() }
    }

    var current: QuizQuestion? {
        guard !questions.isEmpty, currentIndex < questions.count else { return nil }
        return questions[currentIndex]
    }

    var totalNeeded: Int { min(3, questions.count) }

    var isCorrect: Bool {
        guard let q = current else { return false }
        return selectedAnswer.lowercased() == q.correct.lowercased()
    }

    var body: some View {
        ZStack {
            Color(red: 0.07, green: 0.07, blue: 0.12).ignoresSafeArea()

            if isComplete {
                LessonCompleteView(
                    correctCount: correctCount,
                    totalCount:   totalNeeded,
                    lesson:       lesson,
                    isPresented:  $isPresented
                )
                .transition(.move(edge: .trailing).combined(with: .opacity))

            } else if showLesson {
                lessonContentView
                    .transition(.asymmetric(
                        insertion: .move(edge: .leading).combined(with: .opacity),
                        removal:   .move(edge: .leading).combined(with: .opacity)
                    ))

            } else if questions.isEmpty {
                emptyView

            } else if let q = current {
                quizBody(q)
                    .transition(.asymmetric(
                        insertion: .move(edge: .trailing).combined(with: .opacity),
                        removal:   .move(edge: .trailing).combined(with: .opacity)
                    ))
            }
        }
        .animation(.spring(response: 0.5), value: isComplete)
        .animation(.spring(response: 0.5), value: showLesson)
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { appeared = true }
        }
        .onReceive(readingTimer) { _ in
            guard showLesson, !readingGatePassed, !questions.isEmpty else { return }
            if readingSecondsLeft > 0 { readingSecondsLeft -= 1 }
            if readingSecondsLeft == 0 { readingGatePassed = true }
        }
    }

    // MARK: - Phase 1: Lesson Content

    private var lessonContentView: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                Button { isPresented = false } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.white.opacity(0.6))
                        .frame(width: 36, height: 36)
                        .background(Color(red: 0.12, green: 0.12, blue: 0.19))
                        .clipShape(Circle())
                }
                Spacer()
                Text("Lesson \(lesson.lessonNumber)")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(.white.opacity(0.5))
                Spacer()
                Color.clear.frame(width: 36, height: 36)
            }
            .padding(.horizontal, 24)
            .padding(.top, 60)
            .padding(.bottom, 32)

            ScrollView(showsIndicators: false) {
                VStack(spacing: 28) {

                    // Emoji icon
                    ZStack {
                        Circle()
                            .fill(Color(red: 0.42, green: 0.32, blue: 1.0).opacity(0.08))
                            .frame(width: 120, height: 120)
                        Circle()
                            .fill(Color(red: 0.42, green: 0.32, blue: 1.0).opacity(0.15))
                            .frame(width: 88, height: 88)
                        Text(AIManager.shared.emojiForSubject(lesson.subject))
                            .font(.system(size: 44))
                    }
                    .scaleEffect(appeared ? 1.0 : 0.8)
                    .opacity(appeared ? 1.0 : 0.0)
                    .animation(.spring(response: 0.5, dampingFraction: 0.7), value: appeared)

                    // Subject pill
                    Text(lesson.subject)
                        .font(.system(size: 13))
                        .foregroundColor(Color(red: 0.42, green: 0.32, blue: 1.0))
                        .padding(.horizontal, 12).padding(.vertical, 6)
                        .background(Color(red: 0.42, green: 0.32, blue: 1.0).opacity(0.15))
                        .cornerRadius(20)

                    // Title
                    Text(lesson.title)
                        .font(.system(size: 26, weight: .bold))
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)
                        .opacity(appeared ? 1.0 : 0.0)
                        .offset(y: appeared ? 0 : 16)
                        .animation(.spring(response: 0.5).delay(0.1), value: appeared)

                    // Summary
                    if !lesson.summary.isEmpty {
                        Text(lesson.summary)
                            .font(.system(size: 17))
                            .foregroundColor(.white.opacity(0.75))
                            .multilineTextAlignment(.center)
                            .lineSpacing(6)
                            .padding(.horizontal, 4)
                            .opacity(appeared ? 1.0 : 0.0)
                            .offset(y: appeared ? 0 : 16)
                            .animation(.spring(response: 0.5).delay(0.15), value: appeared)
                    }

                    // Key points
                    if !lesson.keyPoints.isEmpty {
                        VStack(alignment: .leading, spacing: 10) {
                            Text("Key Points")
                                .font(.system(size: 12, weight: .semibold))
                                .foregroundColor(.white.opacity(0.35))
                                .textCase(.uppercase)
                                .tracking(0.8)

                            ForEach(lesson.keyPoints, id: \.self) { point in
                                HStack(alignment: .top, spacing: 10) {
                                    Circle()
                                        .fill(Color(red: 0.42, green: 0.32, blue: 1.0))
                                        .frame(width: 6, height: 6)
                                        .padding(.top, 6)
                                    Text(point)
                                        .font(.system(size: 15))
                                        .foregroundColor(.white.opacity(0.85))
                                        .fixedSize(horizontal: false, vertical: true)
                                }
                            }
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(16)
                        .background(Color(red: 0.12, green: 0.12, blue: 0.19))
                        .cornerRadius(14)
                        .overlay(
                            RoundedRectangle(cornerRadius: 14)
                                .stroke(Color.white.opacity(0.07), lineWidth: 1)
                        )
                        .opacity(appeared ? 1.0 : 0.0)
                        .offset(y: appeared ? 0 : 16)
                        .animation(.spring(response: 0.5).delay(0.2), value: appeared)
                    }

                    // Key term
                    if !lesson.keyTerm.isEmpty {
                        HStack(alignment: .top, spacing: 12) {
                            Image(systemName: "key.fill")
                                .foregroundColor(.yellow)
                                .font(.system(size: 15))
                                .padding(.top, 1)
                            Text(lesson.keyTerm)
                                .font(.system(size: 15, weight: .semibold))
                                .foregroundColor(.white)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        .padding(16)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.yellow.opacity(0.10))
                        .cornerRadius(14)
                        .overlay(
                            RoundedRectangle(cornerRadius: 14)
                                .stroke(Color.yellow.opacity(0.2), lineWidth: 1)
                        )
                        .opacity(appeared ? 1.0 : 0.0)
                        .offset(y: appeared ? 0 : 16)
                        .animation(.spring(response: 0.5).delay(0.25), value: appeared)
                    }
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 24)
            }

            Spacer()

            // CTA
            VStack(spacing: 0) {
                Divider().background(Color.white.opacity(0.08))

                let gateActive = !readingGatePassed && !questions.isEmpty
                Button {
                    if questions.isEmpty {
                        isPresented = false
                    } else {
                        withAnimation(.spring(response: 0.5)) { showLesson = false }
                    }
                } label: {
                    HStack(spacing: 10) {
                        if gateActive {
                            Image(systemName: "clock")
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(.white.opacity(0.5))
                            Text("Read for \(readingSecondsLeft)s to continue")
                                .font(.system(size: 18, weight: .semibold))
                                .foregroundColor(.white.opacity(0.5))
                        } else {
                            Text(questions.isEmpty ? "Back to Clavis" : "Got it — start quiz")
                                .font(.system(size: 18, weight: .semibold))
                                .foregroundColor(.white)
                            if !questions.isEmpty {
                                Image(systemName: "arrow.right")
                                    .font(.system(size: 16, weight: .semibold))
                                    .foregroundColor(.white)
                            }
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 56)
                    .background(gateActive
                                ? Color(red: 0.12, green: 0.12, blue: 0.19)
                                : Color(red: 0.42, green: 0.32, blue: 1.0))
                    .cornerRadius(16)
                }
                .disabled(gateActive)
                .padding(.horizontal, 24)
                .padding(.vertical, 16)
                .padding(.bottom, 16)
            }
        }
    }

    // MARK: - Empty state (no questions yet)

    private var emptyView: some View {
        VStack(spacing: 20) {
            Text("😕").font(.system(size: 48))
            Text("No questions yet")
                .font(.system(size: 20, weight: .bold))
                .foregroundColor(.white)
            Text("Questions will appear after the lesson finishes generating.")
                .font(.system(size: 15))
                .foregroundColor(.white.opacity(0.5))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
            Button { isPresented = false } label: {
                Text("Go back")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 52)
                    .background(Color(red: 0.42, green: 0.32, blue: 1.0))
                    .cornerRadius(14)
                    .padding(.horizontal, 40)
            }
        }
    }

    // MARK: - Phase 2: Quiz

    @ViewBuilder
    private func quizBody(_ q: QuizQuestion) -> some View {
        VStack(spacing: 0) {
            // Header — back button returns to lesson content
            HStack {
                Button {
                    withAnimation(.spring(response: 0.5)) { showLesson = true }
                } label: {
                    Image(systemName: "chevron.left")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.white.opacity(0.6))
                        .frame(width: 36, height: 36)
                        .background(Color(red: 0.12, green: 0.12, blue: 0.19))
                        .clipShape(Circle())
                }

                Spacer()

                HStack(spacing: 8) {
                    ForEach(0..<totalNeeded, id: \.self) { i in
                        Circle()
                            .fill(
                                i < currentIndex  ? Color(red: 0.42, green: 0.32, blue: 1.0)
                                : i == currentIndex ? Color(red: 0.55, green: 0.45, blue: 1.0)
                                : Color(red: 0.12, green: 0.12, blue: 0.19)
                            )
                            .frame(width: 10, height: 10)
                            .overlay(Circle().stroke(
                                i == currentIndex ? Color(red: 0.42, green: 0.32, blue: 1.0) : Color.clear,
                                lineWidth: 1.5
                            ))
                    }
                }

                Spacer()

                Text("\(currentIndex + 1) of \(totalNeeded)")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.white.opacity(0.5))
            }
            .padding(.horizontal, 24)
            .padding(.top, 60)
            .padding(.bottom, 28)

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 22) {

                    Text("\(q.emoji)  \(q.subject)")
                        .font(.system(size: 13))
                        .foregroundColor(Color(red: 0.42, green: 0.32, blue: 1.0))
                        .padding(.horizontal, 12).padding(.vertical, 6)
                        .background(Color(red: 0.42, green: 0.32, blue: 1.0).opacity(0.15))
                        .cornerRadius(20)

                    Text(q.question)
                        .font(.system(size: 22, weight: .bold))
                        .foregroundColor(.white)
                        .lineSpacing(5)
                        .fixedSize(horizontal: false, vertical: true)

                    VStack(spacing: 12) {
                        ForEach(q.options, id: \.self) { option in
                            AnswerButton(
                                text:       option,
                                isSelected: selectedAnswer == option,
                                isCorrect:  hasSubmitted && option == q.correct,
                                isWrong:    hasSubmitted && selectedAnswer == option && option != q.correct
                            ) {
                                if !hasSubmitted { selectedAnswer = option }
                            }
                        }
                    }

                    if hasSubmitted {
                        HStack(alignment: .top, spacing: 12) {
                            Image(systemName: isCorrect ? "checkmark.circle.fill" : "lightbulb.fill")
                                .foregroundColor(isCorrect ? Color(red: 0.2, green: 0.85, blue: 0.5) : .orange)
                                .font(.system(size: 18))
                            Text(q.explanation)
                                .font(.system(size: 14))
                                .foregroundColor(.white.opacity(0.7))
                                .lineSpacing(4)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        .padding(16)
                        .background(isCorrect
                                    ? Color(red: 0.2, green: 0.85, blue: 0.5).opacity(0.12)
                                    : Color.orange.opacity(0.12))
                        .cornerRadius(14)
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                    }
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 24)
            }
            .animation(.spring(response: 0.4), value: hasSubmitted)

            Spacer()

            VStack(spacing: 0) {
                Divider().background(Color.white.opacity(0.08))
                Button(action: handleTap) {
                    Text(buttonLabel)
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 56)
                        .background(selectedAnswer.isEmpty
                                    ? Color(red: 0.12, green: 0.12, blue: 0.19)
                                    : Color(red: 0.42, green: 0.32, blue: 1.0))
                        .cornerRadius(16)
                }
                .disabled(selectedAnswer.isEmpty && !hasSubmitted)
                .padding(.horizontal, 24)
                .padding(.vertical, 16)
                .padding(.bottom, 16)
            }
        }
    }

    // MARK: - Quiz Logic

    var buttonLabel: String {
        if !hasSubmitted                   { return "Submit Answer" }
        if currentIndex >= totalNeeded - 1 { return "See Results" }
        return "Next Question"
    }

    func handleTap() {
        if !hasSubmitted {
            withAnimation(.spring(response: 0.3)) {
                hasSubmitted = true
                if isCorrect { correctCount += 1 }
            }
        } else {
            if currentIndex >= totalNeeded - 1 {
                finishLesson()
            } else {
                withAnimation(.spring(response: 0.3)) {
                    currentIndex  += 1
                    selectedAnswer = ""
                    hasSubmitted   = false
                }
            }
        }
    }

    private func finishLesson() {
        let minutesEarned = totalNeeded * 5
        StatsManager.shared.completeSession(
            correctCount:  correctCount,
            totalCount:    totalNeeded,
            minutesEarned: minutesEarned,
            subject:       lesson.subject
        )
        StorageManager.shared.markLessonComplete(id: lesson.id)
        StorageManager.shared.updateReview(
            lessonId:   lesson.id,
            correct:    correctCount >= (totalNeeded + 1) / 2,
            confidence: correctCount >= totalNeeded ? 1.0 : Double(correctCount) / Double(max(totalNeeded, 1))
        )
        // Grant earned screen time immediately — the countdown starts now.
        ScreenTimeManager.shared.addEarnedTime(minutes: minutesEarned)
        withAnimation(.spring(response: 0.5)) { isComplete = true }
    }
}

// MARK: - Lesson Complete View

struct LessonCompleteView: View {
    let correctCount: Int
    let totalCount:   Int
    let lesson:       LessonPlan
    @Binding var isPresented: Bool
    @State private var pulse = false
    @ObservedObject private var screenTime = ScreenTimeManager.shared

    var minutesEarned: Int { totalCount * 5 }
    var xpEarned:      Int { 10 + correctCount * 5 }

    var body: some View {
        ZStack {
            Color(red: 0.07, green: 0.07, blue: 0.12).ignoresSafeArea()

            VStack(spacing: 0) {
                Spacer()

                ZStack {
                    Circle()
                        .fill(Color(red: 0.42, green: 0.32, blue: 1.0).opacity(0.08))
                        .frame(width: 180, height: 180)
                        .scaleEffect(pulse ? 1.08 : 1.0)
                        .animation(.easeInOut(duration: 1.2).repeatForever(autoreverses: true), value: pulse)
                    Circle()
                        .fill(Color(red: 0.42, green: 0.32, blue: 1.0).opacity(0.15))
                        .frame(width: 120, height: 120)
                    Text("🎉").font(.system(size: 60))
                }
                .padding(.bottom, 32)

                VStack(spacing: 10) {
                    Text("Lesson Complete!")
                        .font(.system(size: 32, weight: .bold))
                        .foregroundColor(.white)
                    Text("\(correctCount) of \(totalCount) correct")
                        .font(.system(size: 18))
                        .foregroundColor(.white.opacity(0.6))
                    Text(lesson.title)
                        .font(.system(size: 14))
                        .foregroundColor(.white.opacity(0.4))
                }
                .padding(.bottom, 36)

                // Earned time display
                VStack(spacing: 6) {
                    Text("\(minutesEarned)")
                        .font(.system(size: 80, weight: .bold))
                        .foregroundColor(Color(red: 0.42, green: 0.32, blue: 1.0))
                    Text("minutes earned")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.white.opacity(0.6))

                    // Live countdown if timer already running
                    if screenTime.blockingMode == .earnedUnlocked && screenTime.remainingSeconds > 0 {
                        HStack(spacing: 6) {
                            Image(systemName: "lock.open.fill")
                                .font(.system(size: 12))
                                .foregroundColor(Color(red: 0.2, green: 0.85, blue: 0.5))
                            Text("\(screenTime.remainingFormatted) remaining")
                                .font(.system(size: 14, weight: .semibold))
                                .foregroundColor(Color(red: 0.2, green: 0.85, blue: 0.5))
                        }
                        .padding(.top, 4)
                    }
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 32)
                .background(Color(red: 0.12, green: 0.12, blue: 0.19))
                .cornerRadius(20)
                .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white.opacity(0.08), lineWidth: 1))
                .padding(.horizontal, 32)
                .padding(.bottom, 24)

                HStack(spacing: 8) {
                    Image(systemName: "bolt.fill").foregroundColor(.yellow).font(.system(size: 14))
                    Text("+\(xpEarned) XP earned")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.yellow)
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 10)
                .background(Color.yellow.opacity(0.12))
                .cornerRadius(20)

                Spacer()

                // Earned time is already ticking — just go back.
                Button { isPresented = false } label: {
                    Text("Back to Clavis →")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 56)
                        .background(Color(red: 0.42, green: 0.32, blue: 1.0))
                        .cornerRadius(16)
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 52)
            }
        }
        .onAppear { pulse = true }
    }
}

struct LessonQuizView_Previews: PreviewProvider {
    static var previews: some View {
        LessonQuizView(
            lesson: LessonPlan(
                uploadId: UUID(), lessonNumber: 1, subject: "Biology",
                title: "Photosynthesis",
                summary: "Plants convert sunlight into energy through photosynthesis, producing glucose and oxygen from CO₂ and water.",
                fullExplanation: "Photosynthesis is one of the most fundamental processes in biology.",
                keyPoints: ["Uses sunlight, water, and CO₂", "Produces glucose and oxygen", "Occurs in chloroplasts"],
                keyTerm: "Chlorophyll — the green pigment that absorbs sunlight",
                questions: []
            ),
            isPresented: .constant(true)
        )
    }
}
