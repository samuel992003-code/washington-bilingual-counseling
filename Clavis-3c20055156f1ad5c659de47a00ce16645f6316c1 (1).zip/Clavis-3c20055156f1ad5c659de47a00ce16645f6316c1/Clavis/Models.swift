import Foundation
import SwiftUI

// MARK: - Quiz Question
struct QuizQuestion: Identifiable, Codable {
    var id: String = UUID().uuidString
    var emoji: String
    var subject: String
    var question: String
    var options: [String]
    var correct: String
    var explanation: String
}

// MARK: - Lesson Card
struct LessonCard: Codable {
    var emoji: String
    var subject: String
    var title: String
    var content: String
    var keyPoint: String
}

// MARK: - Saved Question
struct SavedQuestion: Identifiable, Codable {
    var id: UUID = UUID()
    var emoji: String
    var subject: String
    var question: String
    var options: [String]
    var correct: String
    var explanation: String

    func toQuizQuestion() -> QuizQuestion {
        QuizQuestion(
            emoji: emoji, subject: subject, question: question,
            options: options, correct: correct, explanation: explanation
        )
    }
}

// MARK: - Saved Lesson
struct SavedLesson: Codable {
    var emoji: String
    var subject: String
    var title: String
    var content: String
    var keyPoint: String

    func toLessonCard() -> LessonCard {
        LessonCard(emoji: emoji, subject: subject, title: title, content: content, keyPoint: keyPoint)
    }
}

// MARK: - Mastery State
enum MasteryState: String, Codable {
    case new
    case learning
    case reviewing
    case mastered
}

// MARK: - Lesson Status
/// Explicit state machine for the AI generation pipeline.
/// Replaces the old `summary.isEmpty` heuristic — every lesson slot has a clear status.
enum LessonStatus: String, Codable {
    /// Slot created; AI generation not yet started. Shows in course map immediately.
    case placeholder
    /// Generation was paused because the API quota was exhausted.
    /// The user must tap Retry to resume — generation will not restart automatically.
    case pendingQuota
    /// Full AI content exists. The user can open this lesson and earn screen time.
    case ready
    /// Permanent generation failure (bad model / endpoint).
    /// Will not be retried automatically; shows an error badge.
    case failed
}

// MARK: - Lesson Plan
struct LessonPlan: Identifiable, Codable {
    var id: UUID
    var uploadId: UUID
    var lessonNumber: Int
    var subject: String
    var title: String
    var summary: String
    var fullExplanation: String
    var keyPoints: [String]
    var keyTerm: String
    var questions: [SavedQuestion]
    var isCompleted: Bool
    var dateCreated: Date
    var chunkIndex: Int
    var status: LessonStatus
    var masteryState: MasteryState
    var reviewInterval: Double
    var nextReviewDate: Date
    var lastReviewedDate: Date?
    var timesSeen: Int
    var timesCorrect: Int
    var timesIncorrect: Int
    var averageConfidence: Double

    var isPlaceholder: Bool { status != .ready }

    init(
        id: UUID                   = UUID(),
        uploadId: UUID,
        lessonNumber: Int,
        subject: String,
        title: String,
        summary: String,
        fullExplanation: String,
        keyPoints: [String],
        keyTerm: String,
        questions: [SavedQuestion],
        isCompleted: Bool          = false,
        dateCreated: Date          = Date(),
        chunkIndex: Int            = 0,
        status: LessonStatus       = .placeholder,
        masteryState: MasteryState = .new,
        reviewInterval: Double     = 1.0,
        nextReviewDate: Date       = Date(),
        lastReviewedDate: Date?    = nil,
        timesSeen: Int             = 0,
        timesCorrect: Int          = 0,
        timesIncorrect: Int        = 0,
        averageConfidence: Double  = 0.5
    ) {
        self.id                = id
        self.uploadId          = uploadId
        self.lessonNumber      = lessonNumber
        self.subject           = subject
        self.title             = title
        self.summary           = summary
        self.fullExplanation   = fullExplanation
        self.keyPoints         = keyPoints
        self.keyTerm           = keyTerm
        self.questions         = questions
        self.isCompleted       = isCompleted
        self.dateCreated       = dateCreated
        self.chunkIndex        = chunkIndex
        self.status            = status
        self.masteryState      = masteryState
        self.reviewInterval    = reviewInterval
        self.nextReviewDate    = nextReviewDate
        self.lastReviewedDate  = lastReviewedDate
        self.timesSeen         = timesSeen
        self.timesCorrect      = timesCorrect
        self.timesIncorrect    = timesIncorrect
        self.averageConfidence = averageConfidence
    }
}

// MARK: - Saved Upload
struct SavedUpload: Identifiable, Codable {
    var id: UUID = UUID()
    var title: String
    var icon: String
    var subject: String
    var questionCount: Int = 0
    var extractedText: String = ""
    var questions: [SavedQuestion] = []
    var lesson: SavedLesson? = nil
    var dateAdded: Date = Date()
    var status: SavedUploadStatus = .processing
    var lessonPlanBuilt: Bool = false
    var currentLessonIndex: Int = 0
    var totalChunks: Int = 0

    enum SavedUploadStatus: String, Codable {
        case processing, complete, failed
    }
}

// MARK: - Upload Item (in-memory only)
struct UploadItem: Identifiable {
    var id: UUID = UUID()
    var title: String
    var icon: String
    var status: UploadStatus
    var subject: String = "General"
    var questionCount: Int = 0
    var generatedQuestions: [QuizQuestion] = []

    enum UploadStatus {
        case processing, complete, failed
    }
}

// MARK: - Subject Item
struct SubjectItem {
    let emoji: String
    let name: String
    let questions: Int
    let color: Color
}

// MARK: - User Tier
/// Long-term progression tier derived from cumulative total XP.
/// Thresholds are defined in one place — change them here only.
enum UserTier: String, CaseIterable {
    case bronze   = "Bronze"
    case silver   = "Silver"
    case gold     = "Gold"
    case platinum = "Platinum"
    case diamond  = "Diamond"

    // ── Thresholds ───────────────────────────────────────────────
    private static let thresholds: [(tier: UserTier, minXP: Int)] = [
        (.bronze,   0),
        (.silver,   100),
        (.gold,     300),
        (.platinum, 700),
        (.diamond,  1500)
    ]

    static func from(xp: Int) -> UserTier {
        thresholds.reversed().first { xp >= $0.minXP }?.tier ?? .bronze
    }

    // ── Display ──────────────────────────────────────────────────
    var icon: String {
        switch self {
        case .bronze:   return "🥉"
        case .silver:   return "🥈"
        case .gold:     return "🥇"
        case .platinum: return "💎"
        case .diamond:  return "👑"
        }
    }

    var color: Color {
        switch self {
        case .bronze:   return Color(red: 0.72, green: 0.45, blue: 0.20)
        case .silver:   return Color(red: 0.70, green: 0.70, blue: 0.75)
        case .gold:     return Color(red: 0.95, green: 0.76, blue: 0.18)
        case .platinum: return Color(red: 0.55, green: 0.88, blue: 0.98)
        case .diamond:  return Color(red: 0.60, green: 0.42, blue: 1.00)
        }
    }

    // ── Progress ─────────────────────────────────────────────────
    var minXP: Int {
        UserTier.thresholds.first { $0.tier == self }?.minXP ?? 0
    }

    /// XP threshold for the next tier. nil when already Diamond.
    var nextTierMinXP: Int? {
        guard let idx = UserTier.thresholds.firstIndex(where: { $0.tier == self }),
              idx + 1 < UserTier.thresholds.count
        else { return nil }
        return UserTier.thresholds[idx + 1].minXP
    }

    /// 0.0–1.0 progress toward the next tier (1.0 = Diamond/max).
    func progress(xp: Int) -> Double {
        guard let next = nextTierMinXP else { return 1.0 }
        let range = next - minXP
        guard range > 0 else { return 1.0 }
        return min(1.0, Double(max(0, xp - minXP)) / Double(range))
    }
}

// MARK: - Friend Entry
struct FriendEntry: Identifiable {
    var id = UUID()
    var rank: Int
    var name: String
    var xp: Int         // total XP — used for tier calculation
    var weeklyXP: Int   // XP earned this week — used for leaderboard ranking
    var streak: Int
    var sessions: Int
    var isYou: Bool

    // Tier is always derived from total XP so it's never stale.
    var tier: UserTier { UserTier.from(xp: xp) }

    // First letter of the display name — used for the avatar.
    // Replace the Text view with AsyncImage here when profile pictures are added.
    var initial: String { String(name.first ?? "?").uppercased() }
}

// MARK: - Text Chunk
/// A slice of extracted text passed to the AI generation service.
/// Shared between LessonPlanManager (produces chunks) and StorageManager (creates placeholders).
struct TextChunk {
    let index: Int
    let text: String
}
