import SwiftUI

@main
struct ClavisApp: App {
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            ContentView2()
                .onAppear {
                    // checkSession() restores userId then calls
                    // StorageManager/StatsManager/ScreenTimeManager loadData/restoreState.
                    // Do NOT call ScreenTimeManager.restoreState() here directly —
                    // userId must be set first (checkSession does it).
                    SupabaseManager.shared.checkSession()
                }
        }
        .onChange(of: scenePhase) { _, phase in
            // Re-check on every foreground: either resume countdown or relock
            // if the earned-time window expired while the app was backgrounded.
            if phase == .active {
                Task { @MainActor in
                    ScreenTimeManager.shared.restoreState()
                }
            }
        }
    }
}
