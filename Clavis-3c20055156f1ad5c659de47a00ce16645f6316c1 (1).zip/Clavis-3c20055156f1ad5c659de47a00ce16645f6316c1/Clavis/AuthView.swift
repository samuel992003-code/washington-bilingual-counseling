import SwiftUI

struct AuthView: View {
    @State private var isSignUp = true
    @State private var name = ""
    @State private var email = ""
    @State private var password = ""
    @State private var isLoading = false
    @State private var errorMessage = ""
    @State private var infoMessage = ""
    @State private var showForgotPassword = false

    var body: some View {
        ZStack {
            Color(red: 0.07, green: 0.07, blue: 0.12)
                .ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 32) {

                    VStack(spacing: 14) {
                        ZStack {
                            Circle()
                                .fill(Color(red: 0.42, green: 0.32, blue: 1.0))
                                .frame(width: 80, height: 80)
                            Text("🗝️")
                                .font(.system(size: 36))
                        }
                        .padding(.top, 64)

                        Text("Clavis")
                            .font(.system(size: 30, weight: .bold))
                            .foregroundColor(.white)

                        Text(isSignUp ? "Create your account" : "Welcome back")
                            .font(.system(size: 16))
                            .foregroundColor(.white.opacity(0.6))
                    }

                    VStack(spacing: 14) {
                        if isSignUp {
                            InputField(icon: "person.fill", placeholder: "Your name", text: $name)
                        }
                        InputField(icon: "envelope.fill", placeholder: "Email address", text: $email, keyboardType: .emailAddress)
                        InputField(icon: "lock.fill", placeholder: "Password", text: $password, isSecure: true)

                        // "Forgot password?" — only shown on sign-in screen
                        if !isSignUp {
                            HStack {
                                Spacer()
                                Button {
                                    showForgotPassword = true
                                } label: {
                                    Text("Forgot password?")
                                        .font(.system(size: 14))
                                        .foregroundColor(Color(red: 0.42, green: 0.32, blue: 1.0))
                                }
                            }
                            .padding(.horizontal, 4)
                        }
                    }
                    .padding(.horizontal, 24)

                    if !errorMessage.isEmpty {
                        Text(errorMessage)
                            .font(.system(size: 14))
                            .foregroundColor(.red)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 24)
                    }

                    if !infoMessage.isEmpty {
                        Text(infoMessage)
                            .font(.system(size: 14))
                            .foregroundColor(Color(red: 0.4, green: 0.7, blue: 1.0))
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 24)
                    }

                    VStack(spacing: 14) {
                        Button(action: handleAuth) {
                            ZStack {
                                if isLoading {
                                    ProgressView().tint(.white)
                                } else {
                                    Text(isSignUp ? "Create Account" : "Sign In")
                                        .font(.system(size: 18, weight: .semibold))
                                        .foregroundColor(.white)
                                }
                            }
                            .frame(maxWidth: .infinity)
                            .frame(height: 56)
                            .background(Color(red: 0.42, green: 0.32, blue: 1.0))
                            .cornerRadius(16)
                        }
                        .padding(.horizontal, 24)

                        HStack(spacing: 12) {
                            Rectangle().fill(Color.white.opacity(0.08)).frame(height: 1)
                            Text("or").font(.system(size: 14)).foregroundColor(.white.opacity(0.3))
                            Rectangle().fill(Color.white.opacity(0.08)).frame(height: 1)
                        }
                        .padding(.horizontal, 24)

                        // TODO: Replace with ASAuthorizationAppleIDButton for real Sign in with Apple.
                        Button(action: handleAuth) {
                            HStack(spacing: 10) {
                                Image(systemName: "applelogo")
                                    .font(.system(size: 18, weight: .semibold))
                                Text("Continue with Apple")
                                    .font(.system(size: 17, weight: .semibold))
                            }
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .frame(height: 56)
                            .background(Color(red: 0.12, green: 0.12, blue: 0.19))
                            .cornerRadius(16)
                            .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.08), lineWidth: 1))
                        }
                        .padding(.horizontal, 24)
                    }

                    Button {
                        withAnimation { isSignUp.toggle() }
                        errorMessage = ""
                        infoMessage  = ""
                    } label: {
                        HStack(spacing: 4) {
                            Text(isSignUp ? "Already have an account?" : "Don't have an account?")
                                .foregroundColor(.white.opacity(0.5))
                            Text(isSignUp ? "Sign in" : "Sign up")
                                .foregroundColor(Color(red: 0.42, green: 0.32, blue: 1.0))
                                .fontWeight(.semibold)
                        }
                        .font(.system(size: 15))
                    }
                    .padding(.bottom, 48)
                }
            }
        }
        .sheet(isPresented: $showForgotPassword) {
            ForgotPasswordView()
        }
    }

    func handleAuth() {
        errorMessage = ""
        infoMessage  = ""
        isLoading    = true

        if isSignUp {
            SupabaseManager.shared.signUp(name: name, email: email, password: password) { success, error in
                isLoading = false
                if !success, let error {
                    if error.lowercased().contains("check your email") ||
                       error.lowercased().contains("confirm") {
                        infoMessage = error
                    } else {
                        errorMessage = error
                    }
                }
            }
        } else {
            SupabaseManager.shared.signIn(email: email, password: password) { success, error in
                isLoading = false
                if !success {
                    errorMessage = error ?? "Sign in failed."
                }
            }
        }
    }
}

// MARK: - Forgot Password Sheet

struct ForgotPasswordView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var email = ""
    @State private var isLoading = false
    @State private var errorMessage = ""
    @State private var didSend = false

    var body: some View {
        ZStack {
            Color(red: 0.07, green: 0.07, blue: 0.12)
                .ignoresSafeArea()

            VStack(spacing: 28) {
                // Handle bar
                Capsule()
                    .fill(Color.white.opacity(0.15))
                    .frame(width: 40, height: 4)
                    .padding(.top, 16)

                VStack(spacing: 10) {
                    Image(systemName: "lock.rotation")
                        .font(.system(size: 40))
                        .foregroundColor(Color(red: 0.42, green: 0.32, blue: 1.0))

                    Text("Reset Password")
                        .font(.system(size: 22, weight: .bold))
                        .foregroundColor(.white)

                    Text("Enter your email and we'll send you a link to reset your password.")
                        .font(.system(size: 14))
                        .foregroundColor(.white.opacity(0.55))
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 8)
                }

                if didSend {
                    // Success state
                    VStack(spacing: 12) {
                        Image(systemName: "envelope.badge.checkmark")
                            .font(.system(size: 36))
                            .foregroundColor(Color(red: 0.4, green: 0.85, blue: 0.55))

                        Text("Reset link sent!")
                            .font(.system(size: 18, weight: .semibold))
                            .foregroundColor(.white)

                        Text("Check your inbox at\n\(email)")
                            .font(.system(size: 14))
                            .foregroundColor(.white.opacity(0.55))
                            .multilineTextAlignment(.center)
                    }
                    .padding(.vertical, 8)

                    Button {
                        dismiss()
                    } label: {
                        Text("Done")
                            .font(.system(size: 17, weight: .semibold))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .frame(height: 54)
                            .background(Color(red: 0.42, green: 0.32, blue: 1.0))
                            .cornerRadius(16)
                    }
                    .padding(.horizontal, 24)

                } else {
                    // Input state
                    VStack(spacing: 16) {
                        InputField(icon: "envelope.fill", placeholder: "Email address",
                                   text: $email, keyboardType: .emailAddress)
                            .padding(.horizontal, 24)

                        if !errorMessage.isEmpty {
                            Text(errorMessage)
                                .font(.system(size: 13))
                                .foregroundColor(.red)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal, 24)
                        }

                        Button {
                            sendReset()
                        } label: {
                            ZStack {
                                if isLoading {
                                    ProgressView().tint(.white)
                                } else {
                                    Text("Send Reset Link")
                                        .font(.system(size: 17, weight: .semibold))
                                        .foregroundColor(.white)
                                }
                            }
                            .frame(maxWidth: .infinity)
                            .frame(height: 54)
                            .background(Color(red: 0.42, green: 0.32, blue: 1.0))
                            .cornerRadius(16)
                        }
                        .padding(.horizontal, 24)
                        .disabled(email.trimmingCharacters(in: .whitespaces).isEmpty || isLoading)

                        Button { dismiss() } label: {
                            Text("Cancel")
                                .font(.system(size: 15))
                                .foregroundColor(.white.opacity(0.45))
                        }
                    }
                }

                Spacer()
            }
        }
    }

    private func sendReset() {
        errorMessage = ""
        isLoading    = true
        SupabaseManager.shared.resetPassword(email: email.trimmingCharacters(in: .whitespaces)) { success, error in
            isLoading = false
            if success {
                didSend = true
            } else {
                errorMessage = error ?? "Something went wrong. Please try again."
            }
        }
    }
}

// MARK: - Input Field

struct InputField: View {
    let icon: String
    let placeholder: String
    @Binding var text: String
    var keyboardType: UIKeyboardType = .default
    var isSecure: Bool = false

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 15))
                .foregroundColor(.white.opacity(0.3))
                .frame(width: 22)

            if isSecure {
                SecureField(placeholder, text: $text)
                    .foregroundColor(.white)
                    .font(.system(size: 16))
            } else {
                TextField(placeholder, text: $text)
                    .foregroundColor(.white)
                    .font(.system(size: 16))
                    .keyboardType(keyboardType)
                    .autocorrectionDisabled()
                    .textInputAutocapitalization(.never)
            }
        }
        .padding(.horizontal, 16)
        .frame(height: 56)
        .background(Color(red: 0.12, green: 0.12, blue: 0.19))
        .cornerRadius(14)
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.white.opacity(0.08), lineWidth: 1))
    }
}

#Preview {
    AuthView()
}
