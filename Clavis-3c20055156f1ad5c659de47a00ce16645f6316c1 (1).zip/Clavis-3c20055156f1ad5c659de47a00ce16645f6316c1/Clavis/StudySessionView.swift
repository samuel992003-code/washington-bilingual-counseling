import SwiftUI

struct StudySessionView: View {
    let upload:      UploadItem
    @Binding var isPresented: Bool

    @State private var showLesson        = true
    @State private var currentIndex      = 0
    @State private var selectedAnswer    = ""
    @State private var hasSubmitted      = false
    @State private var correctCount      = 0
    @State private var isComplete        = false
    @State private var generatedLesson:  LessonCard? = nil
    @State private var isLoadingLesson   = true
    /// The lesson plan driving this session (nil = no plan yet, use upload questions).
    @State private var activeLessonPlan: LessonPlan? = nil
    /// Questions from the active lesson plan; falls back to upload.generatedQuestions.
    @State private var activeQuestions:  [QuizQuestion] = []

    // Spaced-repetition: accumulate confidence ratings across questions in the session.
    @State private var sessionConfidenceTotal: Double = 0.0
    @State private var sessionConfidenceCount: Int    = 0

    var questions: [QuizQuestion] {
        activeQuestions.isEmpty ? upload.generatedQuestions : activeQuestions
    }
    var totalNeeded: Int { min(3, questions.count) }

    var current: QuizQuestion? {
        guard !questions.isEmpty, currentIndex < questions.count else { return nil }
        return questions[currentIndex]
    }

    var isCorrect: Bool {
        guard let q = current else { return false }
        return selectedAnswer.lowercased() == q.correct.lowercased()
    }

    var body: some View {
        ZStack {
            Color(red: 0.07, green: 0.07, blue: 0.12).ignoresSafeArea()

            if isComplete {
                StudyCompleteView(
                    correctCount: correctCount,
                    totalCount:   totalNeeded,
                    upload:       upload,
                    isPresented:  $isPresented
                )
                .transition(.move(edge: .trailing).combined(with: .opacity))

            } else if showLesson {
                lessonView

            } else if questions.isEmpty {
                emptyQuestionsView

            } else if let q = current {
                quizView(q)
            }
        }
        .animation(.spring(response: 0.5), value: isComplete)
        .animation(.spring(response: 0.5), value: showLesson)
        .onAppear { loadLesson() }
    }

    // MARK: - Lesson View

    private var lessonView: some View {
        VStack(spacing: 0) {
            HStack {
                Button { isPresented = false } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.white.opacity(0.6))
                        .frame(width: 36, height: 36)
                        .background(Color(red: 0.12, green: 0.12, blue: 0.19))
                        .clipShape(Circle())
                }
                Spacer()
                Text("Quick lesson").font(.system(size: 15, weight: .semibold)).foregroundColor(.white.opacity(0.5))
                Spacer()
                Color.clear.frame(width: 36, height: 36)
            }
            .padding(.horizontal, 24)
            .padding(.top, 60)
            .padding(.bottom, 24)

            if isLoadingLesson {
                Spacer()
                VStack(spacing: 16) {
                    ProgressView().scaleEffect(1.3).tint(Color(red: 0.42, green: 0.32, blue: 1.0))
                    Text("Preparing your lesson…")
                        .font(.system(size: 16))
                        .foregroundColor(.white.opacity(0.5))
                }
                Spacer()
            } else if let lesson = generatedLesson {
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 28) {
                        ZStack {
                            Circle().fill(Color(red: 0.42, green: 0.32, blue: 1.0).opacity(0.08)).frame(width: 120, height: 120)
                            Circle().fill(Color(red: 0.42, green: 0.32, blue: 1.0).opacity(0.15)).frame(width: 88, height: 88)
                            Text(lesson.emoji).font(.system(size: 44))
                        }

                        Text(lesson.subject)
                            .font(.system(size: 13))
                            .foregroundColor(Color(red: 0.42, green: 0.32, blue: 1.0))
                            .padding(.horizontal, 12).padding(.vertical, 6)
                            .background(Color(red: 0.42, green: 0.32, blue: 1.0).opacity(0.15))
                            .cornerRadius(20)

                        Text(lesson.title)
                            .font(.system(size: 26, weight: .bold))
                            .foregroundColor(.white)
                            .multilineTextAlignment(.center)

                        Text(lesson.content)
                            .font(.system(size: 17))
                            .foregroundColor(.white.opacity(0.75))
                            .multilineTextAlignment(.center)
                            .lineSpacing(6)
                            .padding(.horizontal, 8)

                        HStack(spacing: 12) {
                            Image(systemName: "key.fill").foregroundColor(.yellow).font(.system(size: 16))
                            Text(lesson.keyPoint)
                                .font(.system(size: 15, weight: .semibold))
                                .foregroundColor(.white)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        .padding(16)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.yellow.opacity(0.10))
                        .cornerRadius(14)
                        .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.yellow.opacity(0.2), lineWidth: 1))
                    }
                    .padding(.horizontal, 24)
                    .padding(.bottom, 24)
                }

                Spacer()

                VStack(spacing: 0) {
                    Divider().background(Color.white.opacity(0.08))
                    Button {
                        if questions.isEmpty {
                            isPresented = false
                        } else {
                            withAnimation(.spring(response: 0.5)) { showLesson = false }
                        }
                    } label: {
                        HStack(spacing: 10) {
                            Text(questions.isEmpty ? "Back to Clavis" : "Got it — start quiz")
                                .font(.system(size: 18, weight: .semibold))
                                .foregroundColor(.white)
                            if !questions.isEmpty {
                                Image(systemName: "arrow.right")
                                    .font(.system(size: 16, weight: .semibold))
                                    .foregroundColor(.white)
                            }
                        }
                        .frame(maxWidth: .infinity)
                        .frame(height: 56)
                        .background(Color(red: 0.42, green: 0.32, blue: 1.0))
                        .cornerRadius(16)
                    }
                    .padding(.horizontal, 24)
                    .padding(.vertical, 16)
                    .padding(.bottom, 16)
                }
            }
        }
    }

    // MARK: - Empty State

    private var emptyQuestionsView: some View {
        VStack(spacing: 20) {
            Text("😕").font(.system(size: 48))
            Text("No questions yet")
                .font(.system(size: 20, weight: .bold))
                .foregroundColor(.white)
            Text("AI is still processing your material.\nPlease try again in a moment.")
                .font(.system(size: 15))
                .foregroundColor(.white.opacity(0.5))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
            Button { isPresented = false } label: {
                Text("Go back")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 52)
                    .background(Color(red: 0.42, green: 0.32, blue: 1.0))
                    .cornerRadius(14)
                    .padding(.horizontal, 40)
            }
        }
    }

    // MARK: - Quiz View

    @ViewBuilder
    private func quizView(_ q: QuizQuestion) -> some View {
        VStack(spacing: 0) {
            // Progress header
            HStack {
                Button { withAnimation(.spring(response: 0.4)) { showLesson = true } } label: {
                    Image(systemName: "chevron.left")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.white.opacity(0.6))
                        .frame(width: 36, height: 36)
                        .background(Color(red: 0.12, green: 0.12, blue: 0.19))
                        .clipShape(Circle())
                }
                Spacer()
                HStack(spacing: 8) {
                    ForEach(0..<totalNeeded, id: \.self) { i in
                        Circle()
                            .fill(i < currentIndex  ? Color(red: 0.42, green: 0.32, blue: 1.0)
                                  : i == currentIndex ? Color(red: 0.55, green: 0.45, blue: 1.0)
                                  : Color(red: 0.12, green: 0.12, blue: 0.19))
                            .frame(width: 10, height: 10)
                            .overlay(Circle().stroke(
                                i == currentIndex ? Color(red: 0.42, green: 0.32, blue: 1.0) : Color.clear,
                                lineWidth: 1.5
                            ))
                    }
                }
                Spacer()
                Text("\(currentIndex + 1) of \(totalNeeded)")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.white.opacity(0.5))
            }
            .padding(.horizontal, 24)
            .padding(.top, 60)
            .padding(.bottom, 28)

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 22) {
                    Text("\(q.emoji)  \(q.subject)")
                        .font(.system(size: 13))
                        .foregroundColor(Color(red: 0.42, green: 0.32, blue: 1.0))
                        .padding(.horizontal, 12).padding(.vertical, 6)
                        .background(Color(red: 0.42, green: 0.32, blue: 1.0).opacity(0.15))
                        .cornerRadius(20)

                    Text(q.question)
                        .font(.system(size: 22, weight: .bold))
                        .foregroundColor(.white)
                        .lineSpacing(5)
                        .fixedSize(horizontal: false, vertical: true)

                    VStack(spacing: 12) {
                        ForEach(q.options, id: \.self) { option in
                            AnswerButton(
                                text:       option,
                                isSelected: selectedAnswer == option,
                                isCorrect:  hasSubmitted && option == q.correct,
                                isWrong:    hasSubmitted && selectedAnswer == option && option != q.correct
                            ) {
                                if !hasSubmitted { selectedAnswer = option }
                            }
                        }
                    }

                    if hasSubmitted {
                        HStack(alignment: .top, spacing: 12) {
                            Image(systemName: isCorrect ? "checkmark.circle.fill" : "lightbulb.fill")
                                .foregroundColor(isCorrect ? Color(red: 0.2, green: 0.85, blue: 0.5) : .orange)
                                .font(.system(size: 18))
                            Text(q.explanation)
                                .font(.system(size: 14))
                                .foregroundColor(.white.opacity(0.7))
                                .lineSpacing(4)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        .padding(16)
                        .background(isCorrect
                                    ? Color(red: 0.2, green: 0.85, blue: 0.5).opacity(0.12)
                                    : Color.orange.opacity(0.12))
                        .cornerRadius(14)
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                    }
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 24)
            }
            .animation(.spring(response: 0.4), value: hasSubmitted)

            Spacer()

            // Bottom action area
            VStack(spacing: 0) {
                Divider().background(Color.white.opacity(0.08))

                if hasSubmitted {
                    // Confidence rating replaces the "Next" button after answer is shown.
                    confidenceRatingView
                } else {
                    Button(action: submitAnswer) {
                        Text("Submit Answer")
                            .font(.system(size: 18, weight: .semibold))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .frame(height: 56)
                            .background(selectedAnswer.isEmpty
                                        ? Color(red: 0.12, green: 0.12, blue: 0.19)
                                        : Color(red: 0.42, green: 0.32, blue: 1.0))
                            .cornerRadius(16)
                    }
                    .disabled(selectedAnswer.isEmpty)
                    .padding(.horizontal, 24)
                    .padding(.vertical, 16)
                    .padding(.bottom, 16)
                }
            }
        }
    }

    // MARK: - Confidence Rating

    private var confidenceRatingView: some View {
        VStack(spacing: 10) {
            Text("How well did you know that?")
                .font(.system(size: 13))
                .foregroundColor(.white.opacity(0.4))
                .padding(.top, 12)

            HStack(spacing: 10) {
                ConfidenceButton(label: "Still fuzzy", emoji: "😕", color: .orange) {
                    recordConfidenceAndAdvance(0.2)
                }
                ConfidenceButton(label: "Got it", emoji: "👍", color: Color(red: 0.42, green: 0.32, blue: 1.0)) {
                    recordConfidenceAndAdvance(0.7)
                }
                ConfidenceButton(label: "Easy!", emoji: "⚡", color: Color(red: 0.2, green: 0.85, blue: 0.5)) {
                    recordConfidenceAndAdvance(1.0)
                }
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 24)
        }
        .transition(.move(edge: .bottom).combined(with: .opacity))
    }

    // MARK: - Actions

    private func submitAnswer() {
        withAnimation(.spring(response: 0.3)) {
            hasSubmitted = true
            if isCorrect { correctCount += 1 }
        }
    }

    private func recordConfidenceAndAdvance(_ confidence: Double) {
        sessionConfidenceTotal += confidence
        sessionConfidenceCount += 1

        if currentIndex >= totalNeeded - 1 {
            finishSession()
        } else {
            withAnimation(.spring(response: 0.3)) {
                currentIndex  += 1
                selectedAnswer = ""
                hasSubmitted   = false
            }
        }
    }

    private func finishSession() {
        let avgConfidence  = sessionConfidenceCount > 0
            ? sessionConfidenceTotal / Double(sessionConfidenceCount)
            : 0.7
        let minutesEarned  = totalNeeded * 5

        StatsManager.shared.completeSession(
            correctCount:  correctCount,
            totalCount:    totalNeeded,
            minutesEarned: minutesEarned,
            subject:       upload.subject
        )

        if let plan = activeLessonPlan {
            StorageManager.shared.markLessonComplete(id: plan.id)
            StorageManager.shared.updateReview(
                lessonId:   plan.id,
                correct:    correctCount >= (totalNeeded + 1) / 2,
                confidence: avgConfidence
            )
            triggerNextBatchIfNeeded()
        }

        // Grant earned screen time immediately — the countdown starts now.
        ScreenTimeManager.shared.addEarnedTime(minutes: minutesEarned)

        withAnimation(.spring(response: 0.5)) { isComplete = true }
    }

    // MARK: - Lesson Loading

    func loadLesson() {
        isLoadingLesson = true
        activeQuestions = upload.generatedQuestions

        if let plan = StorageManager.shared.nextLesson(for: upload.id), !plan.questions.isEmpty {
            activeLessonPlan = plan
            activeQuestions  = plan.questions.map { $0.toQuizQuestion() }
            generatedLesson  = LessonCard(
                emoji:    AIManager.shared.emojiForSubject(plan.subject),
                subject:  plan.subject,
                title:    plan.title,
                content:  plan.summary,
                keyPoint: plan.keyTerm.isEmpty ? (plan.keyPoints.first ?? "") : plan.keyTerm
            )
            isLoadingLesson = false
            return
        }

        let savedUpload = StorageManager.shared.savedUploads.first { $0.id == upload.id }
        let text        = savedUpload.map { StorageManager.shared.extractedText(for: $0) } ?? ""

        guard !text.isEmpty else {
            generatedLesson = defaultLesson()
            isLoadingLesson = false
            return
        }

        let firstChunk = LessonPlanManager.shared.splitIntoChunks(text: text).first?.text ?? String(text.prefix(4_000))
        AIManager.shared.generateLesson(from: firstChunk, subject: upload.subject) { lesson in
            self.generatedLesson = lesson ?? self.defaultLesson()
            self.isLoadingLesson = false
        }
    }

    private func defaultLesson() -> LessonCard {
        LessonCard(
            emoji:    AIManager.shared.emojiForSubject(upload.subject),
            subject:  upload.subject,
            title:    "Key Concepts",
            content:  "Review the key concepts from your uploaded material before answering the questions.",
            keyPoint: "Understanding beats memorisation every time"
        )
    }

    private func triggerNextBatchIfNeeded() {
        guard let savedUpload = StorageManager.shared.savedUploads.first(where: { $0.id == upload.id })
        else { return }

        let remaining = StorageManager.shared.getLessons(for: upload.id).filter { !$0.isCompleted }.count
        let nextChunk = StorageManager.shared.nextChunkIndex(for: upload.id)
        guard remaining <= 2, nextChunk < savedUpload.totalChunks else { return }

        let text = StorageManager.shared.extractedText(for: savedUpload)
        guard !text.isEmpty else { return }

        LessonPlanManager.shared.generateNextBatch(
            uploadId: upload.id,
            text:     text,
            subject:  upload.subject
        ) { }
    }
}

// MARK: - Confidence Button

private struct ConfidenceButton: View {
    let label:  String
    let emoji:  String
    let color:  Color
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 6) {
                Text(emoji).font(.system(size: 22))
                Text(label)
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(color)
                    .multilineTextAlignment(.center)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(color.opacity(0.12))
            .cornerRadius(14)
            .overlay(RoundedRectangle(cornerRadius: 14).stroke(color.opacity(0.25), lineWidth: 1))
        }
    }
}

// MARK: - Study Complete View

struct StudyCompleteView: View {
    let correctCount: Int
    let totalCount:   Int
    let upload:       UploadItem
    @Binding var isPresented: Bool
    @State private var pulse = false
    @ObservedObject private var screenTime = ScreenTimeManager.shared

    var minutesEarned: Int { totalCount * 5 }
    var xpEarned:      Int { 10 + correctCount * 5 }

    var body: some View {
        ZStack {
            Color(red: 0.07, green: 0.07, blue: 0.12).ignoresSafeArea()

            VStack(spacing: 0) {
                Spacer()

                ZStack {
                    Circle()
                        .fill(Color(red: 0.42, green: 0.32, blue: 1.0).opacity(0.08))
                        .frame(width: 180, height: 180)
                        .scaleEffect(pulse ? 1.08 : 1.0)
                        .animation(.easeInOut(duration: 1.2).repeatForever(autoreverses: true), value: pulse)
                    Circle().fill(Color(red: 0.42, green: 0.32, blue: 1.0).opacity(0.15)).frame(width: 120, height: 120)
                    Text("🎉").font(.system(size: 60))
                }
                .padding(.bottom, 32)

                VStack(spacing: 10) {
                    Text("Session Complete!")
                        .font(.system(size: 32, weight: .bold))
                        .foregroundColor(.white)
                    Text("\(correctCount) of \(totalCount) correct")
                        .font(.system(size: 18))
                        .foregroundColor(.white.opacity(0.6))
                    Text("From: \(upload.title)")
                        .font(.system(size: 14))
                        .foregroundColor(.white.opacity(0.4))
                }
                .padding(.bottom, 36)

                VStack(spacing: 6) {
                    Text("\(minutesEarned)")
                        .font(.system(size: 80, weight: .bold))
                        .foregroundColor(Color(red: 0.42, green: 0.32, blue: 1.0))
                    Text("minutes earned")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.white.opacity(0.6))

                    // Live countdown — earned time starts the moment the session ends.
                    if screenTime.blockingMode == .earnedUnlocked && screenTime.remainingSeconds > 0 {
                        HStack(spacing: 6) {
                            Image(systemName: "lock.open.fill")
                                .font(.system(size: 12))
                                .foregroundColor(Color(red: 0.2, green: 0.85, blue: 0.5))
                            Text("\(screenTime.remainingFormatted) remaining")
                                .font(.system(size: 14, weight: .semibold))
                                .foregroundColor(Color(red: 0.2, green: 0.85, blue: 0.5))
                        }
                        .padding(.top, 4)
                    }
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 32)
                .background(Color(red: 0.12, green: 0.12, blue: 0.19))
                .cornerRadius(20)
                .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white.opacity(0.08), lineWidth: 1))
                .padding(.horizontal, 32)
                .padding(.bottom, 24)

                HStack(spacing: 8) {
                    Image(systemName: "bolt.fill").foregroundColor(.yellow).font(.system(size: 14))
                    Text("+\(xpEarned) XP earned")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.yellow)
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 10)
                .background(Color.yellow.opacity(0.12))
                .cornerRadius(20)

                Spacer()

                // Earned time is already granted — just dismiss.
                Button { isPresented = false } label: {
                    Text("Back to Clavis →")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 56)
                        .background(Color(red: 0.42, green: 0.32, blue: 1.0))
                        .cornerRadius(16)
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 52)
            }
        }
        .onAppear { pulse = true }
    }
}

#Preview {
    StudySessionView(
        upload: UploadItem(title: "Test", icon: "doc.fill", status: .complete, subject: "Biology"),
        isPresented: .constant(true)
    )
}
