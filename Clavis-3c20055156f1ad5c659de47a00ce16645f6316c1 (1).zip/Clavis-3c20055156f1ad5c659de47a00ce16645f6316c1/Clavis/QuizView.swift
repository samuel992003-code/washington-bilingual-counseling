import SwiftUI

// MARK: - QuizView
// The "earn screen time" quiz shown from the home screen.
// Questions are loaded from the user's uploaded material (StorageManager).
// Falls back to built-in study-skill questions when no uploads exist yet.

struct QuizView: View {
    @Binding var isPresented: Bool

    @State private var showLesson   = true
    @State private var currentIndex = 0
    @State private var selectedAnswer = ""
    @State private var hasSubmitted   = false
    @State private var correctCount   = 0
    @State private var isComplete     = false
    @State private var isLoading      = true

    @State private var questions:     [QuizQuestion] = []
    @State private var currentLesson: LessonCard?    = nil
    /// When non-nil, the quiz is scoped to this subject (used from SubjectDetailView).
    var targetSubject: String? = nil
    /// The lesson plan driving this session (lesson card + questions come from the same plan).
    @State private var activePlan: LessonPlan? = nil

    // Observe StorageManager so we can reload when lesson plans arrive after onAppear.
    @ObservedObject private var storage = StorageManager.shared

    var totalNeeded: Int { min(2, questions.count) }

    var current: QuizQuestion? {
        guard !questions.isEmpty, currentIndex < questions.count else { return nil }
        return questions[currentIndex]
    }

    var isCorrect: Bool {
        guard let q = current else { return false }
        return selectedAnswer.lowercased() == q.correct.lowercased()
    }

    var body: some View {
        ZStack {
            Color(red: 0.07, green: 0.07, blue: 0.12).ignoresSafeArea()

            if isLoading {
                loadingView
            } else if isComplete {
                CompleteView(
                    correctCount: correctCount,
                    totalCount:   totalNeeded,
                    isPresented:  $isPresented
                )
                .transition(.move(edge: .trailing).combined(with: .opacity))

            } else if questions.isEmpty {
                emptyView

            } else if showLesson, let lesson = currentLesson {
                LessonView(
                    lesson:     lesson,
                    onContinue: { withAnimation(.spring(response: 0.5)) { showLesson = false } },
                    onDismiss:  { isPresented = false }
                )
                .transition(.asymmetric(
                    insertion: .move(edge: .leading).combined(with: .opacity),
                    removal:   .move(edge: .leading).combined(with: .opacity)
                ))

            } else if let q = current {
                quizView(q)
                    .transition(.asymmetric(
                        insertion: .move(edge: .trailing).combined(with: .opacity),
                        removal:   .move(edge: .trailing).combined(with: .opacity)
                    ))
            }
        }
        .animation(.spring(response: 0.5), value: isComplete)
        .animation(.spring(response: 0.5), value: showLesson)
        .animation(.spring(response: 0.3), value: isLoading)
        .onAppear { loadContent() }
        // Reload when lesson plans arrive after the view has already appeared.
        .onChange(of: storage.lessonPlans.count) {
            guard !isComplete, questions.isEmpty || activePlan == nil else { return }
            loadContent()
        }
    }

    // MARK: - Sub-views

    private var loadingView: some View {
        VStack(spacing: 16) {
            ProgressView()
                .scaleEffect(1.3)
                .tint(Color(red: 0.42, green: 0.32, blue: 1.0))
            Text("Preparing your quiz…")
                .font(.system(size: 16))
                .foregroundColor(.white.opacity(0.5))
        }
    }

    private var emptyView: some View {
        VStack(spacing: 20) {
            Text("📂").font(.system(size: 48))
            Text("No questions yet")
                .font(.system(size: 20, weight: .bold))
                .foregroundColor(.white)
            Text("Upload your notes first so AI can\ngenerate questions from your material.")
                .font(.system(size: 15))
                .foregroundColor(.white.opacity(0.5))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
            Button { isPresented = false } label: {
                Text("Go back")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 52)
                    .background(Color(red: 0.42, green: 0.32, blue: 1.0))
                    .cornerRadius(14)
                    .padding(.horizontal, 40)
            }
        }
    }

    @ViewBuilder
    private func quizView(_ q: QuizQuestion) -> some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                Button {
                    withAnimation(.spring(response: 0.4)) { showLesson = true }
                } label: {
                    Image(systemName: "chevron.left")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.white.opacity(0.6))
                        .frame(width: 36, height: 36)
                        .background(Color(red: 0.12, green: 0.12, blue: 0.19))
                        .clipShape(Circle())
                }

                Spacer()

                HStack(spacing: 8) {
                    ForEach(0..<totalNeeded, id: \.self) { i in
                        Circle()
                            .fill(
                                i < currentIndex  ? Color(red: 0.42, green: 0.32, blue: 1.0)
                                : i == currentIndex ? Color(red: 0.55, green: 0.45, blue: 1.0)
                                : Color(red: 0.12, green: 0.12, blue: 0.19)
                            )
                            .frame(width: 10, height: 10)
                            .overlay(Circle().stroke(
                                i == currentIndex ? Color(red: 0.42, green: 0.32, blue: 1.0) : Color.clear,
                                lineWidth: 1.5
                            ))
                    }
                }

                Spacer()

                Text("\(currentIndex + 1) of \(totalNeeded)")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.white.opacity(0.5))
            }
            .padding(.horizontal, 24)
            .padding(.top, 60)
            .padding(.bottom, 28)

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 22) {
                    Text("\(q.emoji)  \(q.subject)")
                        .font(.system(size: 13))
                        .foregroundColor(Color(red: 0.42, green: 0.32, blue: 1.0))
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(Color(red: 0.42, green: 0.32, blue: 1.0).opacity(0.15))
                        .cornerRadius(20)

                    Text(q.question)
                        .font(.system(size: 22, weight: .bold))
                        .foregroundColor(.white)
                        .lineSpacing(5)
                        .fixedSize(horizontal: false, vertical: true)

                    VStack(spacing: 12) {
                        ForEach(q.options, id: \.self) { option in
                            AnswerButton(
                                text:       option,
                                isSelected: selectedAnswer == option,
                                isCorrect:  hasSubmitted && option == q.correct,
                                isWrong:    hasSubmitted && selectedAnswer == option && option != q.correct
                            ) {
                                if !hasSubmitted { selectedAnswer = option }
                            }
                        }
                    }

                    if hasSubmitted {
                        HStack(alignment: .top, spacing: 12) {
                            Image(systemName: isCorrect ? "checkmark.circle.fill" : "lightbulb.fill")
                                .foregroundColor(isCorrect ? Color(red: 0.2, green: 0.85, blue: 0.5) : .orange)
                                .font(.system(size: 18))
                            Text(q.explanation)
                                .font(.system(size: 14))
                                .foregroundColor(.white.opacity(0.7))
                                .lineSpacing(4)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        .padding(16)
                        .background(isCorrect
                                    ? Color(red: 0.2, green: 0.85, blue: 0.5).opacity(0.12)
                                    : Color.orange.opacity(0.12))
                        .cornerRadius(14)
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                    }
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 24)
            }
            .animation(.spring(response: 0.4), value: hasSubmitted)

            Spacer()

            VStack(spacing: 0) {
                Divider().background(Color.white.opacity(0.08))
                Button(action: handleTap) {
                    Text(buttonLabel)
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 56)
                        .background(selectedAnswer.isEmpty
                                    ? Color(red: 0.12, green: 0.12, blue: 0.19)
                                    : Color(red: 0.42, green: 0.32, blue: 1.0))
                        .cornerRadius(16)
                }
                .disabled(selectedAnswer.isEmpty && !hasSubmitted)
                .padding(.horizontal, 24)
                .padding(.vertical, 16)
                .padding(.bottom, 16)
            }
        }
    }

    // MARK: - Content Loading

    private func loadContent() {
        isLoading = true

        // ── PHASE 1: find a lesson plan — lesson card and questions from the SAME source ──

        let candidatePlans: [LessonPlan]
        if let subject = targetSubject {
            // Filter out placeholders — only use lessons with real content.
            candidatePlans = StorageManager.shared.getLessons(for: subject)
                .filter { !$0.isPlaceholder && !$0.questions.isEmpty }
        } else {
            candidatePlans = StorageManager.shared.lessonPlans
                .filter { !$0.isPlaceholder && !$0.questions.isEmpty }
                .sorted { $0.dateCreated > $1.dateCreated }
        }

        if let plan = candidatePlans.first(where: { !$0.isCompleted }) ?? candidatePlans.first {
            activePlan    = plan
            questions     = Array(plan.questions.map { $0.toQuizQuestion() }.prefix(5))
            currentLesson = LessonCard(
                emoji:    AIManager.shared.emojiForSubject(plan.subject),
                subject:  plan.subject,
                title:    plan.title,
                content:  plan.summary,
                keyPoint: plan.keyTerm.isEmpty ? (plan.keyPoints.first ?? "") : plan.keyTerm
            )
            isLoading = false
            return
        }

        // ── PHASE 2: no lesson plans yet — fall back to upload-level questions ──

        let uploads: [SavedUpload]
        if let subject = targetSubject {
            uploads = StorageManager.shared.savedUploads
                .filter { $0.subject.lowercased() == subject.lowercased() }
        } else {
            uploads = StorageManager.shared.savedUploads
        }

        let allUploadQuestions = uploads.flatMap { $0.questions }.map { $0.toQuizQuestion() }

        if allUploadQuestions.isEmpty {
            questions     = fallbackQuestions()
            currentLesson = fallbackLesson(subject: targetSubject ?? "Study Skills")
            isLoading     = false
            return
        }

        questions = Array(allUploadQuestions.shuffled().prefix(5))

        // Generate a matching lesson card from the upload's extracted text.
        let subject = questions.first?.subject ?? targetSubject ?? "General"
        if let upload = uploads.first(where: { $0.subject.lowercased() == subject.lowercased() }) {
            let text = StorageManager.shared.extractedText(for: upload)
            if !text.isEmpty {
                AIManager.shared.generateLesson(from: text, subject: subject) { lesson in
                    self.currentLesson = lesson ?? self.fallbackLesson(subject: subject)
                    self.isLoading     = false
                }
                return
            }
        }

        currentLesson = fallbackLesson(subject: subject)
        isLoading     = false
    }

    // MARK: - Fallbacks

    private func fallbackQuestions() -> [QuizQuestion] {
        [
            QuizQuestion(
                emoji: "📚", subject: "Study Skills",
                question: "Which learning technique has the strongest scientific evidence for long-term retention?",
                options: ["Highlighting text", "Re-reading notes", "Active recall", "Summarising once"],
                correct: "Active recall",
                explanation: "Active recall — testing yourself — beats passive review in nearly every study."
            ),
            QuizQuestion(
                emoji: "📚", subject: "Study Skills",
                question: "Spaced repetition improves long-term memory.",
                options: ["True", "False"],
                correct: "True",
                explanation: "Reviewing material at increasing intervals strengthens memory far better than massed practice."
            )
        ]
    }

    private func fallbackLesson(subject: String = "Study Skills") -> LessonCard {
        LessonCard(
            emoji:    AIManager.shared.emojiForSubject(subject),
            subject:  subject,
            title:    "Study Smarter",
            content:  "Upload your notes and Clavis will generate personalised questions from your own material. Active recall — answering questions — is the most effective study technique backed by science.",
            keyPoint: "Upload notes → AI generates your questions → you earn screen time"
        )
    }

    // MARK: - Quiz Logic

    var buttonLabel: String {
        if !hasSubmitted            { return "Submit Answer" }
        if currentIndex >= totalNeeded - 1 { return "See Results" }
        return "Next Question"
    }

    func handleTap() {
        if !hasSubmitted {
            withAnimation(.spring(response: 0.3)) {
                hasSubmitted = true
                if isCorrect { correctCount += 1 }
            }
        } else {
            if currentIndex >= totalNeeded - 1 {
                withAnimation(.spring(response: 0.5)) { isComplete = true }
            } else {
                withAnimation(.spring(response: 0.3)) {
                    currentIndex   += 1
                    selectedAnswer  = ""
                    hasSubmitted    = false
                }
            }
        }
    }
}

// MARK: - Lesson View (shown before quiz)

struct LessonView: View {
    let lesson:     LessonCard
    let onContinue: () -> Void
    let onDismiss:  () -> Void
    @State private var appeared = false

    var body: some View {
        ZStack {
            Color(red: 0.07, green: 0.07, blue: 0.12).ignoresSafeArea()

            VStack(spacing: 0) {
                HStack {
                    Button(action: onDismiss) {
                        Image(systemName: "xmark")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.white.opacity(0.6))
                            .frame(width: 36, height: 36)
                            .background(Color(red: 0.12, green: 0.12, blue: 0.19))
                            .clipShape(Circle())
                    }
                    Spacer()
                    Text("Quick lesson")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(.white.opacity(0.5))
                    Spacer()
                    Color.clear.frame(width: 36, height: 36)
                }
                .padding(.horizontal, 24)
                .padding(.top, 60)
                .padding(.bottom, 32)

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 28) {
                        ZStack {
                            Circle().fill(Color(red: 0.42, green: 0.32, blue: 1.0).opacity(0.08)).frame(width: 120, height: 120)
                            Circle().fill(Color(red: 0.42, green: 0.32, blue: 1.0).opacity(0.15)).frame(width: 88, height: 88)
                            Text(lesson.emoji).font(.system(size: 44))
                        }
                        .scaleEffect(appeared ? 1.0 : 0.8)
                        .opacity(appeared ? 1.0 : 0.0)
                        .animation(.spring(response: 0.5, dampingFraction: 0.7), value: appeared)

                        Text(lesson.subject)
                            .font(.system(size: 13))
                            .foregroundColor(Color(red: 0.42, green: 0.32, blue: 1.0))
                            .padding(.horizontal, 12).padding(.vertical, 6)
                            .background(Color(red: 0.42, green: 0.32, blue: 1.0).opacity(0.15))
                            .cornerRadius(20)

                        Text(lesson.title)
                            .font(.system(size: 28, weight: .bold))
                            .foregroundColor(.white)
                            .multilineTextAlignment(.center)
                            .opacity(appeared ? 1.0 : 0.0)
                            .offset(y: appeared ? 0 : 20)
                            .animation(.spring(response: 0.5).delay(0.1), value: appeared)

                        Text(lesson.content)
                            .font(.system(size: 17))
                            .foregroundColor(.white.opacity(0.7))
                            .multilineTextAlignment(.center)
                            .lineSpacing(6)
                            .padding(.horizontal, 8)
                            .opacity(appeared ? 1.0 : 0.0)
                            .offset(y: appeared ? 0 : 20)
                            .animation(.spring(response: 0.5).delay(0.2), value: appeared)

                        HStack(spacing: 12) {
                            Image(systemName: "key.fill").foregroundColor(.yellow).font(.system(size: 16))
                            Text(lesson.keyPoint)
                                .font(.system(size: 15, weight: .semibold))
                                .foregroundColor(.white)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        .padding(16)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.yellow.opacity(0.10))
                        .cornerRadius(14)
                        .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.yellow.opacity(0.2), lineWidth: 1))
                        .opacity(appeared ? 1.0 : 0.0)
                        .offset(y: appeared ? 0 : 20)
                        .animation(.spring(response: 0.5).delay(0.3), value: appeared)
                    }
                    .padding(.horizontal, 24)
                    .padding(.bottom, 24)
                }

                Spacer()

                VStack(spacing: 0) {
                    Divider().background(Color.white.opacity(0.08))
                    Button(action: onContinue) {
                        HStack(spacing: 10) {
                            Text("Got it — start quiz")
                                .font(.system(size: 18, weight: .semibold))
                                .foregroundColor(.white)
                            Image(systemName: "arrow.right")
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(.white)
                        }
                        .frame(maxWidth: .infinity)
                        .frame(height: 56)
                        .background(Color(red: 0.42, green: 0.32, blue: 1.0))
                        .cornerRadius(16)
                    }
                    .padding(.horizontal, 24)
                    .padding(.vertical, 16)
                    .padding(.bottom, 16)
                }
            }
        }
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { appeared = true }
        }
    }
}

// MARK: - Answer Button

struct AnswerButton: View {
    let text:       String
    let isSelected: Bool
    let isCorrect:  Bool
    let isWrong:    Bool
    let action:     () -> Void

    var bg: Color {
        if isCorrect  { return Color(red: 0.2, green: 0.85, blue: 0.5).opacity(0.12) }
        if isWrong    { return Color.red.opacity(0.12) }
        if isSelected { return Color(red: 0.42, green: 0.32, blue: 1.0).opacity(0.15) }
        return Color(red: 0.12, green: 0.12, blue: 0.19)
    }

    var border: Color {
        if isCorrect  { return Color(red: 0.2, green: 0.85, blue: 0.5) }
        if isWrong    { return .red }
        if isSelected { return Color(red: 0.42, green: 0.32, blue: 1.0) }
        return Color.white.opacity(0.08)
    }

    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Text(text)
                    .font(.system(size: 16))
                    .foregroundColor(.white)
                    .multilineTextAlignment(.leading)
                    .fixedSize(horizontal: false, vertical: true)
                Spacer()
                if isCorrect {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundColor(Color(red: 0.2, green: 0.85, blue: 0.5))
                        .font(.system(size: 20))
                } else if isWrong {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundColor(.red)
                        .font(.system(size: 20))
                }
            }
            .padding(16)
            .background(bg)
            .cornerRadius(14)
            .overlay(RoundedRectangle(cornerRadius: 14).stroke(border, lineWidth: isSelected || isCorrect || isWrong ? 1.5 : 1))
        }
        .animation(.spring(response: 0.25), value: isSelected)
    }
}

// MARK: - Complete Screen

struct CompleteView: View {
    let correctCount: Int
    let totalCount:   Int
    @Binding var isPresented: Bool
    @State private var pulse = false

    var minutesEarned: Int { totalCount * 5 }
    var xpEarned:      Int { 10 + correctCount * 5 }

    var body: some View {
        ZStack {
            Color(red: 0.07, green: 0.07, blue: 0.12).ignoresSafeArea()

            VStack(spacing: 0) {
                Spacer()

                ZStack {
                    Circle()
                        .fill(Color(red: 0.42, green: 0.32, blue: 1.0).opacity(0.08))
                        .frame(width: 180, height: 180)
                        .scaleEffect(pulse ? 1.08 : 1.0)
                        .animation(.easeInOut(duration: 1.2).repeatForever(autoreverses: true), value: pulse)
                    Circle()
                        .fill(Color(red: 0.42, green: 0.32, blue: 1.0).opacity(0.15))
                        .frame(width: 120, height: 120)
                    Text("🎉").font(.system(size: 60))
                }
                .padding(.bottom, 32)

                VStack(spacing: 10) {
                    Text("Session Complete!")
                        .font(.system(size: 32, weight: .bold))
                        .foregroundColor(.white)
                    Text("\(correctCount) of \(totalCount) correct")
                        .font(.system(size: 18))
                        .foregroundColor(.white.opacity(0.6))
                }
                .padding(.bottom, 36)

                VStack(spacing: 6) {
                    Text("\(minutesEarned)")
                        .font(.system(size: 80, weight: .bold))
                        .foregroundColor(Color(red: 0.42, green: 0.32, blue: 1.0))
                    Text("minutes earned")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.white.opacity(0.6))
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 32)
                .background(Color(red: 0.12, green: 0.12, blue: 0.19))
                .cornerRadius(20)
                .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white.opacity(0.08), lineWidth: 1))
                .padding(.horizontal, 32)
                .padding(.bottom, 24)

                HStack(spacing: 8) {
                    Image(systemName: "bolt.fill").foregroundColor(.yellow).font(.system(size: 14))
                    Text("+\(xpEarned) XP earned")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.yellow)
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 10)
                .background(Color.yellow.opacity(0.12))
                .cornerRadius(20)

                Spacer()

                Button {
                    // Unblock apps so the user can enjoy their earned time.
                    ScreenTimeManager.shared.stopBlocking()
                    isPresented = false
                } label: {
                    Text("Claim your \(minutesEarned) minutes →")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 56)
                        .background(Color(red: 0.42, green: 0.32, blue: 1.0))
                        .cornerRadius(16)
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 52)
            }
        }
        .onAppear {
            pulse = true
            StatsManager.shared.completeSession(
                correctCount:  correctCount,
                totalCount:    totalCount,
                minutesEarned: minutesEarned,
                subject:       "General"
            )
        }
    }
}
