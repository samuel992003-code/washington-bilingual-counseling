import SwiftUI

struct ContentView2: View {
    // Observe SupabaseManager directly so the view reacts to every
    // sign-in, sign-out, and account switch in real time.
    @ObservedObject private var auth = SupabaseManager.shared
    @AppStorage("hasCompletedOnboarding") private var hasCompletedOnboarding = false

    var body: some View {
        Group {
            if auth.isLoggedIn {
                MainTabView()
                    // .id forces SwiftUI to completely destroy and rebuild
                    // MainTabView whenever the signed-in userId changes.
                    // Without this, the old user's views stay alive in memory
                    // and show stale data even after a new user signs in.
                    .id(auth.userId)
            } else if hasCompletedOnboarding {
                AuthView()
            } else {
                OnboardingView()
            }
        }
    }
}

#Preview {
    ContentView2()
}
