import Foundation
import Combine

// MARK: - LessonPlanManager
//
// Orchestrates the lesson-plan generation pipeline.
// All HTTP / AI logic lives in AIGenerationService implementations — this class
// only coordinates batching, concurrency, and quota handling.
//
// Two generation modes:
//
//   buildLessonPlan(from:subject:uploadId:)   — Upload-based.
//     Splits extracted text into ~700-word chunks. Each chunk becomes one lesson
//     grounded in the user's source material. Uses GeminiGenerationService.
//
//   buildTopicCourse(topic:level:subject:)    — Topic-based.
//     Generates a 30-lesson curriculum outline first (single API call), then
//     generates each lesson from first principles. Uses TopicGenerationService.
//     No source text required from the user.
//
// Both modes share the same batching, quota handling, and StorageManager output.

final class LessonPlanManager: ObservableObject {
    static let shared = LessonPlanManager()
    private init() {}

    // MARK: - Swappable service (upload-based default)
    var service: AIGenerationService = GeminiGenerationService.shared

    // MARK: - Configuration
    /// Lessons generated immediately so the user can start studying within seconds.
    private let immediateCount = 3
    /// Max concurrent API calls. Keep at 1–2 to stay well inside quota limits.
    private let apiThrottle = DispatchSemaphore(value: 2)
    private let serialQueue = DispatchQueue(label: "com.clavis.lessonplan.serial")

    // MARK: - Quota state
    private var _quotaExceeded = false
    @Published var isQuotaExceeded: Bool = false

    /// Reset the quota flag. Must be called explicitly from a user-initiated retry — never on onAppear.
    func resetQuota() {
        serialQueue.async {
            self._quotaExceeded = false
            DispatchQueue.main.async { self.isQuotaExceeded = false }
        }
    }

    // MARK: - Upload-Based: Build Lesson Plan

    func buildLessonPlan(
        from text: String,
        subject: String,
        uploadId: UUID,
        completion: @escaping () -> Void
    ) {
        resetQuota()

        let chunks = splitIntoChunks(text: text)
        guard !chunks.isEmpty else { completion(); return }

        // Step 1: Create the full course map (all placeholders) immediately.
        DispatchQueue.main.async {
            StorageManager.shared.markTotalChunks(uploadId: uploadId, count: chunks.count)
            StorageManager.shared.createPlaceholders(for: chunks, subject: subject, uploadId: uploadId)
            StorageManager.shared.markLessonPlanBuilt(uploadId: uploadId)
        }

        // Step 2: Generate first N lessons at high priority.
        let immediate  = Array(chunks.prefix(immediateCount))
        let background = Array(chunks.dropFirst(immediateCount))

        generateBatch(chunks: immediate, qos: .userInitiated, subject: subject, uploadId: uploadId,
                      service: GeminiGenerationService.shared) { _ in
            guard !background.isEmpty else { completion(); return }
            self.generateBatch(chunks: background, qos: .utility, subject: subject, uploadId: uploadId,
                               service: GeminiGenerationService.shared) { _ in
                completion()
            }
        }
    }

    // MARK: - Topic-Based: Build 1-Month Course

    /// Generates a 30-lesson AI curriculum for the given topic and level.
    /// Does NOT require any source text from the user.
    ///
    /// Flow:
    ///   1. Call generateCurriculum → get 30 (index, title) pairs.
    ///   2. Create SavedUpload + 30 placeholder LessonPlans (real titles, not "Lesson N").
    ///   3. Call completion(true) — the UI can dismiss immediately.
    ///   4. Generate lessons in background using TopicGenerationService.
    func buildTopicCourse(
        topic: String,
        level: String,
        subject: String,
        completion: @escaping (_ success: Bool) -> Void
    ) {
        resetQuota()

        AIManager.shared.generateCurriculum(topic: topic, level: level) { titles in
            guard !titles.isEmpty else {
                completion(false)
                return
            }

            let uploadId = UUID()

            // Encode curriculum as the upload's stored text so retry logic can
            // reconstruct chunks without a second API call.
            let curriculumText = titles
                .map { "Lesson \($0.index + 1): \($0.title)" }
                .joined(separator: "\n")
            let storedText = "TOPIC_COURSE:\(topic)\nLEVEL:\(level)\n\n\(curriculumText)"

            var upload = SavedUpload(
                id:            uploadId,
                title:         topic,
                icon:          "sparkles",
                subject:       subject,
                extractedText: storedText
            )
            upload.status = .complete

            DispatchQueue.main.async {
                StorageManager.shared.saveUpload(upload)
                StorageManager.shared.markTotalChunks(uploadId: uploadId, count: titles.count)
                StorageManager.shared.createTopicPlaceholders(
                    titles:   titles,
                    subject:  subject,
                    uploadId: uploadId
                )
                StorageManager.shared.markLessonPlanBuilt(uploadId: uploadId)

                // Notify the caller — UI dismisses; generation continues in background.
                completion(true)

                // Build TextChunks encoding topic/level/title for TopicGenerationService.
                let chunks = titles.map { item in
                    TextChunk(
                        index: item.index,
                        text:  "COURSE:\(topic)\nLEVEL:\(level)\nTITLE:\(item.title)"
                    )
                }
                let immediate  = Array(chunks.prefix(self.immediateCount))
                let background = Array(chunks.dropFirst(self.immediateCount))

                self.generateBatch(chunks: immediate, qos: .userInitiated, subject: subject,
                                   uploadId: uploadId, service: TopicGenerationService.shared) { _ in
                    guard !background.isEmpty else { return }
                    self.generateBatch(chunks: background, qos: .utility, subject: subject,
                                       uploadId: uploadId, service: TopicGenerationService.shared) { _ in }
                }
            }
        }
    }

    // MARK: - Resume After Quota Reset

    /// Resumes generation for any `.placeholder` or `.pendingQuota` lessons.
    /// Caller must call `resetQuota()` first.
    func generateNextBatch(
        uploadId: UUID,
        text: String,
        subject: String,
        completion: @escaping () -> Void
    ) {
        // Detect topic-based courses by the stored text prefix.
        if text.hasPrefix("TOPIC_COURSE:") {
            resumeTopicBatch(uploadId: uploadId, storedText: text, subject: subject, completion: completion)
        } else {
            resumeUploadBatch(uploadId: uploadId, text: text, subject: subject, completion: completion)
        }
    }

    private func resumeUploadBatch(uploadId: UUID, text: String, subject: String, completion: @escaping () -> Void) {
        let allChunks = splitIntoChunks(text: text)
        let pendingIndices = Set(
            StorageManager.shared.getLessons(for: uploadId)
                .filter { $0.status == .placeholder || $0.status == .pendingQuota }
                .map    { $0.chunkIndex }
        )
        let pending = allChunks.filter { pendingIndices.contains($0.index) }
        guard !pending.isEmpty else { completion(); return }
        generateBatch(chunks: pending, qos: .utility, subject: subject, uploadId: uploadId,
                      service: GeminiGenerationService.shared) { _ in completion() }
    }

    private func resumeTopicBatch(uploadId: UUID, storedText: String, subject: String, completion: @escaping () -> Void) {
        // Reconstruct topic/level from header, titles from body lines.
        let lines  = storedText.components(separatedBy: "\n")
        var topic  = subject
        var level  = "Beginner"
        var titles: [(index: Int, title: String)] = []

        for line in lines {
            if line.hasPrefix("TOPIC_COURSE:") { topic = String(line.dropFirst(13)) }
            else if line.hasPrefix("LEVEL:")    { level = String(line.dropFirst(6)) }
            else if line.hasPrefix("Lesson ") {
                // "Lesson N: Title text"
                let body = String(line.dropFirst(7))
                if let colonRange = body.range(of: ": ") {
                    let numStr = String(body[body.startIndex..<colonRange.lowerBound])
                    let title  = String(body[colonRange.upperBound...])
                    if let num = Int(numStr) {
                        titles.append((index: num - 1, title: title))
                    }
                }
            }
        }

        let pendingIndices = Set(
            StorageManager.shared.getLessons(for: uploadId)
                .filter { $0.status == .placeholder || $0.status == .pendingQuota }
                .map    { $0.chunkIndex }
        )
        let pending = titles
            .filter { pendingIndices.contains($0.index) }
            .map    { TextChunk(index: $0.index, text: "COURSE:\(topic)\nLEVEL:\(level)\nTITLE:\($0.title)") }

        guard !pending.isEmpty else { completion(); return }
        generateBatch(chunks: pending, qos: .utility, subject: subject, uploadId: uploadId,
                      service: TopicGenerationService.shared) { _ in completion() }
    }

    // MARK: - Private: Batch Runner

    /// `service` parameter selects which AIGenerationService to use for this batch.
    /// Defaults to `self.service` so existing call sites don't need updating.
    private func generateBatch(
        chunks: [TextChunk],
        qos: DispatchQoS.QoSClass,
        subject: String,
        uploadId: UUID,
        service: AIGenerationService? = nil,
        completion: @escaping ([LessonPlan]) -> Void
    ) {
        guard !chunks.isEmpty else { completion([]); return }

        let activeService = service ?? self.service
        var results: [LessonPlan] = []
        let group = DispatchGroup()

        for chunk in chunks {
            group.enter()
            DispatchQueue.global(qos: qos).async {

                guard !self.serialQueue.sync(execute: { self._quotaExceeded }) else {
                    print("⏭ Chunk \(chunk.index) skipped — quota paused.")
                    group.leave()
                    return
                }

                self.apiThrottle.wait()

                guard !self.serialQueue.sync(execute: { self._quotaExceeded }) else {
                    self.apiThrottle.signal()
                    print("⏭ Chunk \(chunk.index) skipped after wait — quota paused.")
                    group.leave()
                    return
                }

                self.generateWithRetry(chunk: chunk, subject: subject, uploadId: uploadId,
                                       service: activeService) { plan, error in
                    if let plan = plan {
                        DispatchQueue.main.async {
                            StorageManager.shared.saveSingleLessonPlan(plan, for: uploadId)
                        }
                    }

                    if plan == nil, let error = error {
                        switch error {
                        case .quotaExceeded:
                            self.serialQueue.async {
                                guard !self._quotaExceeded else { return }
                                self._quotaExceeded = true
                                DispatchQueue.main.async {
                                    self.isQuotaExceeded = true
                                    StorageManager.shared.pauseAllPendingLessons(uploadId: uploadId)
                                    print("⚠️ Quota exceeded (429) — batch paused. Tap Retry to resume.")
                                }
                            }

                        case .permanent(let code):
                            DispatchQueue.main.async {
                                StorageManager.shared.markLessonFailed(
                                    chunkIndex: chunk.index, uploadId: uploadId)
                            }
                            print("❌ Chunk \(chunk.index) permanent HTTP \(code) — marked as failed.")

                        case .transient:
                            print("❌ Chunk \(chunk.index) failed after retry — stays as placeholder.")
                        }
                    }

                    self.serialQueue.async {
                        if let plan = plan { results.append(plan) }
                        self.apiThrottle.signal()
                        group.leave()
                    }
                }
            }
        }

        group.notify(queue: .main) {
            completion(self.serialQueue.sync { results.sorted { $0.chunkIndex < $1.chunkIndex } })
        }
    }

    // MARK: - Private: Single Lesson with One Retry on Transient Error

    private func generateWithRetry(
        chunk: TextChunk,
        subject: String,
        uploadId: UUID,
        service: AIGenerationService,
        completion: @escaping (LessonPlan?, LessonGenerationError?) -> Void
    ) {
        service.generateLesson(chunk: chunk, subject: subject, uploadId: uploadId) { plan, error in
            if let plan = plan {
                completion(plan, nil)
                return
            }
            let err = error ?? .transient
            switch err {
            case .quotaExceeded, .permanent:
                completion(nil, err)
            case .transient:
                print("⚠️ Chunk \(chunk.index) transient — one retry in 3s…")
                DispatchQueue.global(qos: .utility).asyncAfter(deadline: .now() + 3) {
                    service.generateLesson(chunk: chunk, subject: subject, uploadId: uploadId) { p, e in
                        completion(p, e ?? (p == nil ? .transient : nil))
                    }
                }
            }
        }
    }

    // MARK: - Text Chunking (upload-based)

    func splitIntoChunks(text: String) -> [TextChunk] {
        let paragraphs = text
            .components(separatedBy: "\n")
            .map    { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }

        var chunks:    [TextChunk] = []
        var current:   [String]    = []
        var wordCount: Int          = 0
        var chunkIdx:  Int          = 0

        func flush() {
            guard !current.isEmpty else { return }
            chunks.append(TextChunk(index: chunkIdx, text: current.joined(separator: "\n")))
            chunkIdx  += 1
            current    = []
            wordCount  = 0
        }

        let wordsPerChunk = 700
        for para in paragraphs {
            let words = para.components(separatedBy: .whitespaces).filter { !$0.isEmpty }
            if wordCount + words.count > wordsPerChunk, wordCount > 0 { flush() }
            current.append(para)
            wordCount += words.count
            if wordCount >= wordsPerChunk { flush() }
        }
        flush()
        return chunks
    }
}
