import SwiftUI
#if canImport(FamilyControls)
import FamilyControls
#endif

// MARK: - BlockedAppsView
//
// Manages which apps Clavis controls.
// Requires the com.apple.developer.family-controls entitlement.
// While the entitlement is pending the UI shows an "unavailable" state but
// the earned-time countdown is still functional (visible in simulator).

struct BlockedAppsView: View {
    @ObservedObject private var screenTime = ScreenTimeManager.shared

    #if canImport(FamilyControls)
    @State private var showPicker = false
    #endif

    var body: some View {
        ZStack {
            Color(red: 0.07, green: 0.07, blue: 0.12).ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 24) {

                    Text("Blocked Apps")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.horizontal, 24)
                        .padding(.top, 60)

                    Text("Choose which apps are blocked while no earned time is active. They unlock automatically when you complete a lesson.")
                        .font(.system(size: 14))
                        .foregroundColor(.white.opacity(0.5))
                        .lineSpacing(4)
                        .padding(.horizontal, 24)

                    // Debug status strip — remove before release
                    debugStatusStrip
                        .padding(.horizontal, 24)

                    // Error card — shown when requestAuthorization fails
                    if !screenTime.lastAuthError.isEmpty {
                        authErrorCard
                            .padding(.horizontal, 24)
                    }

                    // Earned time banner (always shown when a window is active)
                    if screenTime.blockingMode == .earnedUnlocked {
                        earnedTimeBanner
                            .padding(.horizontal, 24)
                    }

                    // Authorization gate
                    switch screenTime.authorizationStatus {
                    case .notDetermined:
                        permissionCard

                    case .denied:
                        deniedCard

                    case .authorized:
                        #if canImport(FamilyControls)
                        authorizedContent
                        #else
                        stubCard
                        #endif
                    }

                    Spacer().frame(height: 60)
                }
            }
        }
        .navigationBarHidden(true)
        #if canImport(FamilyControls)
        .familyActivityPicker(isPresented: $showPicker, selection: $screenTime.activitySelection)
        .onChange(of: screenTime.activitySelection) { _, newSelection in
            screenTime.saveSelection(newSelection)
        }
        #endif
        .onAppear {
            print("🔵 [BlockedAppsView] appeared — authStatus=\(screenTime.authorizationStatus) mode=\(screenTime.blockingMode)")
            screenTime.syncAuthorizationStatus()
            screenTime.restoreState()
        }
    }

    // MARK: - Debug strip (always visible during development)

    private var debugStatusStrip: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("DEBUG")
                .font(.system(size: 10, weight: .bold))
                .foregroundColor(.yellow.opacity(0.6))
                .kerning(1)
            #if canImport(FamilyControls)
            Text("FamilyControls: canImport ✓")
                .font(.system(size: 12, design: .monospaced))
                .foregroundColor(.yellow.opacity(0.8))
            Text("FC raw status: \(screenTime.rawFCStatus)")
                .font(.system(size: 12, design: .monospaced))
                .foregroundColor(.yellow.opacity(0.8))
            #else
            Text("FamilyControls: STUB (entitlement missing)")
                .font(.system(size: 12, design: .monospaced))
                .foregroundColor(.orange)
            #endif
            Text("Local auth: \(String(describing: screenTime.authorizationStatus))")
                .font(.system(size: 12, design: .monospaced))
                .foregroundColor(.yellow.opacity(0.8))
            Text("Blocking mode: \(String(describing: screenTime.blockingMode))")
                .font(.system(size: 12, design: .monospaced))
                .foregroundColor(.yellow.opacity(0.8))
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.black.opacity(0.4))
        .cornerRadius(10)
        .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.yellow.opacity(0.2), lineWidth: 1))
    }

    // MARK: - Auth Error Card

    private var authErrorCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 8) {
                Image(systemName: "exclamationmark.triangle.fill")
                    .foregroundColor(.red)
                    .font(.system(size: 14))
                Text("Authorization failed")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.red)
            }
            Text(screenTime.lastAuthError)
                .font(.system(size: 12, design: .monospaced))
                .foregroundColor(.red.opacity(0.8))
                .fixedSize(horizontal: false, vertical: true)
            Text("Most likely cause: the Family Controls entitlement (com.apple.developer.family-controls) is not yet added in Xcode → Signing & Capabilities.")
                .font(.system(size: 12))
                .foregroundColor(.white.opacity(0.5))
                .fixedSize(horizontal: false, vertical: true)
                .lineSpacing(3)
        }
        .padding(14)
        .background(Color.red.opacity(0.08))
        .cornerRadius(12)
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.red.opacity(0.25), lineWidth: 1))
    }

    // MARK: - Earned Time Banner

    private var earnedTimeBanner: some View {
        HStack(spacing: 14) {
            ZStack {
                Circle()
                    .fill(Color(red: 0.2, green: 0.85, blue: 0.5).opacity(0.15))
                    .frame(width: 46, height: 46)
                Image(systemName: "lock.open.fill")
                    .foregroundColor(Color(red: 0.2, green: 0.85, blue: 0.5))
                    .font(.system(size: 20))
            }
            VStack(alignment: .leading, spacing: 3) {
                Text("Apps currently unlocked")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(.white)
                Text("Blocking resumes automatically when timer ends")
                    .font(.system(size: 13))
                    .foregroundColor(.white.opacity(0.5))
            }
            Spacer()
            Text(screenTime.remainingFormatted)
                .font(.system(size: 20, weight: .bold, design: .monospaced))
                .foregroundColor(Color(red: 0.2, green: 0.85, blue: 0.5))
        }
        .padding(14)
        .background(Color(red: 0.2, green: 0.85, blue: 0.5).opacity(0.08))
        .cornerRadius(16)
        .overlay(RoundedRectangle(cornerRadius: 16)
            .stroke(Color(red: 0.2, green: 0.85, blue: 0.5).opacity(0.2), lineWidth: 1))
    }

    // MARK: - Permission Cards

    private var permissionCard: some View {
        VStack(spacing: 20) {
            Image(systemName: "lock.shield.fill")
                .font(.system(size: 44))
                .foregroundColor(Color(red: 0.42, green: 0.32, blue: 1.0))

            VStack(spacing: 8) {
                Text("Screen Time Permission")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(.white)
                Text("Tapping the button below shows an in-app system dialog asking "Allow Clavis to use Screen Time?". This is NOT a Settings toggle — the dialog appears right inside the app.")
                    .font(.system(size: 14))
                    .foregroundColor(.white.opacity(0.6))
                    .multilineTextAlignment(.center)
                    .lineSpacing(4)
            }

            Button {
                print("🟡 [BlockedAppsView] Grant Permission tapped")
                Task {
                    await screenTime.requestAuthorization()
                    print("🟡 [BlockedAppsView] requestAuthorization returned — status=\(screenTime.authorizationStatus)")
                }
            } label: {
                Text("Grant Permission")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 52)
                    .background(Color(red: 0.42, green: 0.32, blue: 1.0))
                    .cornerRadius(14)
            }
        }
        .padding(24)
        .background(Color(red: 0.12, green: 0.12, blue: 0.19))
        .cornerRadius(20)
        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white.opacity(0.08), lineWidth: 1))
        .padding(.horizontal, 24)
    }

    private var deniedCard: some View {
        VStack(spacing: 16) {
            Image(systemName: "exclamationmark.shield.fill")
                .font(.system(size: 36))
                .foregroundColor(.orange)

            VStack(spacing: 6) {
                Text("Permission Required")
                    .font(.system(size: 17, weight: .bold))
                    .foregroundColor(.white)
                Text("Go to Settings → Screen Time → Clavis and grant access to enable app blocking.")
                    .font(.system(size: 14))
                    .foregroundColor(.white.opacity(0.6))
                    .multilineTextAlignment(.center)
                    .lineSpacing(4)
            }

            Button {
                if let url = URL(string: UIApplication.openSettingsURLString) {
                    UIApplication.shared.open(url)
                }
            } label: {
                Text("Open Settings")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(Color(red: 0.42, green: 0.32, blue: 1.0))
            }
        }
        .padding(24)
        .background(Color(red: 0.12, green: 0.12, blue: 0.19))
        .cornerRadius(20)
        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.orange.opacity(0.2), lineWidth: 1))
        .padding(.horizontal, 24)
    }

    private var stubCard: some View {
        VStack(spacing: 12) {
            Image(systemName: "hammer.fill")
                .font(.system(size: 32))
                .foregroundColor(.yellow)
            Text("Entitlement Pending")
                .font(.system(size: 17, weight: .bold))
                .foregroundColor(.white)
            Text("The com.apple.developer.family-controls entitlement must be approved by Apple before real app blocking is active. The earned-time countdown works now.")
                .font(.system(size: 14))
                .foregroundColor(.white.opacity(0.6))
                .multilineTextAlignment(.center)
                .lineSpacing(4)
        }
        .padding(24)
        .background(Color(red: 0.12, green: 0.12, blue: 0.19))
        .cornerRadius(20)
        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.yellow.opacity(0.2), lineWidth: 1))
        .padding(.horizontal, 24)
    }

    // MARK: - Authorized Content

    #if canImport(FamilyControls)
    private var authorizedContent: some View {
        VStack(spacing: 20) {

            // App picker button
            VStack(alignment: .leading, spacing: 10) {
                Text("SELECT APPS")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(.white.opacity(0.3))
                    .kerning(0.8)

                Button { showPicker = true } label: {
                    HStack(spacing: 14) {
                        ZStack {
                            Circle()
                                .fill(Color(red: 0.42, green: 0.32, blue: 1.0).opacity(0.15))
                                .frame(width: 46, height: 46)
                            Image(systemName: "apps.iphone")
                                .foregroundColor(Color(red: 0.42, green: 0.32, blue: 1.0))
                                .font(.system(size: 20))
                        }
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Choose Apps to Block")
                                .font(.system(size: 15, weight: .semibold))
                                .foregroundColor(.white)
                            Text(screenTime.selectedAppCount == 0
                                 ? "None selected"
                                 : "\(screenTime.selectedAppCount) item\(screenTime.selectedAppCount == 1 ? "" : "s") selected")
                                .font(.system(size: 13))
                                .foregroundColor(.white.opacity(0.5))
                        }
                        Spacer()
                        Image(systemName: "chevron.right")
                            .font(.system(size: 13))
                            .foregroundColor(.white.opacity(0.3))
                    }
                    .padding(14)
                    .background(Color(red: 0.12, green: 0.12, blue: 0.19))
                    .cornerRadius(16)
                    .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.08), lineWidth: 1))
                }
            }
            .padding(.horizontal, 24)

            // Blocking status
            VStack(alignment: .leading, spacing: 10) {
                Text("STATUS")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(.white.opacity(0.3))
                    .kerning(0.8)

                HStack(spacing: 14) {
                    ZStack {
                        Circle()
                            .fill(statusColor.opacity(0.15))
                            .frame(width: 46, height: 46)
                        Image(systemName: statusIcon)
                            .foregroundColor(statusColor)
                            .font(.system(size: 20))
                    }
                    VStack(alignment: .leading, spacing: 3) {
                        Text(statusTitle)
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundColor(.white)
                        Text(statusSubtitle)
                            .font(.system(size: 13))
                            .foregroundColor(.white.opacity(0.5))
                    }
                    Spacer()
                    if screenTime.blockingMode == .earnedUnlocked {
                        Text(screenTime.remainingFormatted)
                            .font(.system(size: 16, weight: .bold, design: .monospaced))
                            .foregroundColor(Color(red: 0.2, green: 0.85, blue: 0.5))
                    } else {
                        Circle()
                            .fill(statusColor)
                            .frame(width: 10, height: 10)
                    }
                }
                .padding(14)
                .background(Color(red: 0.12, green: 0.12, blue: 0.19))
                .cornerRadius(16)
                .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.08), lineWidth: 1))
            }
            .padding(.horizontal, 24)

            // ── QA: Test blocking ──────────────────────────────────────────
            // Remove this section before release.
            // Use it to confirm shields actually activate on your device.
            VStack(alignment: .leading, spacing: 10) {
                Text("TEST BLOCKING")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(.orange.opacity(0.7))
                    .kerning(0.8)

                Text("1. Select at least one app above\n2. Tap "Block Now" — then press Home and open that app\n3. You should see a shield screen instead of the app\n4. Tap "Clear Block" to unblock without earning time")
                    .font(.system(size: 12))
                    .foregroundColor(.white.opacity(0.5))
                    .lineSpacing(4)
                    .fixedSize(horizontal: false, vertical: true)

                HStack(spacing: 12) {
                    Button {
                        print("🧪 Block Now tapped — selectedAppCount=\(screenTime.selectedAppCount)")
                        screenTime.testApplyBlock()
                    } label: {
                        Text("🔒 Block Now")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .frame(height: 44)
                            .background(Color.orange.opacity(0.8))
                            .cornerRadius(12)
                    }
                    .disabled(screenTime.selectedAppCount == 0)

                    Button {
                        print("🧪 Clear Block tapped")
                        screenTime.testClearBlock()
                    } label: {
                        Text("🔓 Clear Block")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(.orange)
                            .frame(maxWidth: .infinity)
                            .frame(height: 44)
                            .background(Color.orange.opacity(0.12))
                            .cornerRadius(12)
                            .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.orange.opacity(0.3), lineWidth: 1))
                    }
                }
            }
            .padding(.horizontal, 24)

            // How it works
            VStack(alignment: .leading, spacing: 10) {
                Text("HOW IT WORKS")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(.white.opacity(0.3))
                    .kerning(0.8)

                VStack(spacing: 0) {
                    howItWorksRow(icon: "book.fill",       color: Color(red: 0.42, green: 0.32, blue: 1.0),
                                  title: "Study a lesson",    subtitle: "Read and answer quiz questions")
                    Divider().background(Color.white.opacity(0.06))
                    howItWorksRow(icon: "lock.open.fill",   color: Color(red: 0.2, green: 0.85, blue: 0.5),
                                  title: "Earn screen time",  subtitle: "Every session unlocks selected apps")
                    Divider().background(Color.white.opacity(0.06))
                    howItWorksRow(icon: "clock.fill",       color: Color(red: 1.0, green: 0.6, blue: 0.2),
                                  title: "Timer counts down", subtitle: "Apps re-block automatically when time runs out")
                }
                .padding(4)
                .background(Color(red: 0.12, green: 0.12, blue: 0.19))
                .cornerRadius(16)
                .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.08), lineWidth: 1))
            }
            .padding(.horizontal, 24)
        }
    }

    private func howItWorksRow(icon: String, color: Color, title: String, subtitle: String) -> some View {
        HStack(spacing: 14) {
            ZStack {
                Circle().fill(color.opacity(0.12)).frame(width: 36, height: 36)
                Image(systemName: icon).foregroundColor(color).font(.system(size: 15))
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.system(size: 14, weight: .semibold)).foregroundColor(.white)
                Text(subtitle).font(.system(size: 12)).foregroundColor(.white.opacity(0.4))
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
    }

    // MARK: Status helpers

    private var statusIcon: String {
        switch screenTime.blockingMode {
        case .earnedUnlocked: return "lock.open.fill"
        case .blocked:        return screenTime.selectedAppCount > 0 ? "lock.fill" : "lock.slash.fill"
        case .unavailable:    return "lock.slash.fill"
        }
    }

    private var statusColor: Color {
        switch screenTime.blockingMode {
        case .earnedUnlocked: return Color(red: 0.2, green: 0.85, blue: 0.5)
        case .blocked:
            return screenTime.selectedAppCount > 0
                ? Color(red: 0.42, green: 0.32, blue: 1.0)
                : .gray
        case .unavailable:    return .gray
        }
    }

    private var statusTitle: String {
        switch screenTime.blockingMode {
        case .earnedUnlocked: return "Apps Unlocked"
        case .blocked:
            return screenTime.selectedAppCount > 0
                ? "Blocking Active"
                : "No Apps Selected"
        case .unavailable:    return "Blocking Unavailable"
        }
    }

    private var statusSubtitle: String {
        switch screenTime.blockingMode {
        case .earnedUnlocked:
            return "\(screenTime.remainingFormatted) of earned time remaining"
        case .blocked:
            if screenTime.selectedAppCount > 0 {
                return "\(screenTime.selectedAppCount) item\(screenTime.selectedAppCount == 1 ? "" : "s") shielded · complete a lesson to unlock"
            } else {
                return "Select apps above to start blocking"
            }
        case .unavailable:
            return "Grant Screen Time permission to enable blocking"
        }
    }
    #endif
}

#Preview {
    BlockedAppsView()
}
