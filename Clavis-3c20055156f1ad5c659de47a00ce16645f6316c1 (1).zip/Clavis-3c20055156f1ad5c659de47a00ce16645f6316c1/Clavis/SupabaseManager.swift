import Foundation
import Combine

class SupabaseManager: ObservableObject {
    static let shared = SupabaseManager()

    @Published var isLoggedIn = false
    @Published var userEmail  = ""
    @Published var userName   = ""
    /// Supabase user UUID — used by ContentView (.id), StorageManager,
    /// StatsManager, and ScreenTimeManager to namespace all user data.
    @Published var userId     = ""

    private let supabaseURL = "https://qqmnszuujvjxyodtgqkc.supabase.co"
    private let supabaseKey = "sb_publishable_cAacFNyMGyHEzBShBYGoyg_NT_xCTqd"

    // UserDefaults keys
    private let tokenKey        = "supabase_access_token"
    private let refreshTokenKey = "supabase_refresh_token"
    private let userIdKey       = "supabase_user_id"
    private let emailKey        = "userEmail"
    private let nameKey         = "userName"
    private let isLoggedInKey   = "isLoggedIn"

    // MARK: - Sign Up

    /// Completion: (success, errorMessage)
    /// errorMessage is non-nil on failure — it contains the real backend reason.
    func signUp(name: String, email: String, password: String,
                completion: @escaping (Bool, String?) -> Void) {
        guard let url = URL(string: "\(supabaseURL)/auth/v1/signup") else {
            completion(false, "Invalid server URL."); return
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(supabaseKey,        forHTTPHeaderField: "apikey")
        request.httpBody = try? JSONSerialization.data(withJSONObject: [
            "email": email, "password": password,
            "data": ["full_name": name]
        ])

        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                // Network-level failure
                if let error = error {
                    let msg = "Network error: \(error.localizedDescription)"
                    print("❌ [Auth] signUp network error: \(error)")
                    completion(false, msg); return
                }

                guard let data = data, let http = response as? HTTPURLResponse else {
                    completion(false, "No response from server."); return
                }

                // Always log the raw response so we can see what Supabase returned.
                let rawBody = String(data: data, encoding: .utf8) ?? "(unreadable)"
                print("🔵 [Auth] signUp HTTP \(http.statusCode): \(rawBody)")

                guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                    completion(false, "Unexpected response format (HTTP \(http.statusCode)).")
                    return
                }

                // Non-2xx → extract Supabase's real error message
                // Supabase error shape: { "code": 422, "error_code": "email_exists", "msg": "..." }
                // or OAuth shape:       { "error": "...", "error_description": "..." }
                if !(200...299).contains(http.statusCode) {
                    let msg = json["msg"]               as? String
                           ?? json["message"]           as? String
                           ?? json["error_description"] as? String
                           ?? json["error"]             as? String
                           ?? "Sign up failed (HTTP \(http.statusCode))."
                    print("❌ [Auth] signUp failed: \(msg)")
                    completion(false, msg); return
                }

                // HTTP 200 but no access_token → email confirmation is required.
                // Supabase sends a confirmation link; user must verify before signing in.
                let token = json["access_token"] as? String ?? ""
                if token.isEmpty {
                    print("📧 [Auth] signUp — confirmation email sent to \(email)")
                    completion(false,
                        "Account created! Check your email to confirm it, then sign in.")
                    return
                }

                let refreshToken = json["refresh_token"] as? String ?? ""
                let userObj      = json["user"]          as? [String: Any]
                let uid          = userObj?["id"]        as? String ?? ""
                let meta         = userObj?["user_metadata"] as? [String: Any]
                let fullName     = meta?["full_name"]    as? String ?? name

                print("✅ [Auth] signUp — uid=\(uid.prefix(8))… email=\(email)")
                self.saveSession(userId: uid, email: email, name: fullName,
                                 token: token, refreshToken: refreshToken)
                completion(true, nil)
            }
        }.resume()
    }

    // MARK: - Sign In

    /// Completion: (success, errorMessage)
    func signIn(email: String, password: String,
                completion: @escaping (Bool, String?) -> Void) {
        guard let url = URL(string: "\(supabaseURL)/auth/v1/token?grant_type=password") else {
            completion(false, "Invalid server URL."); return
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(supabaseKey,        forHTTPHeaderField: "apikey")
        request.httpBody = try? JSONSerialization.data(withJSONObject: [
            "email": email, "password": password
        ])

        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    let msg = "Network error: \(error.localizedDescription)"
                    print("❌ [Auth] signIn network error: \(error)")
                    completion(false, msg); return
                }

                guard let data = data, let http = response as? HTTPURLResponse else {
                    completion(false, "No response from server."); return
                }

                let rawBody = String(data: data, encoding: .utf8) ?? "(unreadable)"
                print("🔵 [Auth] signIn HTTP \(http.statusCode): \(rawBody)")

                guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                    completion(false, "Unexpected response format (HTTP \(http.statusCode)).")
                    return
                }

                if http.statusCode != 200 {
                    let msg = json["error_description"] as? String
                           ?? json["msg"]               as? String
                           ?? json["message"]           as? String
                           ?? json["error"]             as? String
                           ?? "Sign in failed (HTTP \(http.statusCode))."
                    print("❌ [Auth] signIn failed: \(msg)")
                    completion(false, msg); return
                }

                guard let token = json["access_token"] as? String, !token.isEmpty else {
                    completion(false, "Sign in failed: no session token returned.")
                    return
                }

                let refreshToken = json["refresh_token"] as? String ?? ""
                let userObj      = json["user"]          as? [String: Any]
                let uid          = userObj?["id"]        as? String ?? ""
                let meta         = userObj?["user_metadata"] as? [String: Any]
                let fullName     = meta?["full_name"]    as? String ?? ""

                print("✅ [Auth] signIn — uid=\(uid.prefix(8))… email=\(email)")
                self.saveSession(userId: uid, email: email, name: fullName,
                                 token: token, refreshToken: refreshToken)
                completion(true, nil)
            }
        }.resume()
    }

    // MARK: - Leaderboard / Stats Sync

    /// Upserts the current user's stats into the `user_stats` table.
    /// Called by StatsManager after every completed session and after weekly reset.
    /// Fire-and-forget — failures are logged but not surfaced to the user.
    func upsertStats(xp: Int, weeklyXP: Int, streak: Int, sessions: Int) {
        guard !userId.isEmpty, let token = authorizationHeader else {
            print("⚠️ [Stats] upsertStats skipped — no userId or token")
            return
        }
        guard let url = URL(string: "\(supabaseURL)/rest/v1/user_stats") else { return }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json",         forHTTPHeaderField: "Content-Type")
        request.setValue(supabaseKey,                forHTTPHeaderField: "apikey")
        request.setValue(token,                      forHTTPHeaderField: "Authorization")
        // merge-duplicates → INSERT … ON CONFLICT (user_id) DO UPDATE
        request.setValue("resolution=merge-duplicates", forHTTPHeaderField: "Prefer")

        let iso  = ISO8601DateFormatter()
        let body: [String: Any] = [
            "user_id":      userId,
            "display_name": userName.isEmpty ? userEmail : userName,
            "xp":           xp,
            "weekly_xp":    weeklyXP,
            "streak":       streak,
            "sessions":     sessions,
            "updated_at":   iso.string(from: Date())
        ]
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("❌ [Stats] upsertStats error: \(error.localizedDescription)")
                return
            }
            if let http = response as? HTTPURLResponse {
                print("🔵 [Stats] upsertStats HTTP \(http.statusCode)")
            }
        }.resume()
    }

    /// Fetches the top 50 users by weekly_xp, then appends the current user
    /// if they are not already in the list.
    /// Completion is called on the main thread.
    func fetchLeaderboard(completion: @escaping ([FriendEntry]) -> Void) {
        guard let url = URL(string: "\(supabaseURL)/rest/v1/user_stats?order=weekly_xp.desc&limit=50") else {
            completion([]); return
        }
        var request = URLRequest(url: url)
        request.setValue(supabaseKey, forHTTPHeaderField: "apikey")
        if let token = authorizationHeader {
            request.setValue(token, forHTTPHeaderField: "Authorization")
        }

        URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
            DispatchQueue.main.async {
                guard let self else { completion([]); return }

                if let error = error {
                    print("❌ [Leaderboard] fetch error: \(error.localizedDescription)")
                    completion([]); return
                }
                guard
                    let data = data,
                    let http = response as? HTTPURLResponse
                else { completion([]); return }

                let rawBody = String(data: data, encoding: .utf8) ?? "(unreadable)"
                print("🔵 [Leaderboard] HTTP \(http.statusCode): \(rawBody.prefix(200))")

                guard
                    http.statusCode == 200,
                    let rows = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]]
                else { completion([]); return }

                // Map rows → FriendEntry (rank assigned after sorting)
                var entries: [FriendEntry] = rows.map { row in
                    let uid = row["user_id"] as? String ?? ""
                    return FriendEntry(
                        rank:     0,
                        name:     row["display_name"] as? String ?? "Unknown",
                        xp:       row["xp"]        as? Int ?? 0,
                        weeklyXP: row["weekly_xp"] as? Int ?? 0,
                        streak:   row["streak"]    as? Int ?? 0,
                        sessions: row["sessions"]  as? Int ?? 0,
                        isYou:    uid == self.userId
                    )
                }

                // If the current user isn't in the top-50, append them from local stats.
                let currentUserInList = entries.contains { $0.isYou }
                if !currentUserInList && !self.userId.isEmpty {
                    let stats = StatsManager.shared
                    entries.append(FriendEntry(
                        rank:     0,
                        name:     self.userName.isEmpty ? self.userEmail : self.userName,
                        xp:       stats.totalXP,
                        weeklyXP: stats.weeklyXP,
                        streak:   stats.currentStreak,
                        sessions: stats.totalSessions,
                        isYou:    true
                    ))
                }

                // Sort by weeklyXP descending, then assign ranks.
                let ranked = entries
                    .sorted { $0.weeklyXP > $1.weeklyXP }
                    .enumerated()
                    .map { idx, e in
                        FriendEntry(rank: idx + 1, name: e.name, xp: e.xp,
                                    weeklyXP: e.weeklyXP, streak: e.streak,
                                    sessions: e.sessions, isYou: e.isYou)
                    }

                completion(ranked)
            }
        }.resume()
    }

    // MARK: - Password Reset

    /// Sends a password-reset email via Supabase.
    /// Supabase endpoint: POST /auth/v1/recover
    /// Always returns 200 even if the email doesn't exist (security by design).
    func resetPassword(email: String, completion: @escaping (Bool, String?) -> Void) {
        guard let url = URL(string: "\(supabaseURL)/auth/v1/recover") else {
            completion(false, "Invalid server URL."); return
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(supabaseKey,        forHTTPHeaderField: "apikey")
        request.httpBody = try? JSONSerialization.data(withJSONObject: ["email": email])

        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    let msg = "Network error: \(error.localizedDescription)"
                    print("❌ [Auth] resetPassword network error: \(error)")
                    completion(false, msg); return
                }
                guard let http = response as? HTTPURLResponse else {
                    completion(false, "No response from server."); return
                }
                let rawBody = data.flatMap { String(data: $0, encoding: .utf8) } ?? "(empty)"
                print("🔵 [Auth] resetPassword HTTP \(http.statusCode): \(rawBody)")

                if (200...299).contains(http.statusCode) {
                    completion(true, nil)
                } else {
                    let json = data.flatMap { try? JSONSerialization.jsonObject(with: $0) as? [String: Any] }
                    let msg  = json?["msg"]     as? String
                           ?? json?["message"]  as? String
                           ?? "Reset failed (HTTP \(http.statusCode))."
                    completion(false, msg)
                }
            }
        }.resume()
    }

    // MARK: - Sign Out

    func signOut() {
        print("🔴 [Auth] signOut — clearing uid=\(userId.prefix(8))…")

        StorageManager.shared.clearAll()
        StatsManager.shared.clearAll()
        Task { @MainActor in ScreenTimeManager.shared.clearUserState() }

        isLoggedIn = false
        userId     = ""
        userEmail  = ""
        userName   = ""

        for key in [tokenKey, refreshTokenKey, userIdKey, emailKey, nameKey, isLoggedInKey] {
            UserDefaults.standard.removeObject(forKey: key)
        }
    }

    // MARK: - Session Restoration (cold launch)

    func checkSession() {
        guard
            let token = UserDefaults.standard.string(forKey: tokenKey),
            !token.isEmpty
        else { return }

        let storedId = UserDefaults.standard.string(forKey: userIdKey) ?? ""
        userEmail    = UserDefaults.standard.string(forKey: emailKey)  ?? ""
        userName     = UserDefaults.standard.string(forKey: nameKey)   ?? ""
        userId       = storedId
        isLoggedIn   = true

        print("🔵 [Auth] checkSession — restored uid=\(storedId.prefix(8))…")

        if !storedId.isEmpty {
            StorageManager.shared.loadData(for: storedId)
            StatsManager.shared.loadData(for: storedId)
            Task { @MainActor in
                ScreenTimeManager.shared.restoreState(for: storedId)
            }
        }

        verifyToken(token)
    }

    // MARK: - Token Verification & Refresh

    private func verifyToken(_ token: String) {
        guard let url = URL(string: "\(supabaseURL)/auth/v1/user") else { return }
        var request = URLRequest(url: url)
        request.setValue(supabaseKey,       forHTTPHeaderField: "apikey")
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")

        URLSession.shared.dataTask(with: request) { data, response, _ in
            DispatchQueue.main.async {
                guard let http = response as? HTTPURLResponse else { return }

                if http.statusCode == 401 {
                    self.refreshAccessToken()
                    return
                }
                guard
                    http.statusCode == 200,
                    let data = data,
                    let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any]
                else { return }

                let uid  = json["id"] as? String ?? self.userId
                let meta = json["user_metadata"] as? [String: Any]
                if let name = meta?["full_name"] as? String, !name.isEmpty {
                    self.userName = name
                    UserDefaults.standard.set(name, forKey: self.nameKey)
                }
                if !uid.isEmpty, uid != self.userId {
                    print("⚠️ [Auth] verifyToken — uid mismatch, reloading for \(uid.prefix(8))…")
                    self.userId = uid
                    UserDefaults.standard.set(uid, forKey: self.userIdKey)
                    StorageManager.shared.loadData(for: uid)
                    StatsManager.shared.loadData(for: uid)
                    Task { @MainActor in
                        ScreenTimeManager.shared.restoreState(for: uid)
                    }
                }
            }
        }.resume()
    }

    private func refreshAccessToken() {
        guard
            let refresh = UserDefaults.standard.string(forKey: refreshTokenKey),
            !refresh.isEmpty,
            let url = URL(string: "\(supabaseURL)/auth/v1/token?grant_type=refresh_token")
        else { signOut(); return }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(supabaseKey,        forHTTPHeaderField: "apikey")
        request.httpBody = try? JSONSerialization.data(withJSONObject: ["refresh_token": refresh])

        URLSession.shared.dataTask(with: request) { data, _, _ in
            DispatchQueue.main.async {
                guard
                    let data     = data,
                    let json     = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                    let newToken = json["access_token"] as? String
                else { self.signOut(); return }

                let newRefresh = json["refresh_token"] as? String ?? refresh
                UserDefaults.standard.set(newToken,   forKey: self.tokenKey)
                UserDefaults.standard.set(newRefresh, forKey: self.refreshTokenKey)
            }
        }.resume()
    }

    // MARK: - Internal session commit

    private func saveSession(userId: String, email: String, name: String,
                             token: String, refreshToken: String) {
        if !self.userId.isEmpty, self.userId != userId {
            print("🔄 [Auth] account switch \(self.userId.prefix(8))… → \(userId.prefix(8))…")
            StorageManager.shared.clearAll()
            StatsManager.shared.clearAll()
            Task { @MainActor in ScreenTimeManager.shared.clearUserState() }
        }

        self.userId     = userId
        self.userEmail  = email
        self.userName   = name
        self.isLoggedIn = true

        UserDefaults.standard.set(true,        forKey: isLoggedInKey)
        UserDefaults.standard.set(userId,       forKey: userIdKey)
        UserDefaults.standard.set(email,        forKey: emailKey)
        UserDefaults.standard.set(name,         forKey: nameKey)
        UserDefaults.standard.set(token,        forKey: tokenKey)
        UserDefaults.standard.set(refreshToken, forKey: refreshTokenKey)

        if !userId.isEmpty {
            StorageManager.shared.loadData(for: userId)
            StatsManager.shared.loadData(for: userId)
            Task { @MainActor in
                ScreenTimeManager.shared.restoreState(for: userId)
            }
        }
    }

    // MARK: - Helpers

    var authorizationHeader: String? {
        guard let token = UserDefaults.standard.string(forKey: tokenKey),
              !token.isEmpty else { return nil }
        return "Bearer \(token)"
    }
}
