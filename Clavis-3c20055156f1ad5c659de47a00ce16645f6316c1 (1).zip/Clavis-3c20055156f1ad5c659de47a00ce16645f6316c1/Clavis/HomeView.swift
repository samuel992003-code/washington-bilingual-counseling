import SwiftUI

struct HomeView: View {
    @ObservedObject var stats       = StatsManager.shared
    @ObservedObject var storage     = StorageManager.shared
    @ObservedObject var screenTime  = ScreenTimeManager.shared
    @State private var showQuiz          = false
    @State private var selectedSubject: SubjectItem? = nil

    // MARK: - Dynamic subjects from real uploads

    var dynamicSubjects: [SubjectItem] {
        let names = Array(Set(storage.savedUploads.map { $0.subject })).sorted()
        return names.map { name in
            SubjectItem(
                emoji:     emojiForSubject(name),
                name:      name,
                questions: questionsCount(for: name),
                color:     colorForSubject(name)
            )
        }
    }

    private func questionsCount(for name: String) -> Int {
        storage.savedUploads
            .filter { $0.subject.lowercased() == name.lowercased() }
            .reduce(0) { $0 + $1.questionCount }
    }

    private func lessonsCount(for name: String) -> Int {
        storage.getLessons(for: name).count
    }

    private func isProcessing(for name: String) -> Bool {
        storage.savedUploads
            .filter { $0.subject.lowercased() == name.lowercased() }
            .contains { $0.status == .processing }
    }

    private func emojiForSubject(_ subject: String) -> String {
        switch subject.lowercased() {
        case "biology":    return "🧬"
        case "finance":    return "💰"
        case "history":    return "📜"
        case "chemistry":  return "⚗️"
        case "math":       return "📐"
        case "physics":    return "⚡️"
        case "english":    return "📝"
        case "psychology": return "🧠"
        default:           return "📚"
        }
    }

    private func colorForSubject(_ subject: String) -> Color {
        switch subject.lowercased() {
        case "biology":    return Color(red: 0.42, green: 0.32, blue: 1.0)
        case "finance":    return Color(red: 0.2,  green: 0.85, blue: 0.5)
        case "history":    return Color(red: 1.0,  green: 0.6,  blue: 0.2)
        case "chemistry":  return Color(red: 1.0,  green: 0.35, blue: 0.35)
        case "math":       return Color(red: 0.2,  green: 0.7,  blue: 1.0)
        case "physics":    return Color(red: 1.0,  green: 0.8,  blue: 0.2)
        case "english":    return Color(red: 0.9,  green: 0.4,  blue: 0.8)
        case "psychology": return Color(red: 0.5,  green: 0.8,  blue: 0.9)
        default:           return Color(red: 0.62, green: 0.32, blue: 1.0)
        }
    }

    // MARK: - Greeting

    var greeting: String {
        let hour = Calendar.current.component(.hour, from: Date())
        switch hour {
        case 5..<12:  return "Good morning 👋"
        case 12..<17: return "Good afternoon 👋"
        case 17..<22: return "Good evening 👋"
        default:      return "Hey there 👋"
        }
    }

    // MARK: - Body

    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 0.07, green: 0.07, blue: 0.12)
                    .ignoresSafeArea()

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 22) {

                        // Header
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(greeting)
                                    .font(.system(size: 14))
                                    .foregroundColor(.white.opacity(0.6))
                                Text("Clavis")
                                    .font(.system(size: 26, weight: .bold))
                                    .foregroundColor(.white)
                            }
                            Spacer()
                            HStack(spacing: 6) {
                                Image(systemName: "bolt.fill")
                                    .font(.system(size: 12))
                                    .foregroundColor(.yellow)
                                Text("\(stats.totalXP) XP")
                                    .font(.system(size: 14, weight: .semibold))
                                    .foregroundColor(.yellow)
                            }
                            .padding(.horizontal, 14)
                            .padding(.vertical, 8)
                            .background(Color.yellow.opacity(0.12))
                            .cornerRadius(20)
                        }
                        .padding(.horizontal, 24)
                        .padding(.top, 60)

                        // Stats row
                        HStack(spacing: 12) {
                            StatBox(icon: "flame.fill",            color: Color(red: 1.0, green: 0.6,  blue: 0.2),  value: "\(stats.currentStreak)",       label: "Day streak")
                            StatBox(icon: "clock.fill",            color: Color(red: 0.42, green: 0.32, blue: 1.0), value: "\(stats.minutesEarnedToday)m", label: "Earned today")
                            StatBox(icon: "checkmark.circle.fill", color: Color(red: 0.2,  green: 0.85, blue: 0.5),  value: "\(stats.totalSessions)",       label: "Sessions")
                        }
                        .padding(.horizontal, 24)

                        // Earned time banner — visible whenever a timer is running
                        if screenTime.blockingMode == .earnedUnlocked {
                            earnedTimeBanner
                                .padding(.horizontal, 24)
                        }

                        // XP bar
                        VStack(alignment: .leading, spacing: 10) {
                            HStack {
                                Text("Level \(stats.level)")
                                    .font(.system(size: 15, weight: .semibold))
                                    .foregroundColor(.white)
                                Spacer()
                                Text("\(stats.xpInCurrentLevel) / 100 XP")
                                    .font(.system(size: 13))
                                    .foregroundColor(.white.opacity(0.5))
                            }
                            GeometryReader { geo in
                                ZStack(alignment: .leading) {
                                    RoundedRectangle(cornerRadius: 6)
                                        .fill(Color(red: 0.42, green: 0.32, blue: 1.0).opacity(0.15))
                                        .frame(height: 8)
                                    RoundedRectangle(cornerRadius: 6)
                                        .fill(Color(red: 0.42, green: 0.32, blue: 1.0))
                                        .frame(width: max(8, geo.size.width * stats.xpProgress), height: 8)
                                        .animation(.spring(response: 0.6), value: stats.xpProgress)
                                }
                            }
                            .frame(height: 8)
                        }
                        .padding(16)
                        .background(Color(red: 0.12, green: 0.12, blue: 0.19))
                        .cornerRadius(16)
                        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.08), lineWidth: 1))
                        .padding(.horizontal, 24)

                        // Start session button
                        Button { showQuiz = true } label: {
                            HStack(spacing: 16) {
                                VStack(alignment: .leading, spacing: 5) {
                                    Text("Start a study session")
                                        .font(.system(size: 17, weight: .semibold))
                                        .foregroundColor(.white)
                                    Text("Answer 2 questions → earn 10 min")
                                        .font(.system(size: 13))
                                        .foregroundColor(.white.opacity(0.7))
                                }
                                Spacer()
                                ZStack {
                                    Circle().fill(.white.opacity(0.15)).frame(width: 44, height: 44)
                                    Image(systemName: "arrow.right")
                                        .font(.system(size: 18, weight: .semibold))
                                        .foregroundColor(.white)
                                }
                            }
                            .padding(.horizontal, 22)
                            .padding(.vertical, 20)
                            .background(
                                LinearGradient(
                                    colors: [Color(red: 0.42, green: 0.32, blue: 1.0), Color(red: 0.62, green: 0.32, blue: 1.0)],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                            .cornerRadius(20)
                        }
                        .padding(.horizontal, 24)

                        // Subjects — built from real uploaded content
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Your subjects")
                                .font(.system(size: 17, weight: .semibold))
                                .foregroundColor(.white)

                            if dynamicSubjects.isEmpty {
                                VStack(spacing: 10) {
                                    Text("📂")
                                        .font(.system(size: 40))
                                    Text("No subjects yet")
                                        .font(.system(size: 15, weight: .semibold))
                                        .foregroundColor(.white.opacity(0.6))
                                    Text("Upload your notes in the Upload tab\nand your subjects will appear here.")
                                        .font(.system(size: 13))
                                        .foregroundColor(.white.opacity(0.35))
                                        .multilineTextAlignment(.center)
                                }
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 32)
                                .background(Color(red: 0.12, green: 0.12, blue: 0.19))
                                .cornerRadius(16)
                                .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.08), lineWidth: 1))
                            } else {
                                ForEach(dynamicSubjects, id: \.name) { subject in
                                    Button { selectedSubject = subject } label: {
                                        HStack(spacing: 14) {
                                            ZStack {
                                                Circle()
                                                    .fill(subject.color.opacity(0.15))
                                                    .frame(width: 46, height: 46)
                                                Text(subject.emoji).font(.system(size: 22))
                                            }
                                            VStack(alignment: .leading, spacing: 3) {
                                                Text(subject.name)
                                                    .font(.system(size: 15, weight: .semibold))
                                                    .foregroundColor(.white)
                                                subjectSubtitleText(for: subject.name)
                                                    .font(.system(size: 13))
                                                    .foregroundColor(.white.opacity(0.5))
                                            }
                                            Spacer()
                                            Image(systemName: "chevron.right")
                                                .font(.system(size: 13, weight: .medium))
                                                .foregroundColor(.white.opacity(0.3))
                                        }
                                        .padding(14)
                                        .background(Color(red: 0.12, green: 0.12, blue: 0.19))
                                        .cornerRadius(16)
                                        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.08), lineWidth: 1))
                                    }
                                }
                            }
                        }
                        .padding(.horizontal, 24)

                        // Blocked apps
                        VStack(alignment: .leading, spacing: 12) {
                            HStack {
                                Text("Blocked apps")
                                    .font(.system(size: 17, weight: .semibold))
                                    .foregroundColor(.white)
                                Spacer()
                                NavigationLink(destination: BlockedAppsView()) {
                                    Text("Manage")
                                        .font(.system(size: 14))
                                        .foregroundColor(Color(red: 0.42, green: 0.32, blue: 1.0))
                                }
                            }

                            if screenTime.selectedAppCount > 0 {
                                HStack(spacing: 10) {
                                    Image(systemName: screenTime.blockingMode == .earnedUnlocked
                                          ? "lock.open.fill" : "lock.fill")
                                        .foregroundColor(screenTime.blockingMode == .earnedUnlocked
                                            ? Color(red: 0.2,  green: 0.85, blue: 0.5)
                                            : Color(red: 0.42, green: 0.32, blue: 1.0))
                                        .font(.system(size: 15))
                                    Text("\(screenTime.selectedAppCount) app\(screenTime.selectedAppCount == 1 ? "" : "s") controlled")
                                        .font(.system(size: 14))
                                        .foregroundColor(.white.opacity(0.6))
                                    Spacer()
                                    if screenTime.blockingMode == .earnedUnlocked {
                                        Text(screenTime.remainingFormatted)
                                            .font(.system(size: 13, weight: .bold, design: .monospaced))
                                            .foregroundColor(Color(red: 0.2, green: 0.85, blue: 0.5))
                                    } else {
                                        Text(screenTime.blockingMode == .blocked ? "Blocked" : "Off")
                                            .font(.system(size: 13, weight: .semibold))
                                            .foregroundColor(screenTime.blockingMode == .blocked
                                                ? Color(red: 0.42, green: 0.32, blue: 1.0)
                                                : .white.opacity(0.4))
                                    }
                                }
                                .padding(14)
                                .background(Color(red: 0.12, green: 0.12, blue: 0.19))
                                .cornerRadius(14)
                                .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.white.opacity(0.08), lineWidth: 1))
                            } else {
                                NavigationLink(destination: BlockedAppsView()) {
                                    HStack(spacing: 10) {
                                        Image(systemName: "plus.circle.fill")
                                            .foregroundColor(Color(red: 0.42, green: 0.32, blue: 1.0))
                                            .font(.system(size: 18))
                                        Text("Add apps to block during sessions")
                                            .font(.system(size: 14))
                                            .foregroundColor(.white.opacity(0.5))
                                    }
                                    .padding(14)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .background(Color(red: 0.12, green: 0.12, blue: 0.19))
                                    .cornerRadius(14)
                                    .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.white.opacity(0.08), lineWidth: 1))
                                }
                            }
                        }
                        .padding(.horizontal, 24)
                        .padding(.bottom, 110)
                    }
                }
            }
            .navigationDestination(isPresented: Binding(
                get:  { selectedSubject != nil },
                set:  { if !$0 { selectedSubject = nil } }
            )) {
                if let subject = selectedSubject {
                    SubjectDetailView(
                        emoji:     subject.emoji,
                        name:      subject.name,
                        questions: subject.questions,
                        color:     subject.color
                    )
                }
            }
        }
        .fullScreenCover(isPresented: $showQuiz) {
            QuizView(isPresented: $showQuiz)
        }
    }

    // MARK: - Earned Time Banner

    private var earnedTimeBanner: some View {
        HStack(spacing: 14) {
            ZStack {
                Circle()
                    .fill(Color(red: 0.2, green: 0.85, blue: 0.5).opacity(0.15))
                    .frame(width: 46, height: 46)
                Image(systemName: "lock.open.fill")
                    .foregroundColor(Color(red: 0.2, green: 0.85, blue: 0.5))
                    .font(.system(size: 20))
            }
            VStack(alignment: .leading, spacing: 3) {
                Text("Apps unlocked")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(.white)
                Text("Earned time is counting down")
                    .font(.system(size: 13))
                    .foregroundColor(.white.opacity(0.5))
            }
            Spacer()
            Text(screenTime.remainingFormatted)
                .font(.system(size: 22, weight: .bold, design: .monospaced))
                .foregroundColor(Color(red: 0.2, green: 0.85, blue: 0.5))
        }
        .padding(14)
        .background(Color(red: 0.2, green: 0.85, blue: 0.5).opacity(0.08))
        .cornerRadius(16)
        .overlay(RoundedRectangle(cornerRadius: 16)
            .stroke(Color(red: 0.2, green: 0.85, blue: 0.5).opacity(0.2), lineWidth: 1))
    }

    // MARK: - Subject row subtitle
    // Returns a plain Text so callers can chain .font/.foregroundColor modifiers.

    private func subjectSubtitleText(for name: String) -> Text {
        let processing = isProcessing(for: name)
        let lessons    = lessonsCount(for: name)
        let questions  = questionsCount(for: name)

        if processing {
            return Text("Generating lessons…")
        } else if lessons > 0 {
            return Text("\(lessons) lesson\(lessons == 1 ? "" : "s") · \(questions) questions")
        } else if questions > 0 {
            return Text("\(questions) question\(questions == 1 ? "" : "s") ready")
        } else {
            return Text("Tap to view material")
        }
    }
}

// MARK: - Stat Box

struct StatBox: View {
    let icon:  String
    let color: Color
    let value: String
    let label: String

    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: icon)
                .font(.system(size: 20))
                .foregroundColor(color)
            Text(value)
                .font(.system(size: 20, weight: .bold))
                .foregroundColor(.white)
            Text(label)
                .font(.system(size: 11))
                .foregroundColor(.white.opacity(0.5))
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 16)
        .background(Color(red: 0.12, green: 0.12, blue: 0.19))
        .cornerRadius(16)
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.08), lineWidth: 1))
    }
}

#Preview {
    HomeView()
}
