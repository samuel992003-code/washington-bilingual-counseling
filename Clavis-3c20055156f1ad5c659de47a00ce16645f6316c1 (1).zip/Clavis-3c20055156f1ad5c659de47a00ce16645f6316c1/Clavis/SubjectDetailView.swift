import SwiftUI

struct SubjectDetailView: View {
    let emoji:     String
    let name:      String
    let questions: Int
    let color:     Color

    @ObservedObject private var storage       = StorageManager.shared
    @ObservedObject private var lessonManager = LessonPlanManager.shared

    @State private var selectedLesson:     LessonPlan? = nil
    @State private var showQuiz            = false
    /// Prevents onAppear from re-firing generation every time a sheet is dismissed.
    @State private var generationTriggered = false

    // MARK: - Derived state

    private var lessons: [LessonPlan] {
        storage.getLessons(for: name)
    }

    private var readyLessons: [LessonPlan] {
        lessons.filter { $0.status == .ready }
    }

    /// True while at least one lesson slot is actively being generated (not paused, not done).
    private var isGenerating: Bool {
        lessons.contains { $0.status == .placeholder }
    }

    /// True when quota was exhausted and some lessons are paused.
    private var isQuotaPaused: Bool {
        lessonManager.isQuotaExceeded || lessons.contains { $0.status == .pendingQuota }
    }

    private var dueReviews: [LessonPlan] {
        storage.dueReviews(for: name)
    }

    private var allQuestions: [QuizQuestion] {
        let planQ = readyLessons.flatMap { $0.questions }.map { $0.toQuizQuestion() }
        if !planQ.isEmpty { return planQ }
        return storage.savedUploads
            .filter  { $0.subject.lowercased() == name.lowercased() }
            .flatMap { $0.questions }
            .map     { $0.toQuizQuestion() }
    }

    private var isProcessing: Bool {
        storage.savedUploads
            .filter { $0.subject.lowercased() == name.lowercased() }
            .contains { $0.status == .processing }
    }

    // MARK: - Body

    var body: some View {
        ZStack {
            Color(red: 0.07, green: 0.07, blue: 0.12).ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 24) {

                    heroSection
                        .padding(.horizontal, 24)
                        .padding(.top, 20)

                    if !allQuestions.isEmpty {
                        quickQuizButton
                            .padding(.horizontal, 24)
                    }

                    if !dueReviews.isEmpty {
                        dueReviewSection
                    }

                    lessonPlanSection

                    Spacer().frame(height: 100)
                }
            }
        }
        .navigationTitle(name)
        .navigationBarTitleDisplayMode(.inline)
        .sheet(item: $selectedLesson) { lesson in
            LessonQuizView(
                lesson: lesson,
                isPresented: Binding(
                    get: { selectedLesson != nil },
                    set: { if !$0 { selectedLesson = nil } }
                )
            )
        }
        .fullScreenCover(isPresented: $showQuiz) {
            QuizView(isPresented: $showQuiz, targetSubject: name)
        }
        .onAppear {
            guard !generationTriggered else { return }
            generationTriggered = true
            startPrefetchIfNeeded()
        }
    }

    // MARK: - Hero

    private var heroSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            ZStack {
                Circle().fill(color.opacity(0.15)).frame(width: 72, height: 72)
                Text(emoji).font(.system(size: 36))
            }

            Text(name)
                .font(.system(size: 28, weight: .bold))
                .foregroundColor(.white)

            HStack(spacing: 20) {
                Label("\(lessons.count) lessons", systemImage: "book.fill")
                    .font(.system(size: 13))
                    .foregroundColor(.white.opacity(0.5))
                Label("\(allQuestions.count) questions", systemImage: "questionmark.circle.fill")
                    .font(.system(size: 13))
                    .foregroundColor(.white.opacity(0.5))
                if !dueReviews.isEmpty {
                    Label("\(dueReviews.count) due", systemImage: "clock.fill")
                        .font(.system(size: 13))
                        .foregroundColor(Color(red: 1.0, green: 0.6, blue: 0.2))
                }
            }

            // Status banner — quota pause takes precedence over generating spinner.
            if isQuotaPaused {
                quotaExceededBanner
            } else if isGenerating {
                generatingBanner
            }
        }
    }

    private var generatingBanner: some View {
        HStack(spacing: 8) {
            ProgressView().scaleEffect(0.75).tint(color)
            Text("Generating \(readyLessons.count) of \(lessons.count) lessons…")
                .font(.system(size: 13))
                .foregroundColor(.white.opacity(0.6))
        }
        .padding(.horizontal, 12).padding(.vertical, 8)
        .background(color.opacity(0.12))
        .cornerRadius(10)
    }

    private var quotaExceededBanner: some View {
        let paused = lessons.filter { $0.status == .pendingQuota }.count
        return HStack(spacing: 8) {
            Image(systemName: "exclamationmark.triangle.fill")
                .font(.system(size: 13))
                .foregroundColor(.orange)
            Text("\(readyLessons.count)/\(lessons.count) generated — \(paused) paused (quota limit)")
                .font(.system(size: 13))
                .foregroundColor(.orange)
            Spacer()
            Button {
                lessonManager.resetQuota()
                generationTriggered = false
                startPrefetchIfNeeded()
            } label: {
                Text("Retry")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(.white)
                    .padding(.horizontal, 10).padding(.vertical, 5)
                    .background(Color.orange.opacity(0.8))
                    .cornerRadius(8)
            }
        }
        .padding(.horizontal, 12).padding(.vertical, 8)
        .background(Color.orange.opacity(0.10))
        .cornerRadius(10)
        .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.orange.opacity(0.25), lineWidth: 1))
    }

    // MARK: - Quick Quiz

    private var quickQuizButton: some View {
        Button { showQuiz = true } label: {
            HStack(spacing: 16) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Quick Quiz")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.white)
                    Text("Test yourself on \(name)")
                        .font(.system(size: 13))
                        .foregroundColor(.white.opacity(0.6))
                }
                Spacer()
                ZStack {
                    Circle().fill(.white.opacity(0.15)).frame(width: 40, height: 40)
                    Image(systemName: "bolt.fill")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.white)
                }
            }
            .padding(.horizontal, 20).padding(.vertical, 16)
            .background(LinearGradient(
                colors: [color, color.opacity(0.7)],
                startPoint: .leading, endPoint: .trailing))
            .cornerRadius(18)
        }
    }

    // MARK: - Due Reviews

    private var dueReviewSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 8) {
                Image(systemName: "clock.fill")
                    .font(.system(size: 13))
                    .foregroundColor(Color(red: 1.0, green: 0.6, blue: 0.2))
                Text("Due for Review")
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundColor(.white)
                Text("(\(dueReviews.count))")
                    .font(.system(size: 14))
                    .foregroundColor(Color(red: 1.0, green: 0.6, blue: 0.2))
            }
            .padding(.horizontal, 24)

            ForEach(dueReviews) { lesson in
                Button { selectedLesson = lesson } label: {
                    LessonRow(lesson: lesson, color: Color(red: 1.0, green: 0.6, blue: 0.2))
                }
                .buttonStyle(PlainButtonStyle())
                .padding(.horizontal, 24)
            }
        }
    }

    // MARK: - Lesson Plan

    private var lessonPlanSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Lesson Plan")
                .font(.system(size: 17, weight: .semibold))
                .foregroundColor(.white)
                .padding(.horizontal, 24)

            if lessons.isEmpty {
                if isProcessing {
                    HStack(spacing: 14) {
                        ProgressView().scaleEffect(0.9).tint(color)
                        Text("Generating lessons from your notes…")
                            .font(.system(size: 14))
                            .foregroundColor(.white.opacity(0.5))
                    }
                    .padding(16)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color(red: 0.12, green: 0.12, blue: 0.19))
                    .cornerRadius(16)
                    .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.08), lineWidth: 1))
                    .padding(.horizontal, 24)
                } else {
                    VStack(spacing: 12) {
                        Text("📖").font(.system(size: 40))
                        Text("No lessons yet")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.white.opacity(0.6))
                        Text("Upload notes for \(name) to generate\na personalised lesson plan.")
                            .font(.system(size: 14))
                            .foregroundColor(.white.opacity(0.3))
                            .multilineTextAlignment(.center)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 40)
                }
            } else {
                ForEach(lessons) { lesson in
                    if lesson.status == .ready {
                        Button { selectedLesson = lesson } label: {
                            LessonRow(lesson: lesson, color: color)
                        }
                        .buttonStyle(PlainButtonStyle())
                        .padding(.horizontal, 24)
                    } else {
                        // Non-interactive placeholder, pendingQuota, or failed row.
                        LessonRow(lesson: lesson, color: color)
                            .padding(.horizontal, 24)
                            .opacity(lesson.status == .failed ? 0.35 : 0.5)
                    }
                }
            }
        }
    }

    // MARK: - Generation trigger

    private func startPrefetchIfNeeded() {
        guard !lessonManager.isQuotaExceeded else { return }

        for upload in storage.savedUploads.filter({ $0.subject.lowercased() == name.lowercased() }) {
            let hasPending = storage.getLessons(for: upload.id)
                .contains { $0.status == .placeholder || $0.status == .pendingQuota }
            guard hasPending else { continue }

            let text = storage.extractedText(for: upload)
            guard !text.isEmpty else { continue }

            LessonPlanManager.shared.generateNextBatch(
                uploadId: upload.id, text: text, subject: upload.subject
            ) { }
        }
    }
}

// MARK: - Lesson Row

struct LessonRow: View {
    let lesson: LessonPlan
    let color:  Color

    var body: some View {
        HStack(spacing: 14) {
            // Leading icon
            ZStack {
                Circle()
                    .fill(iconBackground)
                    .frame(width: 44, height: 44)
                iconContent
            }

            // Title + subtitle
            VStack(alignment: .leading, spacing: 4) {
                Text(lesson.title)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(.white)
                    .lineLimit(1)
                subtitleView
            }

            Spacer()

            // Trailing
            trailingView
        }
        .padding(14)
        .background(rowBackground)
        .cornerRadius(16)
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(rowBorder, lineWidth: 1)
        )
    }

    // MARK: Sub-views by status

    private var iconBackground: Color {
        switch lesson.status {
        case .ready where lesson.isCompleted:
            return Color(red: 0.2, green: 0.85, blue: 0.5).opacity(0.15)
        case .pendingQuota:
            return Color.orange.opacity(0.12)
        case .failed:
            return Color.red.opacity(0.12)
        default:
            return color.opacity(0.12)
        }
    }

    @ViewBuilder
    private var iconContent: some View {
        switch lesson.status {
        case .ready where lesson.isCompleted:
            Image(systemName: "checkmark")
                .font(.system(size: 16, weight: .bold))
                .foregroundColor(Color(red: 0.2, green: 0.85, blue: 0.5))
        case .ready:
            Text("\(lesson.lessonNumber)")
                .font(.system(size: 16, weight: .bold))
                .foregroundColor(color)
        case .placeholder:
            ProgressView().scaleEffect(0.7).tint(color)
        case .pendingQuota:
            Image(systemName: "pause.circle.fill")
                .font(.system(size: 20))
                .foregroundColor(.orange)
        case .failed:
            Image(systemName: "exclamationmark.circle.fill")
                .font(.system(size: 20))
                .foregroundColor(.red.opacity(0.8))
        }
    }

    @ViewBuilder
    private var subtitleView: some View {
        switch lesson.status {
        case .ready:
            Text(lesson.summary)
                .font(.system(size: 13))
                .foregroundColor(.white.opacity(0.5))
                .lineLimit(2)
        case .placeholder:
            Text("Generating…")
                .font(.system(size: 13))
                .foregroundColor(.white.opacity(0.35))
                .italic()
        case .pendingQuota:
            Text("Paused — quota limit reached")
                .font(.system(size: 13))
                .foregroundColor(.orange.opacity(0.8))
                .italic()
        case .failed:
            Text("Generation failed")
                .font(.system(size: 13))
                .foregroundColor(.red.opacity(0.7))
                .italic()
        }
    }

    @ViewBuilder
    private var trailingView: some View {
        if lesson.status == .ready {
            VStack(alignment: .trailing, spacing: 6) {
                Image(systemName: "chevron.right")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(.white.opacity(0.3))
                if lesson.masteryState != .new {
                    MasteryBadge(state: lesson.masteryState)
                }
            }
        } else {
            EmptyView()
        }
    }

    private var rowBackground: Color {
        switch lesson.status {
        case .ready where lesson.isCompleted:
            return Color(red: 0.2, green: 0.85, blue: 0.5).opacity(0.05)
        case .pendingQuota:
            return Color.orange.opacity(0.05)
        case .failed:
            return Color(red: 0.10, green: 0.10, blue: 0.16)
        default:
            return Color(red: 0.12, green: 0.12, blue: 0.19)
        }
    }

    private var rowBorder: Color {
        switch lesson.status {
        case .ready where lesson.isCompleted:
            return Color(red: 0.2, green: 0.85, blue: 0.5).opacity(0.2)
        case .pendingQuota:
            return Color.orange.opacity(0.2)
        case .failed:
            return Color.red.opacity(0.15)
        default:
            return Color.white.opacity(0.08)
        }
    }
}

// MARK: - Mastery Badge

struct MasteryBadge: View {
    let state: MasteryState

    var label: String {
        switch state {
        case .new:       return ""
        case .learning:  return "Learning"
        case .reviewing: return "Review"
        case .mastered:  return "Mastered"
        }
    }

    var badgeColor: Color {
        switch state {
        case .new:       return .clear
        case .learning:  return .orange
        case .reviewing: return Color(red: 0.42, green: 0.32, blue: 1.0)
        case .mastered:  return Color(red: 0.2, green: 0.85, blue: 0.5)
        }
    }

    var body: some View {
        Text(label)
            .font(.system(size: 10, weight: .semibold))
            .foregroundColor(badgeColor)
            .padding(.horizontal, 7).padding(.vertical, 3)
            .background(badgeColor.opacity(0.15))
            .cornerRadius(6)
    }
}
