import SwiftUI

struct MainTabView: View {
    @State private var selectedTab = 0

    var body: some View {
        ZStack(alignment: .bottom) {
            Color(red: 0.07, green: 0.07, blue: 0.12)
                .ignoresSafeArea()

            // Using if/else keeps each tab's state alive while hidden (like TabView).
            ZStack {
                if selectedTab == 0      { HomeView() }
                else if selectedTab == 1 { UploadView() }
                else if selectedTab == 2 { LeaderboardView() }
                else if selectedTab == 3 { ProgressTabView() }
                else                     { SettingsView() }
            }

            HStack(spacing: 0) {
                TabButton(icon: "house.fill",       label: "Home",        index: 0, selected: $selectedTab)
                TabButton(icon: "plus.circle.fill", label: "Upload",      index: 1, selected: $selectedTab)
                TabButton(icon: "trophy.fill",      label: "Leaderboard", index: 2, selected: $selectedTab)
                TabButton(icon: "chart.bar.fill",   label: "Progress",    index: 3, selected: $selectedTab)
                TabButton(icon: "gearshape.fill",   label: "Settings",    index: 4, selected: $selectedTab)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .background(
                RoundedRectangle(cornerRadius: 28)
                    .fill(Color(red: 0.12, green: 0.12, blue: 0.19))
                    .overlay(
                        RoundedRectangle(cornerRadius: 28)
                            .stroke(Color.white.opacity(0.08), lineWidth: 1)
                    )
                    .shadow(color: .black.opacity(0.5), radius: 24, y: 8)
            )
            .padding(.horizontal, 16)
            .padding(.bottom, 28)
        }
    }
}

struct TabButton: View {
    let icon:  String
    let label: String
    let index: Int
    @Binding var selected: Int

    var isActive: Bool { selected == index }

    var body: some View {
        Button {
            withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                selected = index
            }
        } label: {
            VStack(spacing: 4) {
                Image(systemName: icon)
                    .font(.system(size: 20))
                    .foregroundColor(isActive ? Color(red: 0.42, green: 0.32, blue: 1.0) : Color.white.opacity(0.3))
                    .scaleEffect(isActive ? 1.1 : 1.0)
                    .animation(.spring(response: 0.3), value: isActive)

                Text(label)
                    .font(.system(size: 10, weight: isActive ? .semibold : .regular))
                    .foregroundColor(isActive ? Color(red: 0.42, green: 0.32, blue: 1.0) : Color.white.opacity(0.3))
            }
            .frame(maxWidth: .infinity)
        }
    }
}

#Preview {
    MainTabView()
}
