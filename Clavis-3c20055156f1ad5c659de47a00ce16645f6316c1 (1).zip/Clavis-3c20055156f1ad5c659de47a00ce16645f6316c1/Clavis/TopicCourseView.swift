import SwiftUI

// MARK: - TopicCourseView
//
// Sheet presented from UploadView when the user taps "Build a 1-month course".
// The user types a topic and picks a level; the AI generates a 30-lesson curriculum.
//
// Flow:
//   1. User fills in topic + level + subject → taps "Build my 1-month course"
//   2. LessonPlanManager.buildTopicCourse generates the curriculum outline (single API call).
//   3. On success: 30 placeholders are created, sheet dismisses, and lessons generate in background.
//   4. On failure: error message shown inline.

struct TopicCourseView: View {
    @Binding var isPresented: Bool

    @State private var topic           = ""
    @State private var selectedLevel   = "Beginner"
    @State private var selectedSubject = "General"
    @State private var isBuilding      = false
    @State private var errorMessage    = ""

    private let levels   = ["Beginner", "Intermediate", "Advanced"]
    private let subjects = ["General", "Biology", "Finance", "History",
                            "Chemistry", "Math", "Physics", "Psychology"]

    var body: some View {
        ZStack {
            Color(red: 0.07, green: 0.07, blue: 0.12).ignoresSafeArea()

            VStack(spacing: 0) {
                // Drag handle
                RoundedRectangle(cornerRadius: 2)
                    .fill(Color.white.opacity(0.2))
                    .frame(width: 40, height: 4)
                    .padding(.top, 14)
                    .padding(.bottom, 4)

                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 24) {

                        // Header
                        VStack(alignment: .leading, spacing: 8) {
                            HStack(spacing: 10) {
                                Image(systemName: "sparkles")
                                    .font(.system(size: 22))
                                    .foregroundColor(Color(red: 0.42, green: 0.32, blue: 1.0))
                                Text("Build a 1-month course")
                                    .font(.system(size: 24, weight: .bold))
                                    .foregroundColor(.white)
                            }
                            Text("No notes needed. Type a topic and AI builds 30 progressive lessons for you.")
                                .font(.system(size: 15))
                                .foregroundColor(.white.opacity(0.55))
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        .padding(.top, 16)

                        // Topic input
                        VStack(alignment: .leading, spacing: 10) {
                            Text("What do you want to learn?")
                                .font(.system(size: 15, weight: .semibold))
                                .foregroundColor(.white.opacity(0.7))

                            TextField(
                                "",
                                text: $topic,
                                prompt: Text("e.g. Python programming, Stoicism, Organic chemistry")
                                    .foregroundColor(.white.opacity(0.25))
                            )
                            .font(.system(size: 16))
                            .foregroundColor(.white)
                            .padding(14)
                            .background(Color(red: 0.12, green: 0.12, blue: 0.19))
                            .cornerRadius(14)
                            .overlay(
                                RoundedRectangle(cornerRadius: 14)
                                    .stroke(Color.white.opacity(0.08), lineWidth: 1)
                            )
                            .disabled(isBuilding)
                        }

                        // Level picker
                        VStack(alignment: .leading, spacing: 10) {
                            Text("Your level")
                                .font(.system(size: 15, weight: .semibold))
                                .foregroundColor(.white.opacity(0.7))

                            HStack(spacing: 8) {
                                ForEach(levels, id: \.self) { level in
                                    Button { selectedLevel = level } label: {
                                        Text(level)
                                            .font(.system(size: 14,
                                                         weight: selectedLevel == level ? .semibold : .regular))
                                            .foregroundColor(selectedLevel == level ? .white : .white.opacity(0.5))
                                            .frame(maxWidth: .infinity)
                                            .padding(.vertical, 10)
                                            .background(selectedLevel == level
                                                        ? Color(red: 0.42, green: 0.32, blue: 1.0)
                                                        : Color(red: 0.12, green: 0.12, blue: 0.19))
                                            .cornerRadius(12)
                                            .overlay(
                                                RoundedRectangle(cornerRadius: 12)
                                                    .stroke(selectedLevel == level
                                                            ? Color.clear
                                                            : Color.white.opacity(0.08), lineWidth: 1)
                                            )
                                    }
                                    .disabled(isBuilding)
                                }
                            }
                        }

                        // Subject picker
                        VStack(alignment: .leading, spacing: 10) {
                            Text("Subject category")
                                .font(.system(size: 15, weight: .semibold))
                                .foregroundColor(.white.opacity(0.7))

                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack(spacing: 8) {
                                    ForEach(subjects, id: \.self) { subject in
                                        Button { selectedSubject = subject } label: {
                                            Text(subject)
                                                .font(.system(size: 14,
                                                             weight: selectedSubject == subject ? .semibold : .regular))
                                                .foregroundColor(selectedSubject == subject ? .white : .white.opacity(0.5))
                                                .padding(.horizontal, 14)
                                                .padding(.vertical, 8)
                                                .background(selectedSubject == subject
                                                            ? Color(red: 0.42, green: 0.32, blue: 1.0)
                                                            : Color(red: 0.12, green: 0.12, blue: 0.19))
                                                .cornerRadius(20)
                                                .overlay(
                                                    RoundedRectangle(cornerRadius: 20)
                                                        .stroke(selectedSubject == subject
                                                                ? Color.clear
                                                                : Color.white.opacity(0.08), lineWidth: 1)
                                                )
                                        }
                                        .disabled(isBuilding)
                                    }
                                }
                            }
                        }

                        // Info box
                        HStack(alignment: .top, spacing: 12) {
                            Image(systemName: "sparkles")
                                .font(.system(size: 16))
                                .foregroundColor(Color(red: 0.42, green: 0.32, blue: 1.0))
                                .padding(.top, 1)
                            VStack(alignment: .leading, spacing: 4) {
                                Text("30 structured lessons")
                                    .font(.system(size: 14, weight: .semibold))
                                    .foregroundColor(.white)
                                Text("Foundations first, progressively more advanced. Each lesson has content, key points, and a quiz. Complete lessons to earn app-unlock time.")
                                    .font(.system(size: 13))
                                    .foregroundColor(.white.opacity(0.5))
                                    .fixedSize(horizontal: false, vertical: true)
                                    .lineSpacing(3)
                            }
                        }
                        .padding(14)
                        .background(Color(red: 0.42, green: 0.32, blue: 1.0).opacity(0.08))
                        .cornerRadius(14)
                        .overlay(
                            RoundedRectangle(cornerRadius: 14)
                                .stroke(Color(red: 0.42, green: 0.32, blue: 1.0).opacity(0.2), lineWidth: 1)
                        )

                        // Error message
                        if !errorMessage.isEmpty {
                            Text(errorMessage)
                                .font(.system(size: 13))
                                .foregroundColor(.red.opacity(0.8))
                                .multilineTextAlignment(.center)
                                .frame(maxWidth: .infinity)
                        }
                    }
                    .padding(.horizontal, 24)
                    .padding(.bottom, 32)
                }

                // CTA
                VStack(spacing: 0) {
                    Divider().background(Color.white.opacity(0.08))

                    Button { startBuilding() } label: {
                        HStack(spacing: 10) {
                            if isBuilding {
                                ProgressView().tint(.white).scaleEffect(0.9)
                                Text("Generating curriculum…")
                                    .font(.system(size: 17, weight: .semibold))
                                    .foregroundColor(.white)
                            } else {
                                Text("Build my 1-month course →")
                                    .font(.system(size: 17, weight: .semibold))
                                    .foregroundColor(.white)
                            }
                        }
                        .frame(maxWidth: .infinity)
                        .frame(height: 56)
                        .background(canBuild
                                    ? Color(red: 0.42, green: 0.32, blue: 1.0)
                                    : Color(red: 0.12, green: 0.12, blue: 0.19))
                        .cornerRadius(16)
                    }
                    .disabled(!canBuild || isBuilding)
                    .padding(.horizontal, 24)
                    .padding(.vertical, 16)
                    .padding(.bottom, 16)
                }
            }
        }
    }

    // MARK: - Helpers

    private var canBuild: Bool {
        !topic.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    private func startBuilding() {
        let trimmedTopic = topic.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedTopic.isEmpty else { return }
        isBuilding    = true
        errorMessage  = ""

        LessonPlanManager.shared.buildTopicCourse(
            topic:   trimmedTopic,
            level:   selectedLevel,
            subject: selectedSubject
        ) { success in
            DispatchQueue.main.async {
                isBuilding = false
                if success {
                    isPresented = false
                } else {
                    errorMessage = "Could not generate the curriculum. Check your connection and try again."
                }
            }
        }
    }
}

#Preview {
    TopicCourseView(isPresented: .constant(true))
}
