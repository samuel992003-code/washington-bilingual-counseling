import Foundation
import Combine

// MARK: - AIManager
// Handles quick quiz-question generation and lesson card generation (used by QuizView / UploadView).
// Lesson-plan generation lives in AIGenerationService / GeminiGenerationService below.

class AIManager: ObservableObject {
    static let shared = AIManager()

    // Replace with your actual Gemini API key.
    private let apiKey = "YOUR_GEMINI_API_KEY"

    // Change geminiModel here to swap models across the whole app.
    private let geminiModel      = "gemini-2.5-flash-lite"
    private let geminiAPIVersion = "v1beta"

    private var apiURL: String {
        "https://generativelanguage.googleapis.com/\(geminiAPIVersion)/models/\(geminiModel):generateContent"
    }

    func getApiKey() -> String { apiKey }
    func getApiURL() -> String { apiURL }

    // MARK: - Generate Quiz Questions

    func generateQuestions(from text: String,
                           subject: String,
                           completion: @escaping ([QuizQuestion]) -> Void) {
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            completion([]); return
        }
        guard let url = URL(string: "\(apiURL)?key=\(apiKey)") else {
            completion([]); return
        }

        let prompt = """
        You are a study assistant creating quiz questions for a student.

        Subject: \(subject)

        Study material:
        \(String(text.prefix(6_000)))

        Generate exactly 5 quiz questions from this material.
        Mix multiple_choice and true_false types.
        Keep questions short and answerable in under 20 seconds.

        Return ONLY a valid JSON array — no markdown, no explanation:
        [
          {
            "type": "multiple_choice",
            "question": "question text",
            "options": ["A", "B", "C", "D"],
            "correct": "A",
            "explanation": "brief explanation"
          },
          {
            "type": "true_false",
            "question": "true or false statement",
            "options": ["True", "False"],
            "correct": "True",
            "explanation": "brief explanation"
          }
        ]
        """

        performRequest(url: url, prompt: prompt) { data, statusCode, error in
            if let error = error {
                print("❌ AIManager.generateQuestions: \(error.localizedDescription)")
                DispatchQueue.main.async { completion([]) }
                return
            }
            guard let data = data else {
                DispatchQueue.main.async { completion([]) }
                return
            }
            if let code = statusCode, !(200...299).contains(code) {
                print("❌ AIManager.generateQuestions HTTP \(code)")
                DispatchQueue.main.async { completion([]) }
                return
            }
            guard let responseText = self.extractText(from: data) else {
                DispatchQueue.main.async { completion([]) }
                return
            }
            let cleaned = self.stripMarkdownFences(responseText)
            guard
                let jsonData = cleaned.data(using: .utf8),
                let array    = try? JSONSerialization.jsonObject(with: jsonData) as? [[String: Any]]
            else {
                DispatchQueue.main.async { completion([]) }
                return
            }
            let questions: [QuizQuestion] = array.compactMap { q in
                guard
                    let qt  = q["question"]    as? String,
                    let opts = q["options"]    as? [String],
                    let cor  = q["correct"]    as? String,
                    let exp  = q["explanation"] as? String
                else { return nil }
                return QuizQuestion(
                    emoji: self.emojiForSubject(subject), subject: subject,
                    question: qt, options: opts, correct: cor, explanation: exp
                )
            }
            DispatchQueue.main.async { completion(questions) }
        }
    }

    // MARK: - Generate Lesson Card

    func generateLesson(from text: String,
                        subject: String,
                        completion: @escaping (LessonCard?) -> Void) {
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            completion(nil); return
        }
        guard let url = URL(string: "\(apiURL)?key=\(apiKey)") else {
            completion(nil); return
        }

        let prompt = """
        You are a study assistant creating a short lesson card for a student.

        Subject: \(subject)

        Study material:
        \(String(text.prefix(4_000)))

        Create a lesson card from the most important concept in this material.

        Return ONLY a valid JSON object — no markdown, no explanation:
        {
          "title": "short concept title (5 words max)",
          "content": "3-4 sentence explanation in simple plain English",
          "keyPoint": "one key formula or fact to remember"
        }
        """

        performRequest(url: url, prompt: prompt) { data, statusCode, error in
            if let error = error {
                print("❌ AIManager.generateLesson: \(error.localizedDescription)")
                DispatchQueue.main.async { completion(nil) }
                return
            }
            guard let data = data else {
                DispatchQueue.main.async { completion(nil) }
                return
            }
            if let code = statusCode, !(200...299).contains(code) {
                print("❌ AIManager.generateLesson HTTP \(code)")
                DispatchQueue.main.async { completion(nil) }
                return
            }
            guard let responseText = self.extractText(from: data) else {
                DispatchQueue.main.async { completion(nil) }
                return
            }
            let cleaned = self.stripMarkdownFences(responseText)
            guard
                let jsonData = cleaned.data(using: .utf8),
                let obj      = try? JSONSerialization.jsonObject(with: jsonData) as? [String: Any],
                let title    = obj["title"]    as? String,
                let content  = obj["content"]  as? String,
                let keyPoint = obj["keyPoint"] as? String
            else {
                DispatchQueue.main.async { completion(nil) }
                return
            }
            let lesson = LessonCard(
                emoji: self.emojiForSubject(subject), subject: subject,
                title: title, content: content, keyPoint: keyPoint
            )
            DispatchQueue.main.async { completion(lesson) }
        }
    }

    // MARK: - Generate Topic Curriculum
    //
    // Topic-based mode only. Returns 30 (index, title) pairs that form a progressive
    // curriculum for the given topic and level. Called once per course creation; the
    // resulting titles are turned into TextChunks and fed to TopicGenerationService.

    func generateCurriculum(
        topic: String,
        level: String,
        completion: @escaping ([(index: Int, title: String)]) -> Void
    ) {
        guard let url = URL(string: "\(apiURL)?key=\(apiKey)") else {
            completion([]); return
        }

        let prompt = """
        You are a curriculum designer creating a structured 30-lesson 1-month course.

        Topic: \(topic)
        Student level: \(level)

        Design 30 progressive lessons that build from fundamentals to advanced material.
        Follow this arc:
        - Lessons 1–8:   Core foundations and essential concepts
        - Lessons 9–18:  Intermediate application and deeper understanding
        - Lessons 19–26: Advanced topics, edge cases, and nuance
        - Lessons 27–30: Integration, real-world application, and review

        Rules:
        - Each title must be specific and directly related to \(topic).
        - Titles should be 5–10 words each.
        - Maintain a clear logical progression between lessons.

        Return ONLY a valid JSON array with exactly 30 items. No markdown, no explanation:
        [
          {"index": 0, "title": "Introduction to \(topic): Core Ideas"},
          {"index": 1, "title": "..."},
          ...
          {"index": 29, "title": "..."}
        ]
        """

        performRequest(url: url, prompt: prompt) { data, statusCode, error in
            if let error = error {
                print("❌ AIManager.generateCurriculum: \(error.localizedDescription)")
                DispatchQueue.main.async { completion([]) }
                return
            }
            guard let data = data else {
                DispatchQueue.main.async { completion([]) }
                return
            }
            if let code = statusCode, !(200...299).contains(code) {
                print("❌ AIManager.generateCurriculum HTTP \(code)")
                DispatchQueue.main.async { completion([]) }
                return
            }
            guard let responseText = self.extractText(from: data) else {
                DispatchQueue.main.async { completion([]) }
                return
            }
            let cleaned = self.stripMarkdownFences(responseText)
            guard
                let jsonData = cleaned.data(using: .utf8),
                let array    = try? JSONSerialization.jsonObject(with: jsonData) as? [[String: Any]]
            else {
                DispatchQueue.main.async { completion([]) }
                return
            }
            let titles: [(index: Int, title: String)] = array.compactMap { item in
                guard
                    let idx   = item["index"] as? Int,
                    let title = item["title"] as? String
                else { return nil }
                return (index: idx, title: title)
            }.sorted { $0.index < $1.index }

            DispatchQueue.main.async { completion(titles) }
        }
    }

    // MARK: - Subject Emoji

    func emojiForSubject(_ subject: String) -> String {
        switch subject.lowercased() {
        case "biology":    return "🧬"
        case "finance":    return "💰"
        case "history":    return "📜"
        case "chemistry":  return "⚗️"
        case "math":       return "📐"
        case "physics":    return "⚡️"
        case "english":    return "📝"
        case "psychology": return "🧠"
        default:           return "📚"
        }
    }

    // MARK: - Private Helpers

    private func performRequest(url: URL,
                                prompt: String,
                                completion: @escaping (Data?, Int?, Error?) -> Void) {
        let body: [String: Any] = ["contents": [["parts": [["text": prompt]]]]]
        var request = URLRequest(url: url)
        request.httpMethod      = "POST"
        request.timeoutInterval = 30
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)
        URLSession.shared.dataTask(with: request) { data, response, error in
            completion(data, (response as? HTTPURLResponse)?.statusCode, error)
        }.resume()
    }

    func extractText(from data: Data) -> String? {
        guard
            let json       = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
            let candidates = json["candidates"]  as? [[String: Any]],
            let first      = candidates.first,
            let content    = first["content"]    as? [String: Any],
            let parts      = content["parts"]    as? [[String: Any]],
            let text       = parts.first?["text"] as? String
        else { return nil }
        return text
    }

    func stripMarkdownFences(_ text: String) -> String {
        text
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "```json", with: "")
            .replacingOccurrences(of: "```",     with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MARK: - AI Generation Service Abstraction
//
// Protocol-based boundary for lesson-plan generation.
//
// Two concrete implementations:
//   GeminiGenerationService  — upload-based; prompt grounds content in extracted text.
//   TopicGenerationService   — topic-based; prompt teaches from first principles.
//
// To move generation server-side: create BackendGenerationService : AIGenerationService
// that POSTs to your server, then set LessonPlanManager.shared.service = BackendGenerationService.shared.
// ─────────────────────────────────────────────────────────────────────────────

// MARK: - Generation Error

enum LessonGenerationError: Error {
    /// HTTP 429 — quota exhausted. Stop the batch cleanly; preserve existing lessons.
    case quotaExceeded
    /// HTTP 400 / 404 — bad model or endpoint. No point retrying.
    case permanent(statusCode: Int)
    /// HTTP 5xx / network timeout — safe to retry once.
    case transient
}

// MARK: - Protocol

/// Thin abstraction over lesson generation.
/// Swap the concrete implementation in LessonPlanManager.shared.service — no other changes required.
protocol AIGenerationService: AnyObject {
    func generateLesson(
        chunk: TextChunk,
        subject: String,
        uploadId: UUID,
        completion: @escaping (LessonPlan?, LessonGenerationError?) -> Void
    )
}

// MARK: - Gemini Implementation (upload-based)

/// Default AIGenerationService for uploaded-notes mode.
/// Grounds every lesson in the extracted text chunk supplied by the user.
final class GeminiGenerationService: AIGenerationService {
    static let shared = GeminiGenerationService()
    private init() {}

    private var geminiURL: String { AIManager.shared.getApiURL() }
    private var apiKey:    String { AIManager.shared.getApiKey() }

    private static let _loggedEndpoint: Void = {
        print("ℹ️ GeminiGenerationService — \(AIManager.shared.getApiURL())")
    }()

    func generateLesson(
        chunk: TextChunk,
        subject: String,
        uploadId: UUID,
        completion: @escaping (LessonPlan?, LessonGenerationError?) -> Void
    ) {
        _ = GeminiGenerationService._loggedEndpoint

        guard let url = URL(string: "\(geminiURL)?key=\(apiKey)") else {
            completion(nil, .permanent(statusCode: 0)); return
        }

        let prompt = buildPrompt(chunk: chunk, subject: subject)
        let body: [String: Any] = ["contents": [["parts": [["text": prompt]]]]]
        var request = URLRequest(url: url)
        request.httpMethod      = "POST"
        request.timeoutInterval = 60
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("❌ Chunk \(chunk.index) network error: \(error.localizedDescription)")
                completion(nil, .transient); return
            }
            guard let data = data else { completion(nil, .transient); return }

            let statusCode = (response as? HTTPURLResponse)?.statusCode ?? 0
            if !(200...299).contains(statusCode) {
                let body = String(data: data, encoding: .utf8) ?? ""
                print("❌ Chunk \(chunk.index) HTTP \(statusCode): \(body.prefix(200))")
                let failure: LessonGenerationError
                switch statusCode {
                case 429:      failure = .quotaExceeded
                case 400, 404: failure = .permanent(statusCode: statusCode)
                default:       failure = .transient
                }
                completion(nil, failure); return
            }

            guard let plan = self.parse(data: data, chunk: chunk, subject: subject, uploadId: uploadId) else {
                print("❌ Chunk \(chunk.index) — parse failed.")
                completion(nil, .transient); return
            }
            completion(plan, nil)
        }.resume()
    }

    // MARK: Private helpers

    private func buildPrompt(chunk: TextChunk, subject: String) -> String {
        """
        You are a study assistant creating a self-contained lesson and quiz for a student.

        Subject: \(subject)
        Lesson \(chunk.index + 1)

        ===BEGIN STUDY MATERIAL===
        \(chunk.text)
        ===END STUDY MATERIAL===

        INSTRUCTIONS
        1. Identify the 3-5 most important concepts, facts, or processes in the material above.
        2. Write a clear lesson (summary + key points) that teaches those ideas.
        3. Write quiz questions that test ONLY facts explicitly stated in the material.
           Every question must be answerable by reading your summary and key points alone.

        Return ONLY a valid JSON object. No markdown, no code fences, no text outside the JSON:
        {
          "title": "5-word-max title specific to this content",
          "summary": "3-4 sentences explaining the key ideas from this passage in plain language",
          "fullExplanation": "2-3 paragraph in-depth explanation using only content from this passage",
          "keyPoints": [
            "specific fact or concept from this text",
            "another specific point from this text",
            "third specific point from this text"
          ],
          "keyTerm": "most important term: one-line definition",
          "questions": [
            {
              "type": "multiple_choice",
              "question": "question about a specific fact stated above",
              "options": ["correct answer", "wrong option", "wrong option", "wrong option"],
              "correct": "correct answer",
              "explanation": "one sentence referencing the key point"
            },
            {
              "type": "true_false",
              "question": "statement about something explicitly stated above",
              "options": ["True", "False"],
              "correct": "True",
              "explanation": "one sentence citing the relevant key point"
            },
            {
              "type": "multiple_choice",
              "question": "question testing a different specific fact from the key points",
              "options": ["correct answer", "wrong option", "wrong option", "wrong option"],
              "correct": "correct answer",
              "explanation": "one sentence explanation"
            }
          ]
        }
        """
    }

    private func parse(data: Data, chunk: TextChunk, subject: String, uploadId: UUID) -> LessonPlan? {
        guard
            let json       = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
            let candidates = json["candidates"]  as? [[String: Any]],
            let first      = candidates.first,
            let content    = first["content"]    as? [String: Any],
            let parts      = content["parts"]    as? [[String: Any]],
            let rawText    = parts.first?["text"] as? String
        else { return nil }

        let cleaned = rawText
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "```json", with: "")
            .replacingOccurrences(of: "```",     with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)

        guard
            let jsonData = cleaned.data(using: .utf8),
            let d        = try? JSONSerialization.jsonObject(with: jsonData) as? [String: Any]
        else { return nil }

        let title           = d["title"]           as? String ?? "Lesson \(chunk.index + 1)"
        let summary         = d["summary"]         as? String ?? ""
        let fullExplanation = d["fullExplanation"] as? String ?? ""
        let keyPoints       = d["keyPoints"]       as? [String] ?? []
        let keyTerm         = d["keyTerm"]         as? String ?? ""

        guard !summary.isEmpty else { return nil }

        var questions: [SavedQuestion] = []
        if let qs = d["questions"] as? [[String: Any]] {
            for q in qs {
                guard
                    let questionText = q["question"]    as? String,
                    let options      = q["options"]     as? [String],
                    let correct      = q["correct"]     as? String,
                    let explanation  = q["explanation"] as? String
                else { continue }
                questions.append(SavedQuestion(
                    emoji:       AIManager.shared.emojiForSubject(subject),
                    subject:     subject,
                    question:    questionText,
                    options:     options,
                    correct:     correct,
                    explanation: explanation
                ))
            }
        }

        return LessonPlan(
            uploadId:        uploadId,
            lessonNumber:    chunk.index + 1,
            subject:         subject,
            title:           title,
            summary:         summary,
            fullExplanation: fullExplanation,
            keyPoints:       keyPoints,
            keyTerm:         keyTerm,
            questions:       questions,
            chunkIndex:      chunk.index,
            status:          .ready
        )
    }
}

// MARK: - Topic Generation Service (topic-based)

/// AIGenerationService for topic-based courses.
/// Each TextChunk encodes "COURSE:", "LEVEL:", and "TITLE:" fields instead of raw study text.
/// The prompt teaches the lesson from first principles rather than grounding it in source material.
final class TopicGenerationService: AIGenerationService {
    static let shared = TopicGenerationService()
    private init() {}

    private var geminiURL: String { AIManager.shared.getApiURL() }
    private var apiKey:    String { AIManager.shared.getApiKey() }

    func generateLesson(
        chunk: TextChunk,
        subject: String,
        uploadId: UUID,
        completion: @escaping (LessonPlan?, LessonGenerationError?) -> Void
    ) {
        guard let url = URL(string: "\(geminiURL)?key=\(apiKey)") else {
            completion(nil, .permanent(statusCode: 0)); return
        }

        let prompt = buildPrompt(chunk: chunk, subject: subject)
        let body: [String: Any] = ["contents": [["parts": [["text": prompt]]]]]
        var request = URLRequest(url: url)
        request.httpMethod      = "POST"
        request.timeoutInterval = 60
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("❌ Topic lesson \(chunk.index) network error: \(error.localizedDescription)")
                completion(nil, .transient); return
            }
            guard let data = data else { completion(nil, .transient); return }

            let statusCode = (response as? HTTPURLResponse)?.statusCode ?? 0
            if !(200...299).contains(statusCode) {
                let body = String(data: data, encoding: .utf8) ?? ""
                print("❌ Topic lesson \(chunk.index) HTTP \(statusCode): \(body.prefix(200))")
                switch statusCode {
                case 429:      completion(nil, .quotaExceeded)
                case 400, 404: completion(nil, .permanent(statusCode: statusCode))
                default:       completion(nil, .transient)
                }
                return
            }

            guard let plan = self.parse(data: data, chunk: chunk, subject: subject, uploadId: uploadId) else {
                print("❌ Topic lesson \(chunk.index) — parse failed.")
                completion(nil, .transient); return
            }
            completion(plan, nil)
        }.resume()
    }

    // MARK: - Private helpers

    /// Decodes COURSE/LEVEL/TITLE fields encoded in chunk.text by buildTopicCourse.
    private func decode(chunk: TextChunk) -> (course: String, level: String, title: String) {
        var course = "the topic"
        var level  = "Beginner"
        var title  = "Lesson \(chunk.index + 1)"
        for line in chunk.text.components(separatedBy: "\n") {
            if line.hasPrefix("COURSE:") { course = String(line.dropFirst(7)) }
            if line.hasPrefix("LEVEL:")  { level  = String(line.dropFirst(6)) }
            if line.hasPrefix("TITLE:")  { title  = String(line.dropFirst(6)) }
        }
        return (course, level, title)
    }

    private func buildPrompt(chunk: TextChunk, subject: String) -> String {
        let (course, level, title) = decode(chunk: chunk)
        return """
        You are a curriculum teacher creating lesson \(chunk.index + 1) of 30 in a course on "\(course)".

        Course: \(course)
        Subject area: \(subject)
        Student level: \(level)
        This lesson (\(chunk.index + 1) of 30): \(title)

        INSTRUCTIONS
        1. Write a clear, accurate lesson that teaches "\(title)" from first principles.
        2. Pitch the content for a \(level.lowercased()) learner.
        3. Assume the student has completed the previous \(chunk.index) lesson(s) in this course.
        4. Be specific, concrete, and accurate — no filler content.
        5. Include 3 quiz questions that test understanding of this specific lesson.

        Return ONLY a valid JSON object. No markdown, no code fences, no text outside the JSON:
        {
          "title": "\(title)",
          "summary": "3-4 sentences explaining the core idea of this lesson in plain language",
          "fullExplanation": "2-3 paragraph in-depth explanation of this lesson's concepts",
          "keyPoints": [
            "specific concept or fact from this lesson",
            "second key point",
            "third key point"
          ],
          "keyTerm": "most important term from this lesson: one-line definition",
          "questions": [
            {
              "type": "multiple_choice",
              "question": "question testing a core concept from this lesson",
              "options": ["correct answer", "wrong option", "wrong option", "wrong option"],
              "correct": "correct answer",
              "explanation": "brief explanation"
            },
            {
              "type": "true_false",
              "question": "true or false statement about this lesson",
              "options": ["True", "False"],
              "correct": "True",
              "explanation": "brief explanation"
            },
            {
              "type": "multiple_choice",
              "question": "question testing a different concept from this lesson",
              "options": ["correct answer", "wrong option", "wrong option", "wrong option"],
              "correct": "correct answer",
              "explanation": "brief explanation"
            }
          ]
        }
        """
    }

    private func parse(data: Data, chunk: TextChunk, subject: String, uploadId: UUID) -> LessonPlan? {
        guard
            let json       = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
            let candidates = json["candidates"]  as? [[String: Any]],
            let first      = candidates.first,
            let content    = first["content"]    as? [String: Any],
            let parts      = content["parts"]    as? [[String: Any]],
            let rawText    = parts.first?["text"] as? String
        else { return nil }

        let cleaned = rawText
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "```json", with: "")
            .replacingOccurrences(of: "```",     with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)

        guard
            let jsonData = cleaned.data(using: .utf8),
            let d        = try? JSONSerialization.jsonObject(with: jsonData) as? [String: Any]
        else { return nil }

        let (_, _, fallbackTitle) = decode(chunk: chunk)
        let title           = d["title"]           as? String ?? fallbackTitle
        let summary         = d["summary"]         as? String ?? ""
        let fullExplanation = d["fullExplanation"] as? String ?? ""
        let keyPoints       = d["keyPoints"]       as? [String] ?? []
        let keyTerm         = d["keyTerm"]         as? String ?? ""

        guard !summary.isEmpty else { return nil }

        var questions: [SavedQuestion] = []
        if let qs = d["questions"] as? [[String: Any]] {
            for q in qs {
                guard
                    let questionText = q["question"]    as? String,
                    let options      = q["options"]     as? [String],
                    let correct      = q["correct"]     as? String,
                    let explanation  = q["explanation"] as? String
                else { continue }
                questions.append(SavedQuestion(
                    emoji:       AIManager.shared.emojiForSubject(subject),
                    subject:     subject,
                    question:    questionText,
                    options:     options,
                    correct:     correct,
                    explanation: explanation
                ))
            }
        }

        return LessonPlan(
            uploadId:        uploadId,
            lessonNumber:    chunk.index + 1,
            subject:         subject,
            title:           title,
            summary:         summary,
            fullExplanation: fullExplanation,
            keyPoints:       keyPoints,
            keyTerm:         keyTerm,
            questions:       questions,
            chunkIndex:      chunk.index,
            status:          .ready
        )
    }
}
