import Foundation
import Combine

class StorageManager: ObservableObject {
    static let shared = StorageManager()

    @Published var savedUploads: [SavedUpload] = []
    @Published var lessonPlans: [LessonPlan]   = []

    // Current signed-in user. All keys and file paths are namespaced by this.
    private var currentUserId: String = ""

    // Computed keys — scoped per user so accounts never share data.
    private var uploadsKey: String { "\(currentUserId)_savedUploads_v2" }
    private var lessonsKey: String { "\(currentUserId)_lessonPlans_v2" }

    private var documentsDir: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    // Don't auto-load in init — SupabaseManager calls loadData(for:) once the
    // userId is known, so we never accidentally load the wrong user's data.
    private init() {}

    // MARK: - User Lifecycle

    /// Called by SupabaseManager after sign-in or session restore.
    func loadData(for userId: String) {
        currentUserId = userId
        loadUploads()
        loadLessonPlans()
    }

    /// Called by SupabaseManager on sign-out.
    /// Wipes in-memory state only — persisted data stays on disk keyed by userId
    /// so it can be restored when the same user signs back in.
    func clearAll() {
        savedUploads  = []
        lessonPlans   = []
        currentUserId = ""
    }

    // MARK: - Uploads

    func loadUploads() {
        guard !currentUserId.isEmpty else { return }
        guard
            let data    = UserDefaults.standard.data(forKey: uploadsKey),
            let decoded = try? JSONDecoder().decode([SavedUpload].self, from: data)
        else { savedUploads = []; return }
        savedUploads = decoded
    }

    func saveUpload(_ upload: SavedUpload) {
        guard !currentUserId.isEmpty else { return }
        if !upload.extractedText.isEmpty { writeText(upload.extractedText, id: upload.id) }
        var meta = upload
        meta.extractedText = ""
        savedUploads.removeAll { $0.id == upload.id }
        savedUploads.insert(meta, at: 0)
        persistUploads()
    }

    func updateUpload(_ upload: SavedUpload) {
        guard !currentUserId.isEmpty else { return }
        if !upload.extractedText.isEmpty { writeText(upload.extractedText, id: upload.id) }
        var meta = upload
        meta.extractedText = ""
        if let idx = savedUploads.firstIndex(where: { $0.id == upload.id }) {
            savedUploads[idx] = meta
            persistUploads()
        }
    }

    func deleteUpload(id: UUID) {
        savedUploads.removeAll { $0.id == id }
        lessonPlans.removeAll  { $0.uploadId == id }
        deleteText(id: id)
        persistUploads()
        persistLessonPlans()
    }

    func extractedText(for upload: SavedUpload) -> String {
        if !upload.extractedText.isEmpty { return upload.extractedText }
        return readText(id: upload.id) ?? ""
    }

    private func persistUploads() {
        guard !currentUserId.isEmpty else { return }
        if let encoded = try? JSONEncoder().encode(savedUploads) {
            UserDefaults.standard.set(encoded, forKey: uploadsKey)
        }
    }

    // MARK: - Lesson Plans

    func loadLessonPlans() {
        guard !currentUserId.isEmpty else { return }
        guard
            let data    = UserDefaults.standard.data(forKey: lessonsKey),
            let decoded = try? JSONDecoder().decode([LessonPlan].self, from: data)
        else { lessonPlans = []; return }

        // Migration: promote plans with content that were saved before the
        // LessonStatus field existed.
        lessonPlans = decoded.map { plan in
            guard plan.status == .placeholder, !plan.summary.isEmpty else { return plan }
            var migrated = plan
            migrated.status = .ready
            return migrated
        }
    }

    /// Creates placeholder LessonPlan records for a topic-based course.
    /// Unlike createPlaceholders, each slot gets the real AI-generated lesson title
    /// from the curriculum outline rather than the generic "Lesson N" fallback.
    func createTopicPlaceholders(
        titles: [(index: Int, title: String)],
        subject: String,
        uploadId: UUID
    ) {
        var changed = false
        for (idx, title) in titles {
            let alreadyExists = lessonPlans.contains {
                $0.uploadId == uploadId && $0.chunkIndex == idx
            }
            guard !alreadyExists else { continue }

            lessonPlans.append(LessonPlan(
                uploadId:        uploadId,
                lessonNumber:    idx + 1,
                subject:         subject,
                title:           title,
                summary:         "",
                fullExplanation: "",
                keyPoints:       [],
                keyTerm:         "",
                questions:       [],
                chunkIndex:      idx,
                status:          .placeholder
            ))
            changed = true
        }
        if changed { persistLessonPlans() }
    }

    /// Creates placeholder LessonPlan records for every chunk immediately after upload.
    func createPlaceholders(for chunks: [TextChunk], subject: String, uploadId: UUID) {
        var changed = false
        for chunk in chunks {
            let existing = lessonPlans.first { $0.uploadId == uploadId && $0.chunkIndex == chunk.index }
            if let existing = existing, existing.status == .ready { continue }
            if existing != nil { continue }

            lessonPlans.append(LessonPlan(
                uploadId:        uploadId,
                lessonNumber:    chunk.index + 1,
                subject:         subject,
                title:           "Lesson \(chunk.index + 1)",
                summary:         "",
                fullExplanation: "",
                keyPoints:       [],
                keyTerm:         "",
                questions:       [],
                chunkIndex:      chunk.index,
                status:          .placeholder
            ))
            changed = true
        }
        if changed { persistLessonPlans() }
    }

    func saveLessonPlans(_ plans: [LessonPlan], for uploadId: UUID) {
        plans.forEach { saveSingleLessonPlan($0, for: uploadId) }
    }

    func saveSingleLessonPlan(_ plan: LessonPlan, for uploadId: UUID) {
        if let idx = lessonPlans.firstIndex(where: {
            $0.uploadId == uploadId && $0.chunkIndex == plan.chunkIndex
        }) {
            lessonPlans[idx] = plan
        } else {
            lessonPlans.append(plan)
        }
        persistLessonPlans()
    }

    func pauseAllPendingLessons(uploadId: UUID) {
        var changed = false
        for idx in lessonPlans.indices {
            guard lessonPlans[idx].uploadId == uploadId else { continue }
            let s = lessonPlans[idx].status
            if s == .placeholder || s == .pendingQuota {
                lessonPlans[idx].status = .pendingQuota
                changed = true
            }
        }
        if changed { persistLessonPlans() }
    }

    func markLessonFailed(chunkIndex: Int, uploadId: UUID) {
        guard let idx = lessonPlans.firstIndex(where: {
            $0.uploadId == uploadId && $0.chunkIndex == chunkIndex
        }) else { return }
        lessonPlans[idx].status = .failed
        persistLessonPlans()
    }

    func markLessonComplete(id: UUID) {
        guard let lessonIdx = lessonPlans.firstIndex(where: { $0.id == id }) else { return }
        lessonPlans[lessonIdx].isCompleted = true
        let completed = lessonPlans[lessonIdx]

        if let uploadIdx = savedUploads.firstIndex(where: { $0.id == completed.uploadId }) {
            let nextChunk = completed.chunkIndex + 1
            if savedUploads[uploadIdx].currentLessonIndex < nextChunk {
                savedUploads[uploadIdx].currentLessonIndex = nextChunk
            }
            persistUploads()
        }
        persistLessonPlans()
    }

    func getLessons(for subject: String) -> [LessonPlan] {
        lessonPlans
            .filter { $0.subject.lowercased() == subject.lowercased() }
            .sorted { $0.chunkIndex < $1.chunkIndex }
    }

    func getLessons(for uploadId: UUID) -> [LessonPlan] {
        lessonPlans
            .filter { $0.uploadId == uploadId }
            .sorted { $0.chunkIndex < $1.chunkIndex }
    }

    func nextLesson(for uploadId: UUID) -> LessonPlan? {
        let all = getLessons(for: uploadId).filter { $0.status == .ready }
        return all.first { !$0.isCompleted } ?? all.first
    }

    func nextLesson(for subject: String) -> LessonPlan? {
        let all = getLessons(for: subject).filter { $0.status == .ready }
        return all.first { !$0.isCompleted } ?? all.first
    }

    func nextChunkIndex(for uploadId: UUID) -> Int {
        let existing = lessonPlans.filter { $0.uploadId == uploadId }
        return (existing.map { $0.chunkIndex }.max() ?? -1) + 1
    }

    // MARK: - Spaced Repetition

    func dueReviews(for subject: String) -> [LessonPlan] {
        let now = Date()
        return lessonPlans.filter {
            $0.subject.lowercased() == subject.lowercased()
            && $0.status == .ready
            && $0.masteryState != .new
            && $0.nextReviewDate <= now
        }.sorted { $0.nextReviewDate < $1.nextReviewDate }
    }

    func updateReview(lessonId: UUID, correct: Bool, confidence: Double) {
        guard let idx = lessonPlans.firstIndex(where: { $0.id == lessonId }) else { return }
        var plan = lessonPlans[idx]

        plan.timesSeen        += 1
        plan.lastReviewedDate  = Date()
        plan.averageConfidence = plan.averageConfidence * 0.6 + confidence * 0.4

        if correct {
            plan.timesCorrect += 1
            if confidence >= 0.7 {
                plan.reviewInterval = min(plan.reviewInterval * 2.5, 30)
                plan.masteryState   = plan.reviewInterval >= 14 ? .mastered : .reviewing
            } else {
                plan.reviewInterval = max(plan.reviewInterval * 1.3, 1)
                plan.masteryState   = .reviewing
            }
        } else {
            plan.timesIncorrect += 1
            plan.reviewInterval  = 0.5
            plan.masteryState    = .learning
        }

        plan.nextReviewDate = Date().addingTimeInterval(plan.reviewInterval * 86_400)
        lessonPlans[idx] = plan
        persistLessonPlans()
    }

    func totalLessonsCompleted() -> Int {
        lessonPlans.filter { $0.isCompleted && $0.status == .ready }.count
    }

    func subjectsWithContent() -> [String] {
        Array(Set(lessonPlans.filter { $0.status == .ready }.map { $0.subject })).sorted()
    }

    func deleteAllMaterials() {
        savedUploads.forEach { deleteText(id: $0.id) }
        savedUploads = []
        lessonPlans  = []
        guard !currentUserId.isEmpty else { return }
        UserDefaults.standard.removeObject(forKey: uploadsKey)
        UserDefaults.standard.removeObject(forKey: lessonsKey)
    }

    func markTotalChunks(uploadId: UUID, count: Int) {
        guard let idx = savedUploads.firstIndex(where: { $0.id == uploadId }) else { return }
        savedUploads[idx].totalChunks = count
        persistUploads()
    }

    func markLessonPlanBuilt(uploadId: UUID) {
        guard let idx = savedUploads.firstIndex(where: { $0.id == uploadId }) else { return }
        savedUploads[idx].lessonPlanBuilt = true
        persistUploads()
    }

    private func persistLessonPlans() {
        guard !currentUserId.isEmpty else { return }
        if let encoded = try? JSONEncoder().encode(lessonPlans) {
            UserDefaults.standard.set(encoded, forKey: lessonsKey)
        }
    }

    // MARK: - File-based text storage
    // Text files are stored under Documents/{userId}/ so they are
    // isolated per account and cleaned up correctly on sign-out.

    private func userDocumentsDir() -> URL {
        let dir = documentsDir.appendingPathComponent(currentUserId, isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    private func textFilePath(id: UUID) -> URL {
        guard !currentUserId.isEmpty else {
            // Fallback — should not happen in normal flow.
            return documentsDir.appendingPathComponent("\(id.uuidString)_text.txt")
        }
        return userDocumentsDir().appendingPathComponent("\(id.uuidString)_text.txt")
    }

    private func writeText(_ text: String, id: UUID) {
        try? text.write(to: textFilePath(id: id), atomically: true, encoding: .utf8)
    }

    private func readText(id: UUID) -> String? {
        try? String(contentsOf: textFilePath(id: id), encoding: .utf8)
    }

    private func deleteText(id: UUID) {
        try? FileManager.default.removeItem(at: textFilePath(id: id))
    }
}
