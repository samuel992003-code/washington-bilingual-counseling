import Foundation
import Combine

class StatsManager: ObservableObject {
    static let shared = StatsManager()

    @Published var totalXP:            Int  = 0
    @Published var weeklyXP:           Int  = 0   // resets every Monday; used by leaderboard
    @Published var currentStreak:      Int  = 0
    @Published var longestStreak:      Int  = 0
    @Published var totalSessions:      Int  = 0
    @Published var totalQuestions:     Int  = 0
    @Published var minutesEarnedToday: Int  = 0
    @Published var level:              Int  = 1
    @Published var weeklyActivity:     [Int] = [0, 0, 0, 0, 0, 0, 0]
    @Published var biologyQuestions:   Int  = 0
    @Published var financeQuestions:   Int  = 0
    @Published var historyQuestions:   Int  = 0

    // Current signed-in user. All UserDefaults keys are namespaced by this.
    private var currentUserId: String = ""

    // Computed keys — one set per user, never shared across accounts.
    private var xpKey:            String { "\(currentUserId)_totalXP" }
    private var weeklyXPKey:      String { "\(currentUserId)_weeklyXP" }
    private var streakKey:        String { "\(currentUserId)_currentStreak" }
    private var longestKey:       String { "\(currentUserId)_longestStreak" }
    private var sessionsKey:      String { "\(currentUserId)_totalSessions" }
    private var questionsKey:     String { "\(currentUserId)_totalQuestions" }
    private var minutesTodayKey:  String { "\(currentUserId)_minutesEarnedToday" }
    private var lastActiveKey:    String { "\(currentUserId)_lastActiveDate" }
    private var weeklyKey:        String { "\(currentUserId)_weeklyActivity" }
    private var lastResetKey:     String { "\(currentUserId)_lastReset" }
    private var lastWeekResetKey: String { "\(currentUserId)_lastWeekReset" }
    private var biologyKey:       String { "\(currentUserId)_biologyQuestions" }
    private var financeKey:       String { "\(currentUserId)_financeQuestions" }
    private var historyKey:       String { "\(currentUserId)_historyQuestions" }

    // Don't auto-load in init — SupabaseManager calls loadData(for:) once
    // the userId is known.
    private init() {}

    // MARK: - User Lifecycle

    /// Called by SupabaseManager after sign-in or session restore.
    func loadData(for userId: String) {
        currentUserId = userId
        loadAll()
        checkStreak()
        resetDailyIfNeeded()
    }

    /// Called by SupabaseManager on sign-out.
    /// Resets all in-memory stats to zero — does NOT delete the persisted data
    /// so it comes back correctly when the same user signs in again.
    func clearAll() {
        totalXP            = 0
        weeklyXP           = 0
        currentStreak      = 0
        longestStreak      = 0
        totalSessions      = 0
        totalQuestions     = 0
        minutesEarnedToday = 0
        level              = 1
        weeklyActivity     = [0, 0, 0, 0, 0, 0, 0]
        biologyQuestions   = 0
        financeQuestions   = 0
        historyQuestions   = 0
        currentUserId      = ""
    }

    // MARK: - Load / Save

    func loadAll() {
        guard !currentUserId.isEmpty else { return }
        totalXP            = UserDefaults.standard.integer(forKey: xpKey)
        weeklyXP           = UserDefaults.standard.integer(forKey: weeklyXPKey)
        currentStreak      = UserDefaults.standard.integer(forKey: streakKey)
        longestStreak      = UserDefaults.standard.integer(forKey: longestKey)
        totalSessions      = UserDefaults.standard.integer(forKey: sessionsKey)
        totalQuestions     = UserDefaults.standard.integer(forKey: questionsKey)
        minutesEarnedToday = UserDefaults.standard.integer(forKey: minutesTodayKey)
        biologyQuestions   = UserDefaults.standard.integer(forKey: biologyKey)
        financeQuestions   = UserDefaults.standard.integer(forKey: financeKey)
        historyQuestions   = UserDefaults.standard.integer(forKey: historyKey)

        if let saved = UserDefaults.standard.array(forKey: weeklyKey) as? [Int], saved.count == 7 {
            weeklyActivity = saved
        }
        updateLevel()
    }

    func saveAll() {
        guard !currentUserId.isEmpty else { return }
        UserDefaults.standard.set(totalXP,            forKey: xpKey)
        UserDefaults.standard.set(weeklyXP,           forKey: weeklyXPKey)
        UserDefaults.standard.set(currentStreak,      forKey: streakKey)
        UserDefaults.standard.set(longestStreak,      forKey: longestKey)
        UserDefaults.standard.set(totalSessions,      forKey: sessionsKey)
        UserDefaults.standard.set(totalQuestions,     forKey: questionsKey)
        UserDefaults.standard.set(minutesEarnedToday, forKey: minutesTodayKey)
    }

    // MARK: - Session Completion

    func completeSession(correctCount: Int,
                         totalCount: Int,
                         minutesEarned: Int,
                         subject: String = "") {
        guard !currentUserId.isEmpty else { return }
        let xpGained = 10 + (correctCount * 5)
        totalXP            += xpGained
        weeklyXP           += xpGained      // accumulates until Monday reset
        totalSessions      += 1
        totalQuestions     += totalCount
        minutesEarnedToday += minutesEarned

        switch subject.lowercased() {
        case "biology":
            biologyQuestions += totalCount
            UserDefaults.standard.set(biologyQuestions, forKey: biologyKey)
        case "finance":
            financeQuestions += totalCount
            UserDefaults.standard.set(financeQuestions, forKey: financeKey)
        case "history":
            historyQuestions += totalCount
            UserDefaults.standard.set(historyQuestions, forKey: historyKey)
        default:
            break
        }

        let todayIndex = todayWeekIndex()
        weeklyActivity[todayIndex] += 1
        UserDefaults.standard.set(weeklyActivity, forKey: weeklyKey)

        updateStreak()
        updateLevel()
        saveAll()

        // Push updated stats to Supabase so the leaderboard reflects real data.
        SupabaseManager.shared.upsertStats(
            xp:        totalXP,
            weeklyXP:  weeklyXP,
            streak:    currentStreak,
            sessions:  totalSessions
        )
    }

    // MARK: - Streak

    func checkStreak() {
        guard !currentUserId.isEmpty else { return }
        guard let lastDate = UserDefaults.standard.object(forKey: lastActiveKey) as? Date else { return }
        let days = Calendar.current.dateComponents([.day], from: lastDate, to: Date()).day ?? 0
        if days > 1 {
            currentStreak = 0
            UserDefaults.standard.set(0, forKey: streakKey)
        }
    }

    func updateStreak() {
        guard !currentUserId.isEmpty else { return }
        let calendar = Calendar.current
        let today    = calendar.startOfDay(for: Date())

        if let lastDate = UserDefaults.standard.object(forKey: lastActiveKey) as? Date {
            let lastDay = calendar.startOfDay(for: lastDate)
            let diff    = calendar.dateComponents([.day], from: lastDay, to: today).day ?? 0
            if diff == 1 {
                currentStreak += 1
            } else if diff > 1 {
                currentStreak = 1
            }
        } else {
            currentStreak = 1
        }

        if currentStreak > longestStreak { longestStreak = currentStreak }
        UserDefaults.standard.set(Date(), forKey: lastActiveKey)
    }

    // MARK: - Level / XP

    func updateLevel() {
        level = (totalXP / 100) + 1
    }

    var xpProgress:       Double { Double(totalXP % 100) / 100.0 }
    var xpInCurrentLevel: Int    { totalXP % 100 }

    // MARK: - Daily / Weekly Reset

    func resetDailyIfNeeded() {
        guard !currentUserId.isEmpty else { return }
        let lastReset = UserDefaults.standard.object(forKey: lastResetKey) as? Date ?? .distantPast
        let calendar  = Calendar.current

        if !calendar.isDateInToday(lastReset) {
            minutesEarnedToday = 0
            UserDefaults.standard.set(0,     forKey: minutesTodayKey)
            UserDefaults.standard.set(Date(), forKey: lastResetKey)
        }

        // Reset weeklyXP and weeklyActivity every Monday.
        if calendar.component(.weekday, from: Date()) == 2 {
            let lastWeekReset = UserDefaults.standard.object(forKey: lastWeekResetKey) as? Date ?? .distantPast
            if !calendar.isDateInToday(lastWeekReset) {
                weeklyXP       = 0
                weeklyActivity = [0, 0, 0, 0, 0, 0, 0]
                UserDefaults.standard.set(0,           forKey: weeklyXPKey)
                UserDefaults.standard.set(weeklyActivity, forKey: weeklyKey)
                UserDefaults.standard.set(Date(),      forKey: lastWeekResetKey)

                // Push the reset (weeklyXP = 0) to Supabase immediately.
                SupabaseManager.shared.upsertStats(
                    xp:       totalXP,
                    weeklyXP: 0,
                    streak:   currentStreak,
                    sessions: totalSessions
                )
            }
        }
    }

    // MARK: - Subject Progress

    func subjectProgress(for subject: String, totalQuestions: Int) -> Double {
        let answered: Int
        switch subject.lowercased() {
        case "biology":  answered = biologyQuestions
        case "finance":  answered = financeQuestions
        case "history":  answered = historyQuestions
        default:         answered = 0
        }
        guard totalQuestions > 0 else { return 0 }
        return min(1.0, Double(answered) / Double(totalQuestions))
    }

    func todayWeekIndex() -> Int {
        let weekday = Calendar.current.component(.weekday, from: Date())
        return (weekday + 5) % 7   // Monday = 0 … Sunday = 6
    }
}
