import SwiftUI

struct LeaderboardView: View {
    @ObservedObject var stats = StatsManager.shared
    @ObservedObject var auth  = SupabaseManager.shared
    @AppStorage("inviteCode") private var inviteCode = "CLAVIS-\(Int.random(in: 1000...9999))"

    @State private var entries:   [FriendEntry] = []
    @State private var isLoading  = false
    @State private var fetchError = ""
    @State private var copied     = false

    var body: some View {
        ZStack {
            Color(red: 0.07, green: 0.07, blue: 0.12)
                .ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 24) {

                    Text("Leaderboard")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.horizontal, 24)
                        .padding(.top, 60)

                    // ── Current User Identity Card ──────────────────────
                    CurrentUserCard(stats: stats, auth: auth)
                        .padding(.horizontal, 24)

                    // ── Invite Card ─────────────────────────────────────
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Invite friends")
                            .font(.system(size: 17, weight: .semibold))
                            .foregroundColor(.white)

                        HStack(spacing: 12) {
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Your invite code")
                                    .font(.system(size: 13))
                                    .foregroundColor(.white.opacity(0.5))
                                Text(inviteCode)
                                    .font(.system(size: 20, weight: .bold))
                                    .foregroundColor(Color(red: 0.42, green: 0.32, blue: 1.0))
                            }
                            Spacer()
                            Button {
                                UIPasteboard.general.string = inviteCode
                                copied = true
                                DispatchQueue.main.asyncAfter(deadline: .now() + 2) { copied = false }
                            } label: {
                                HStack(spacing: 6) {
                                    Image(systemName: copied ? "checkmark" : "doc.on.doc.fill")
                                        .font(.system(size: 14))
                                    Text(copied ? "Copied!" : "Copy")
                                        .font(.system(size: 14, weight: .semibold))
                                }
                                .foregroundColor(.white)
                                .padding(.horizontal, 16).padding(.vertical, 10)
                                .background(Color(red: 0.42, green: 0.32, blue: 1.0))
                                .cornerRadius(12)
                            }
                        }
                    }
                    .padding(16)
                    .background(Color(red: 0.12, green: 0.12, blue: 0.19))
                    .cornerRadius(16)
                    .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.08), lineWidth: 1))
                    .padding(.horizontal, 24)

                    // ── Rankings ────────────────────────────────────────
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Text("Weekly XP ranking")
                                .font(.system(size: 17, weight: .semibold))
                                .foregroundColor(.white)
                            Spacer()
                            if isLoading {
                                ProgressView().tint(.white).scaleEffect(0.8)
                            } else {
                                Button { loadLeaderboard() } label: {
                                    Image(systemName: "arrow.clockwise")
                                        .font(.system(size: 14))
                                        .foregroundColor(.white.opacity(0.4))
                                }
                            }
                        }

                        if !fetchError.isEmpty {
                            Text(fetchError)
                                .font(.system(size: 13))
                                .foregroundColor(.red.opacity(0.8))
                                .multilineTextAlignment(.center)
                                .frame(maxWidth: .infinity).padding(.vertical, 8)
                        }

                        if entries.isEmpty && !isLoading {
                            Text("No data yet. Complete a lesson to appear here!")
                                .font(.system(size: 14))
                                .foregroundColor(.white.opacity(0.4))
                                .multilineTextAlignment(.center)
                                .frame(maxWidth: .infinity).padding(.vertical, 24)
                        } else {
                            ForEach(entries) { entry in
                                LeaderboardRow(entry: entry)
                            }
                        }
                    }
                    .padding(.horizontal, 24)
                    .padding(.bottom, 110)
                }
            }
        }
        .onAppear { loadLeaderboard() }
    }

    private func loadLeaderboard() {
        guard !isLoading else { return }
        isLoading = true; fetchError = ""
        SupabaseManager.shared.fetchLeaderboard { fetched in
            isLoading = false
            if fetched.isEmpty {
                let s = StatsManager.shared
                if s.totalXP > 0 {
                    let a = SupabaseManager.shared
                    entries = [FriendEntry(
                        rank: 1,
                        name: a.userName.isEmpty ? a.userEmail : a.userName,
                        xp: s.totalXP, weeklyXP: s.weeklyXP,
                        streak: s.currentStreak, sessions: s.totalSessions,
                        isYou: true
                    )]
                } else { entries = [] }
            } else { entries = fetched }
        }
    }
}

// MARK: - Current User Identity Card

struct CurrentUserCard: View {
    @ObservedObject var stats: StatsManager
    @ObservedObject var auth:  SupabaseManager

    private var displayName: String {
        auth.userName.isEmpty ? (auth.userEmail.isEmpty ? "You" : auth.userEmail) : auth.userName
    }
    private var tier: UserTier { UserTier.from(xp: stats.totalXP) }
    private var tierProgress: Double { tier.progress(xp: stats.totalXP) }
    private var xpToNext: Int? {
        guard let next = tier.nextTierMinXP else { return nil }
        return next - stats.totalXP
    }

    var body: some View {
        VStack(spacing: 16) {
            HStack(spacing: 16) {
                // Avatar — swap Text for AsyncImage when profile pictures are added
                ZStack {
                    Circle()
                        .fill(tier.color.opacity(0.18))
                        .frame(width: 62, height: 62)
                    Circle()
                        .stroke(tier.color.opacity(0.5), lineWidth: 2)
                        .frame(width: 62, height: 62)
                    Text(String(displayName.prefix(1)).uppercased())
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(tier.color)
                }

                VStack(alignment: .leading, spacing: 6) {
                    Text(displayName)
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(.white)
                        .lineLimit(1)

                    TierBadge(tier: tier)

                    HStack(spacing: 14) {
                        StatPill(icon: "flame.fill",  color: .orange,
                                 value: "\(stats.currentStreak)", label: "streak")
                        StatPill(icon: "book.fill",
                                 color: Color(red: 0.42, green: 0.32, blue: 1.0),
                                 value: "\(stats.totalSessions)", label: "sessions")
                        StatPill(icon: "star.fill",   color: .yellow,
                                 value: "\(stats.totalXP)", label: "total XP")
                    }
                }

                Spacer()
            }

            // Tier progress bar
            VStack(alignment: .leading, spacing: 6) {
                HStack {
                    Text(tier == .diamond ? "Max tier reached" : "Progress to \(nextTierName)")
                        .font(.system(size: 12))
                        .foregroundColor(.white.opacity(0.5))
                    Spacer()
                    if let xpLeft = xpToNext {
                        Text("\(xpLeft) XP to go")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(tier.color)
                    }
                }

                GeometryReader { geo in
                    ZStack(alignment: .leading) {
                        RoundedRectangle(cornerRadius: 4)
                            .fill(Color.white.opacity(0.08))
                            .frame(height: 6)
                        RoundedRectangle(cornerRadius: 4)
                            .fill(tier.color)
                            .frame(width: geo.size.width * tierProgress, height: 6)
                            .animation(.easeInOut(duration: 0.6), value: tierProgress)
                    }
                }
                .frame(height: 6)
            }
        }
        .padding(16)
        .background(Color(red: 0.12, green: 0.12, blue: 0.19))
        .cornerRadius(16)
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(tier.color.opacity(0.25), lineWidth: 1)
        )
    }

    private var nextTierName: String {
        switch tier {
        case .bronze:   return "Silver"
        case .silver:   return "Gold"
        case .gold:     return "Platinum"
        case .platinum: return "Diamond"
        case .diamond:  return ""
        }
    }
}

// MARK: - Leaderboard Row

struct LeaderboardRow: View {
    let entry: FriendEntry

    var rankLabel: some View {
        Group {
            if entry.rank <= 3 {
                Text(["🥇","🥈","🥉"][entry.rank - 1])
                    .font(.system(size: 24))
            } else {
                Text("\(entry.rank)")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(.white.opacity(0.3))
            }
        }
        .frame(width: 36)
    }

    var body: some View {
        HStack(spacing: 14) {
            rankLabel

            // Avatar — replace Text with AsyncImage when profile pictures land
            ZStack {
                Circle()
                    .fill(entry.isYou
                          ? Color(red: 0.42, green: 0.32, blue: 1.0).opacity(0.2)
                          : Color.white.opacity(0.08))
                    .frame(width: 42, height: 42)
                Text(entry.initial)
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(entry.isYou
                                     ? Color(red: 0.42, green: 0.32, blue: 1.0)
                                     : .white.opacity(0.8))
            }

            VStack(alignment: .leading, spacing: 4) {
                // Name + "you" pill
                HStack(spacing: 6) {
                    Text(entry.name)
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(entry.isYou
                                         ? Color(red: 0.42, green: 0.32, blue: 1.0)
                                         : .white)
                        .lineLimit(1)
                    if entry.isYou {
                        Text("you")
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundColor(.white)
                            .padding(.horizontal, 6).padding(.vertical, 2)
                            .background(Color(red: 0.42, green: 0.32, blue: 1.0))
                            .cornerRadius(6)
                    }
                }

                // Tier badge + streak + sessions
                HStack(spacing: 8) {
                    TierBadge(tier: entry.tier)

                    HStack(spacing: 3) {
                        Image(systemName: "flame.fill")
                            .foregroundColor(.orange).font(.system(size: 10))
                        Text("\(entry.streak)")
                            .font(.system(size: 11)).foregroundColor(.white.opacity(0.5))
                    }
                    HStack(spacing: 3) {
                        Image(systemName: "book.fill")
                            .foregroundColor(Color(red: 0.42, green: 0.32, blue: 1.0))
                            .font(.system(size: 10))
                        Text("\(entry.sessions)")
                            .font(.system(size: 11)).foregroundColor(.white.opacity(0.5))
                    }
                }
            }

            Spacer()

            VStack(alignment: .trailing, spacing: 2) {
                Text("\(entry.weeklyXP)")
                    .font(.system(size: 17, weight: .bold))
                    .foregroundColor(entry.isYou
                                     ? Color(red: 0.42, green: 0.32, blue: 1.0)
                                     : .white)
                Text("XP")
                    .font(.system(size: 12)).foregroundColor(.white.opacity(0.4))
            }
        }
        .padding(14)
        .background(entry.isYou
                    ? Color(red: 0.42, green: 0.32, blue: 1.0).opacity(0.08)
                    : Color(red: 0.12, green: 0.12, blue: 0.19))
        .cornerRadius(16)
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(
            entry.isYou
                ? Color(red: 0.42, green: 0.32, blue: 1.0).opacity(0.3)
                : Color.white.opacity(0.08),
            lineWidth: 1))
    }
}

// MARK: - Shared Components

/// Colored tier pill with icon + name. Reusable anywhere in the app.
struct TierBadge: View {
    let tier: UserTier

    var body: some View {
        HStack(spacing: 3) {
            Text(tier.icon).font(.system(size: 10))
            Text(tier.rawValue)
                .font(.system(size: 10, weight: .semibold))
                .foregroundColor(tier.color)
        }
        .padding(.horizontal, 6).padding(.vertical, 2)
        .background(tier.color.opacity(0.12))
        .cornerRadius(6)
    }
}

/// Small stat label used inside the CurrentUserCard.
private struct StatPill: View {
    let icon: String
    let color: Color
    let value: String
    let label: String

    var body: some View {
        HStack(spacing: 3) {
            Image(systemName: icon).font(.system(size: 10)).foregroundColor(color)
            Text(value).font(.system(size: 11, weight: .semibold)).foregroundColor(.white)
            Text(label).font(.system(size: 10)).foregroundColor(.white.opacity(0.4))
        }
    }
}

#Preview {
    LeaderboardView()
}
