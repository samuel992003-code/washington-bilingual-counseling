import SwiftUI
import PhotosUI
import UniformTypeIdentifiers
import Vision
import PDFKit

struct UploadView: View {
    @State private var showTextInput    = false
    @State private var pastedText       = ""
    @State private var showCamera       = false
    @State private var showDocPicker    = false
    @State private var selectedPhoto: PhotosPickerItem? = nil
    @State private var selectedSubject  = "General"
    @State private var showTopicCourse  = false
    // Drives navigation to SubjectDetailView when the user taps a completed upload.
    @State private var navigateToUpload: SavedUpload? = nil

    @ObservedObject private var storage = StorageManager.shared

    let subjects = ["General", "Biology", "Finance", "History", "Chemistry", "Math", "Physics", "Psychology"]

    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 0.07, green: 0.07, blue: 0.12).ignoresSafeArea()

                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 24) {

                        VStack(alignment: .leading, spacing: 6) {
                            Text("Upload material")
                                .font(.system(size: 28, weight: .bold))
                                .foregroundColor(.white)
                            Text("AI builds a full lesson plan from your notes")
                                .font(.system(size: 15))
                                .foregroundColor(.white.opacity(0.6))
                        }
                        .padding(.horizontal, 24)
                        .padding(.top, 60)

                        // Subject selector (for uploaded-notes mode)
                        VStack(alignment: .leading, spacing: 10) {
                            Text("Subject")
                                .font(.system(size: 15, weight: .semibold))
                                .foregroundColor(.white.opacity(0.6))

                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack(spacing: 8) {
                                    ForEach(subjects, id: \.self) { subject in
                                        Button { selectedSubject = subject } label: {
                                            Text(subject)
                                                .font(.system(size: 14, weight: selectedSubject == subject ? .semibold : .regular))
                                                .foregroundColor(selectedSubject == subject ? .white : .white.opacity(0.5))
                                                .padding(.horizontal, 14)
                                                .padding(.vertical, 8)
                                                .background(selectedSubject == subject
                                                            ? Color(red: 0.42, green: 0.32, blue: 1.0)
                                                            : Color(red: 0.12, green: 0.12, blue: 0.19))
                                                .cornerRadius(20)
                                                .overlay(RoundedRectangle(cornerRadius: 20)
                                                    .stroke(selectedSubject == subject ? Color.clear : Color.white.opacity(0.08), lineWidth: 1))
                                        }
                                    }
                                }
                            }
                        }
                        .padding(.horizontal, 24)

                        // Upload options (notes-based)
                        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                            UploadCard(icon: "doc.fill", title: "PDF", subtitle: "Lecture slides\nor study guides", color: Color(red: 1.0, green: 0.35, blue: 0.35)) {
                                showDocPicker = true
                            }
                            UploadCard(icon: "camera.fill", title: "Camera", subtitle: "Photo your\nhandwritten notes", color: Color(red: 0.42, green: 0.32, blue: 1.0)) {
                                showCamera = true
                            }
                            PhotosPicker(selection: $selectedPhoto, matching: .images) {
                                UploadCardLabel(icon: "photo.fill", title: "Photos", subtitle: "Screenshots from\nyour camera roll", color: Color(red: 0.2, green: 0.85, blue: 0.5))
                            }
                            .onChange(of: selectedPhoto) {
                                if let item = selectedPhoto {
                                    handlePhotoSelection(item)
                                    selectedPhoto = nil
                                }
                            }
                            UploadCard(icon: "text.alignleft", title: "Type / Paste", subtitle: "Paste text\ndirectly", color: Color(red: 1.0, green: 0.7, blue: 0.2)) {
                                withAnimation(.spring()) { showTextInput.toggle() }
                            }
                        }
                        .padding(.horizontal, 24)

                        // ── Topic-based course entry point ───────────────────────────────────
                        VStack(alignment: .leading, spacing: 10) {
                            Text("No notes? Build from a topic")
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundColor(.white.opacity(0.35))
                                .textCase(.uppercase)
                                .tracking(0.6)
                                .padding(.horizontal, 24)

                            Button { showTopicCourse = true } label: {
                                HStack(spacing: 16) {
                                    ZStack {
                                        Circle()
                                            .fill(Color(red: 0.42, green: 0.32, blue: 1.0).opacity(0.15))
                                            .frame(width: 52, height: 52)
                                        Image(systemName: "sparkles")
                                            .font(.system(size: 22))
                                            .foregroundColor(Color(red: 0.42, green: 0.32, blue: 1.0))
                                    }
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text("Build a 1-month course")
                                            .font(.system(size: 16, weight: .semibold))
                                            .foregroundColor(.white)
                                        Text("Type a topic — AI generates 30 lessons for you")
                                            .font(.system(size: 13))
                                            .foregroundColor(.white.opacity(0.5))
                                    }
                                    Spacer()
                                    Image(systemName: "chevron.right")
                                        .font(.system(size: 13, weight: .medium))
                                        .foregroundColor(.white.opacity(0.3))
                                }
                                .padding(16)
                                .background(Color(red: 0.12, green: 0.12, blue: 0.19))
                                .cornerRadius(16)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 16)
                                        .stroke(Color(red: 0.42, green: 0.32, blue: 1.0).opacity(0.25), lineWidth: 1)
                                )
                            }
                            .padding(.horizontal, 24)
                        }

                        // Text input (notes paste)
                        if showTextInput {
                            VStack(alignment: .leading, spacing: 12) {
                                HStack {
                                    Text("Paste your notes")
                                        .font(.system(size: 16, weight: .semibold))
                                        .foregroundColor(.white)
                                    Spacer()
                                    Button { withAnimation { showTextInput = false } } label: {
                                        Image(systemName: "xmark.circle.fill")
                                            .foregroundColor(.white.opacity(0.3))
                                            .font(.system(size: 20))
                                    }
                                }

                                TextEditor(text: $pastedText)
                                    .font(.system(size: 15))
                                    .foregroundColor(.white)
                                    .frame(minHeight: 140)
                                    .scrollContentBackground(.hidden)
                                    .padding(12)
                                    .background(Color(red: 0.07, green: 0.07, blue: 0.12))
                                    .cornerRadius(12)
                                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.white.opacity(0.08), lineWidth: 1))

                                if !pastedText.isEmpty {
                                    Button {
                                        processText(pastedText, title: "Pasted notes")
                                        showTextInput = false
                                        pastedText    = ""
                                    } label: {
                                        Text("Build Lesson Plan →")
                                            .font(.system(size: 16, weight: .semibold))
                                            .foregroundColor(.white)
                                            .frame(maxWidth: .infinity)
                                            .frame(height: 50)
                                            .background(Color(red: 0.42, green: 0.32, blue: 1.0))
                                            .cornerRadius(14)
                                    }
                                }
                            }
                            .padding(16)
                            .background(Color(red: 0.12, green: 0.12, blue: 0.19))
                            .cornerRadius(16)
                            .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.08), lineWidth: 1))
                            .padding(.horizontal, 24)
                            .transition(.move(edge: .top).combined(with: .opacity))
                        }

                        // Uploaded items
                        if !storage.savedUploads.isEmpty {
                            VStack(alignment: .leading, spacing: 12) {
                                HStack {
                                    Text("Your materials")
                                        .font(.system(size: 17, weight: .semibold))
                                        .foregroundColor(.white)
                                    Spacer()
                                    Text("\(storage.savedUploads.count) files")
                                        .font(.system(size: 13))
                                        .foregroundColor(.white.opacity(0.4))
                                }

                                ForEach(storage.savedUploads) { upload in
                                    Button {
                                        if upload.status == .complete {
                                            navigateToUpload = upload
                                        }
                                    } label: {
                                        UploadedRow(
                                            upload: upload,
                                            lessonCount: storage.getLessons(for: upload.id)
                                                .filter { !$0.isPlaceholder }.count,
                                            totalChunks: storage.getLessons(for: upload.id).count,
                                            onDelete: {
                                                withAnimation { StorageManager.shared.deleteUpload(id: upload.id) }
                                            }
                                        )
                                    }
                                    .buttonStyle(PlainButtonStyle())
                                }
                            }
                            .padding(.horizontal, 24)
                        } else if !showTextInput {
                            VStack(spacing: 12) {
                                Text("📂").font(.system(size: 48))
                                Text("No material uploaded yet")
                                    .font(.system(size: 16, weight: .semibold))
                                    .foregroundColor(.white.opacity(0.6))
                                Text("Upload your notes above, or build a course\nfrom a topic using the button above")
                                    .font(.system(size: 14))
                                    .foregroundColor(.white.opacity(0.3))
                                    .multilineTextAlignment(.center)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 40)
                        }

                        Spacer().frame(height: 100)
                    }
                }
            }
            .toolbar(.hidden, for: .navigationBar)
            .navigationDestination(isPresented: Binding(
                get:  { navigateToUpload != nil },
                set:  { if !$0 { navigateToUpload = nil } }
            )) {
                if let upload = navigateToUpload {
                    SubjectDetailView(
                        emoji:     emojiForSubject(upload.subject),
                        name:      upload.subject,
                        questions: upload.questionCount,
                        color:     colorForSubject(upload.subject)
                    )
                }
            }
        }
        .sheet(isPresented: $showCamera) {
            CameraView { image in
                showCamera = false
                if let image = image { extractTextFromImage(image, title: "Camera notes") }
            }
        }
        .sheet(isPresented: $showDocPicker) {
            DocumentPickerView { url in
                showDocPicker = false
                if let url = url { extractTextFromPDF(url) }
            }
        }
        .sheet(isPresented: $showTopicCourse) {
            TopicCourseView(isPresented: $showTopicCourse)
        }
    }

    // MARK: - Subject helpers

    private func emojiForSubject(_ subject: String) -> String {
        AIManager.shared.emojiForSubject(subject)
    }

    private func colorForSubject(_ subject: String) -> Color {
        switch subject.lowercased() {
        case "biology":    return Color(red: 0.42, green: 0.32, blue: 1.0)
        case "finance":    return Color(red: 0.2,  green: 0.85, blue: 0.5)
        case "history":    return Color(red: 1.0,  green: 0.6,  blue: 0.2)
        case "chemistry":  return Color(red: 1.0,  green: 0.35, blue: 0.35)
        case "math":       return Color(red: 0.2,  green: 0.7,  blue: 1.0)
        case "physics":    return Color(red: 1.0,  green: 0.8,  blue: 0.2)
        case "english":    return Color(red: 0.9,  green: 0.4,  blue: 0.8)
        case "psychology": return Color(red: 0.5,  green: 0.8,  blue: 0.9)
        default:           return Color(red: 0.62, green: 0.32, blue: 1.0)
        }
    }

    // MARK: - Processing (upload-based)

    func processText(_ text: String, title: String) {
        let subject  = selectedSubject
        var upload   = SavedUpload(id: UUID(), title: title, icon: "text.alignleft",
                                   subject: subject, extractedText: text)
        upload.status = .processing
        StorageManager.shared.saveUpload(upload)
        let uploadId = upload.id

        // Fast-path: 5 questions from the first 6k chars.
        AIManager.shared.generateQuestions(from: String(text.prefix(6_000)), subject: subject) { questions in
            upload.status        = .complete
            upload.questionCount = questions.count
            upload.questions     = questions.map {
                SavedQuestion(emoji: $0.emoji, subject: $0.subject, question: $0.question,
                              options: $0.options, correct: $0.correct, explanation: $0.explanation)
            }
            StorageManager.shared.updateUpload(upload)
        }

        // Full lesson plan from the entire text (runs in parallel with questions above).
        LessonPlanManager.shared.buildLessonPlan(from: text, subject: subject, uploadId: uploadId) { }
    }

    func extractTextFromImage(_ image: UIImage, title: String) {
        let subject  = selectedSubject
        var upload   = SavedUpload(id: UUID(), title: title, icon: "camera.fill", subject: subject)
        upload.status = .processing
        StorageManager.shared.saveUpload(upload)

        guard let cgImage = image.cgImage else {
            upload.status = .failed
            StorageManager.shared.updateUpload(upload)
            return
        }

        let request = VNRecognizeTextRequest { req, _ in
            let text = req.results?
                .compactMap { $0 as? VNRecognizedTextObservation }
                .compactMap { $0.topCandidates(1).first?.string }
                .joined(separator: "\n") ?? ""

            guard !text.isEmpty else {
                DispatchQueue.main.async {
                    upload.status = .failed
                    StorageManager.shared.updateUpload(upload)
                }
                return
            }

            upload.extractedText = text
            StorageManager.shared.saveUpload(upload)
            let capturedSubject = upload.subject
            let capturedId      = upload.id

            AIManager.shared.generateQuestions(from: String(text.prefix(6_000)), subject: capturedSubject) { questions in
                upload.status        = .complete
                upload.questionCount = questions.count
                upload.questions     = questions.map {
                    SavedQuestion(emoji: $0.emoji, subject: $0.subject, question: $0.question,
                                  options: $0.options, correct: $0.correct, explanation: $0.explanation)
                }
                StorageManager.shared.updateUpload(upload)
            }

            LessonPlanManager.shared.buildLessonPlan(from: text, subject: capturedSubject, uploadId: capturedId) { }
        }
        request.recognitionLevel       = .accurate
        request.usesLanguageCorrection = true

        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        DispatchQueue.global(qos: .userInitiated).async {
            try? handler.perform([request])
        }
    }

    func extractTextFromPDF(_ url: URL) {
        let accessed = url.startAccessingSecurityScopedResource()
        let subject  = selectedSubject

        var upload   = SavedUpload(id: UUID(), title: url.lastPathComponent, icon: "doc.fill", subject: subject)
        upload.status = .processing
        StorageManager.shared.saveUpload(upload)

        DispatchQueue.global(qos: .userInitiated).async {
            defer { if accessed { url.stopAccessingSecurityScopedResource() } }

            guard let pdf = PDFDocument(url: url) else {
                DispatchQueue.main.async {
                    upload.status = .failed
                    StorageManager.shared.updateUpload(upload)
                }
                return
            }

            let maxChars   = 250_000
            let totalPages = pdf.pageCount
            var fullText   = ""

            for pageIdx in 0..<totalPages {
                guard fullText.count < maxChars else { break }

                autoreleasepool {
                    guard let page = pdf.page(at: pageIdx) else { return }

                    if let pageText = page.string,
                       !pageText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                        fullText += pageText + "\n"
                        return
                    }

                    let thumbSize = CGSize(width: 1024, height: 1448)
                    let thumb     = page.thumbnail(of: thumbSize, for: .mediaBox)
                    guard let cgImage = thumb.cgImage else { return }

                    var ocrResult = ""
                    let req = VNRecognizeTextRequest { request, _ in
                        ocrResult = request.results?
                            .compactMap { $0 as? VNRecognizedTextObservation }
                            .compactMap { $0.topCandidates(1).first?.string }
                            .joined(separator: "\n") ?? ""
                    }
                    req.recognitionLevel       = .accurate
                    req.usesLanguageCorrection = true

                    let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
                    try? handler.perform([req])

                    if !ocrResult.isEmpty { fullText += ocrResult + "\n" }
                }
            }

            let trimmedText = String(fullText.prefix(maxChars))
                .trimmingCharacters(in: .whitespacesAndNewlines)

            guard !trimmedText.isEmpty else {
                DispatchQueue.main.async {
                    upload.status = .failed
                    StorageManager.shared.updateUpload(upload)
                }
                return
            }

            upload.extractedText = trimmedText
            StorageManager.shared.saveUpload(upload)

            let capturedSubject = upload.subject
            let capturedId      = upload.id

            let questionsText = String(trimmedText.prefix(6_000))
            AIManager.shared.generateQuestions(from: questionsText, subject: capturedSubject) { questions in
                upload.status        = .complete
                upload.questionCount = questions.count
                upload.questions     = questions.map {
                    SavedQuestion(emoji: $0.emoji, subject: $0.subject, question: $0.question,
                                  options: $0.options, correct: $0.correct, explanation: $0.explanation)
                }
                StorageManager.shared.updateUpload(upload)
            }

            LessonPlanManager.shared.buildLessonPlan(
                from:     trimmedText,
                subject:  capturedSubject,
                uploadId: capturedId
            ) { }
        }
    }

    func handlePhotoSelection(_ item: PhotosPickerItem) {
        item.loadTransferable(type: Data.self) { result in
            DispatchQueue.main.async {
                if case .success(let data) = result,
                   let data  = data,
                   let image = UIImage(data: data) {
                    self.extractTextFromImage(image, title: "Photo notes")
                }
            }
        }
    }
}

// MARK: - Reusable card views

struct UploadCard: View {
    let icon:     String
    let title:    String
    let subtitle: String
    let color:    Color
    let action:   () -> Void

    var body: some View {
        Button(action: action) {
            UploadCardLabel(icon: icon, title: title, subtitle: subtitle, color: color)
        }
    }
}

struct UploadCardLabel: View {
    let icon:     String
    let title:    String
    let subtitle: String
    let color:    Color

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            ZStack {
                Circle().fill(color.opacity(0.15)).frame(width: 46, height: 46)
                Image(systemName: icon).foregroundColor(color).font(.system(size: 20))
            }
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.system(size: 16, weight: .semibold)).foregroundColor(.white)
                Text(subtitle).font(.system(size: 12)).foregroundColor(.white.opacity(0.5)).fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(red: 0.12, green: 0.12, blue: 0.19))
        .cornerRadius(16)
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.08), lineWidth: 1))
    }
}

struct UploadedRow: View {
    let upload:      SavedUpload
    let lessonCount: Int
    let totalChunks: Int
    var onDelete:    (() -> Void)? = nil

    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                Circle().fill(iconColor.opacity(0.15)).frame(width: 46, height: 46)
                Image(systemName: upload.icon)
                    .foregroundColor(iconColor)
                    .font(.system(size: 18))
            }

            VStack(alignment: .leading, spacing: 4) {
                Text(upload.title).font(.system(size: 15, weight: .semibold)).foregroundColor(.white)
                Text(upload.subject).font(.system(size: 12)).foregroundColor(iconColor)

                switch upload.status {
                case .processing:
                    HStack(spacing: 6) {
                        ProgressView().scaleEffect(0.7).tint(iconColor)
                        Text("Processing…").font(.system(size: 13)).foregroundColor(.white.opacity(0.5))
                    }
                case .complete:
                    if totalChunks > 0 {
                        HStack(spacing: 4) {
                            if lessonCount < totalChunks {
                                ProgressView().scaleEffect(0.65).tint(iconColor)
                            } else {
                                Image(systemName: "checkmark.circle.fill")
                                    .font(.system(size: 12))
                                    .foregroundColor(Color(red: 0.2, green: 0.85, blue: 0.5))
                            }
                            Text("\(lessonCount)/\(totalChunks) lessons ready")
                                .font(.system(size: 13))
                                .foregroundColor(lessonCount < totalChunks
                                                 ? .white.opacity(0.5)
                                                 : Color(red: 0.2, green: 0.85, blue: 0.5))
                            Text("· Tap to study")
                                .font(.system(size: 13))
                                .foregroundColor(.white.opacity(0.3))
                        }
                    } else {
                        HStack(spacing: 6) {
                            ProgressView().scaleEffect(0.65).tint(iconColor)
                            Text("Building lesson plan…").font(.system(size: 13)).foregroundColor(.white.opacity(0.5))
                        }
                    }
                case .failed:
                    Text("Failed — check your notes and retry").font(.system(size: 13)).foregroundColor(.red)
                }
            }

            Spacer()

            if let onDelete = onDelete {
                Button(action: onDelete) {
                    Image(systemName: "trash.fill").font(.system(size: 14)).foregroundColor(.red.opacity(0.6))
                }
            }
        }
        .padding(14)
        .background(upload.status == .complete
                    ? iconColor.opacity(0.06)
                    : Color(red: 0.12, green: 0.12, blue: 0.19))
        .cornerRadius(16)
        .overlay(RoundedRectangle(cornerRadius: 16)
            .stroke(upload.status == .complete
                    ? iconColor.opacity(0.2)
                    : Color.white.opacity(0.08), lineWidth: 1))
    }

    /// Topic-based uploads use a purple accent; note-based uploads use the same purple (default).
    private var iconColor: Color {
        Color(red: 0.42, green: 0.32, blue: 1.0)
    }
}

// MARK: - Camera / Document pickers

struct CameraView: UIViewControllerRepresentable {
    let onComplete: (UIImage?) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(onComplete: onComplete) }
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.sourceType = .camera
        picker.delegate   = context.coordinator
        return picker
    }
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}

    class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let onComplete: (UIImage?) -> Void
        init(onComplete: @escaping (UIImage?) -> Void) { self.onComplete = onComplete }
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
            onComplete(info[.originalImage] as? UIImage)
        }
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) { onComplete(nil) }
    }
}

struct DocumentPickerView: UIViewControllerRepresentable {
    let onComplete: (URL?) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(onComplete: onComplete) }
    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [UTType.pdf])
        picker.delegate = context.coordinator
        return picker
    }
    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onComplete: (URL?) -> Void
        init(onComplete: @escaping (URL?) -> Void) { self.onComplete = onComplete }
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            onComplete(urls.first)
        }
        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) { onComplete(nil) }
    }
}

struct UploadView_Previews: PreviewProvider {
    static var previews: some View {
        UploadView()
    }
}
