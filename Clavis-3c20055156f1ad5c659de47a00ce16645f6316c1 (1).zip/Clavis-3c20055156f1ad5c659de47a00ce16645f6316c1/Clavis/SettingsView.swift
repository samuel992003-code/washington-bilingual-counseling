import SwiftUI

struct SettingsView: View {
    @AppStorage("isLoggedIn")            var isLoggedIn            = false
    @AppStorage("hasCompletedOnboarding") var hasCompletedOnboarding = false
    @AppStorage("questionsRequired")     var questionsRequired     = 2
    @AppStorage("privateMode")           var privateMode           = true
    @AppStorage("leaderboardOn")         var leaderboardOn         = false
    @AppStorage("notificationsOn")       var notificationsOn       = true

    @ObservedObject var stats = StatsManager.shared
    @State private var showDeleteConfirm = false

    var body: some View {
        ZStack {
            Color(red: 0.07, green: 0.07, blue: 0.12)
                .ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 24) {

                    Text("Settings")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.horizontal, 24)
                        .padding(.top, 60)

                    // Profile card
                    HStack(spacing: 16) {
                        ZStack {
                            Circle()
                                .fill(Color(red: 0.42, green: 0.32, blue: 1.0).opacity(0.15))
                                .frame(width: 60, height: 60)
                            Text("👤").font(.system(size: 28))
                        }
                        VStack(alignment: .leading, spacing: 4) {
                            Text(SupabaseManager.shared.userName.isEmpty
                                 ? "Student"
                                 : SupabaseManager.shared.userName)
                                .font(.system(size: 17, weight: .semibold))
                                .foregroundColor(.white)
                            Text("Level \(stats.level) · \(stats.totalXP) XP")
                                .font(.system(size: 14))
                                .foregroundColor(.white.opacity(0.5))
                        }
                        Spacer()
                    }
                    .padding(16)
                    .background(Color(red: 0.12, green: 0.12, blue: 0.19))
                    .cornerRadius(16)
                    .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.08), lineWidth: 1))
                    .padding(.horizontal, 24)

                    // Unlock rules
                    SettingsSection(title: "Unlock rules") {
                        VStack(spacing: 16) {
                            HStack {
                                Text("Questions per unlock")
                                    .font(.system(size: 15))
                                    .foregroundColor(.white)
                                Spacer()
                                HStack(spacing: 0) {
                                    ForEach([1, 2, 3], id: \.self) { n in
                                        Button { questionsRequired = n } label: {
                                            Text("\(n)")
                                                .font(.system(size: 15, weight: .semibold))
                                                .foregroundColor(questionsRequired == n ? .white : .white.opacity(0.4))
                                                .frame(width: 40, height: 34)
                                                .background(questionsRequired == n
                                                            ? Color(red: 0.42, green: 0.32, blue: 1.0)
                                                            : Color.clear)
                                        }
                                    }
                                }
                                .background(Color(red: 0.07, green: 0.07, blue: 0.12))
                                .cornerRadius(10)
                                .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white.opacity(0.08), lineWidth: 1))
                            }

                            HStack {
                                Text("Minutes earned")
                                    .font(.system(size: 15))
                                    .foregroundColor(.white)
                                Spacer()
                                Text("\(questionsRequired * 5) minutes")
                                    .font(.system(size: 15, weight: .semibold))
                                    .foregroundColor(Color(red: 0.42, green: 0.32, blue: 1.0))
                            }

                            Text("\(questionsRequired) question\(questionsRequired > 1 ? "s" : "") = \(questionsRequired * 5) minutes of app access")
                                .font(.system(size: 13))
                                .foregroundColor(.white.opacity(0.3))
                        }
                    }
                    .padding(.horizontal, 24)

                    // Privacy
                    SettingsSection(title: "Privacy") {
                        VStack(spacing: 0) {
                            SettingsToggleRow(icon: "lock.fill",   iconColor: Color(red: 0.2, green: 0.85, blue: 0.5),   title: "Private mode",          subtitle: "Hide your activity from everyone",     isOn: $privateMode)
                            Divider().background(Color.white.opacity(0.06))
                            SettingsToggleRow(icon: "trophy.fill", iconColor: .yellow,                                   title: "Show on leaderboard",   subtitle: "Let friends see your XP and streak",   isOn: $leaderboardOn)
                            Divider().background(Color.white.opacity(0.06))
                            SettingsToggleRow(icon: "bell.fill",   iconColor: Color(red: 0.42, green: 0.32, blue: 1.0), title: "Notifications",         subtitle: "Study reminders and streak alerts",    isOn: $notificationsOn)
                        }
                    }
                    .padding(.horizontal, 24)

                    // Account
                    SettingsSection(title: "Account") {
                        VStack(spacing: 0) {
                            SettingsActionRow(icon: "trash.fill", iconColor: .red, title: "Delete all materials") {
                                showDeleteConfirm = true
                            }
                            Divider().background(Color.white.opacity(0.06))
                            SettingsActionRow(icon: "arrow.right.circle.fill", iconColor: .white.opacity(0.3), title: "Sign out") {
                                SupabaseManager.shared.signOut()
                                isLoggedIn             = false
                                hasCompletedOnboarding = false
                            }
                        }
                    }
                    .padding(.horizontal, 24)

                    Text("Clavis v1.0")
                        .font(.system(size: 13))
                        .foregroundColor(.white.opacity(0.2))
                        .padding(.bottom, 110)
                }
            }
        }
        .confirmationDialog(
            "Delete all uploaded materials?",
            isPresented: $showDeleteConfirm,
            titleVisibility: .visible
        ) {
            Button("Delete All", role: .destructive) {
                StorageManager.shared.deleteAllMaterials()
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("This removes all uploads and lesson plans. Your stats and XP are kept.")
        }
    }
}

// MARK: - Settings Section

struct SettingsSection<Content: View>: View {
    let title:   String
    let content: Content

    init(title: String, @ViewBuilder content: () -> Content) {
        self.title   = title
        self.content = content()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title.uppercased())
                .font(.system(size: 12, weight: .semibold))
                .foregroundColor(.white.opacity(0.3))
                .kerning(0.8)
            content
                .padding(16)
                .background(Color(red: 0.12, green: 0.12, blue: 0.19))
                .cornerRadius(16)
                .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.08), lineWidth: 1))
        }
    }
}

// MARK: - Toggle Row

struct SettingsToggleRow: View {
    let icon:      String
    let iconColor: Color
    let title:     String
    let subtitle:  String
    @Binding var isOn: Bool

    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                Circle().fill(iconColor.opacity(0.15)).frame(width: 36, height: 36)
                Image(systemName: icon).foregroundColor(iconColor).font(.system(size: 15))
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.system(size: 15, weight: .semibold)).foregroundColor(.white)
                Text(subtitle).font(.system(size: 12)).foregroundColor(.white.opacity(0.4))
            }
            Spacer()
            Toggle("", isOn: $isOn)
                .tint(Color(red: 0.42, green: 0.32, blue: 1.0))
                .labelsHidden()
        }
        .padding(.vertical, 8)
    }
}

// MARK: - Action Row

struct SettingsActionRow: View {
    let icon:      String
    let iconColor: Color
    let title:     String
    let action:    () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 14) {
                ZStack {
                    Circle().fill(iconColor.opacity(0.15)).frame(width: 36, height: 36)
                    Image(systemName: icon).foregroundColor(iconColor).font(.system(size: 15))
                }
                Text(title).font(.system(size: 15, weight: .semibold)).foregroundColor(.white)
                Spacer()
                Image(systemName: "chevron.right").font(.system(size: 13)).foregroundColor(.white.opacity(0.2))
            }
            .padding(.vertical, 8)
        }
    }
}

#Preview {
    SettingsView()
}
